package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.MakeNotice;

@Repository
public interface MakeNoticeRepository  extends CrudRepository<MakeNotice, Integer>{

}
