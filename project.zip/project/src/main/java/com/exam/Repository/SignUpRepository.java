package com.exam.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.SignUp;

@Repository
public interface SignUpRepository  extends CrudRepository<SignUp, Integer>{
	@Query(value= "select  *  from sign_up  ", nativeQuery=true)
	public List<SignUp> findByUser_nameAndPassword(String user_name, String password);

}
