package com.exam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.Entity.AccountMaster;
import com.exam.Entity.AssetsInfo;
import com.exam.Entity.BuildingInfo;
import com.exam.Entity.ComplainsLog;
import com.exam.Entity.CostCenterInfo;
import com.exam.Entity.EmployeeInfo;
import com.exam.Entity.Event;
import com.exam.Entity.HomeStaffInfo;
import com.exam.Entity.MakeNotice;
import com.exam.Entity.MembershipInfo;
import com.exam.Entity.ParkingAllotment;
import com.exam.Entity.Service;
import com.exam.Entity.SignUp;
import com.exam.Entity.SocietyInformation;
import com.exam.Repository.AccountMasterRepo;
import com.exam.Repository.BuildingRepository;
import com.exam.Repository.Complains_logRepository;
import com.exam.Repository.EventRepository;
import com.exam.Repository.HomeStaffIRepo;
import com.exam.Repository.MakeNoticeRepository;
import com.exam.Repository.MermershipInfo;
import com.exam.Repository.ParkingAllotmentRepository;
import com.exam.Repository.ServiceProviderRepository;
import com.exam.Repository.ServiceRepo;
import com.exam.Repository.SignUpRepository;
import com.exam.Repository.SocietyInfoRepo;
import com.exam.Repository.UserAssetsInfo;
import com.exam.Repository.UserCostRepository;
import com.exam.Repository.UserEmployeeInfo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

//@CrossOrigin("")
public class Controller {
	@Autowired
	private SocietyInfoRepo repo;
	
	@Autowired
	private AccountMasterRepo accRepo;
	
	
	@Autowired
	private UserCostRepository costRepo;
	
	@Autowired
	private UserAssetsInfo AssetsRepo;
	
	@Autowired
	private UserEmployeeInfo emprepo;
	
	@Autowired
	private MermershipInfo memberRepo;
	
	@Autowired
	private HomeStaffIRepo homestaffRepo;
	
	@Autowired
	private ParkingAllotmentRepository parkingAllotment;
	
	@Autowired
	private Complains_logRepository complians;

	private Iterable<SocietyInformation> all;
	@Autowired
	private BuildingRepository buildingRepo;
	
	@Autowired
	private SignUpRepository signuprepo;
	
	@Autowired
	private MakeNoticeRepository makeNoticeRepo;
	
	@Autowired
	private EventRepository saveEventRepo;
	
	
	@Autowired
	private ServiceRepo serviceRepo;
	
	@Autowired
	private ServiceProviderRepository serProRepo;
	
	
	

	private Iterable<BuildingInfo> all2;

	private Iterable<MembershipInfo> all3;

	private Iterable<HomeStaffInfo> all4;
	
	
	@GetMapping("/")
	public String sayhello() {
		System.out.println("hello");
		return "hello";
	}
	
	
	@PostMapping("/commons/signup")
	public void signUp(@RequestBody SignUp s) {
		System.out.println(s.getUser_name()+" "+ s.getPassword());
		
		List<SignUp> result = (List<SignUp>) signuprepo.findByUser_nameAndPassword(s.getUser_name(), s.getPassword());
		System.out.println(result);
		for(SignUp s1: result) {
			if(s1.getUser_name().equals(s.getUser_name()) && (s1.equals(s.getPassword()))) {
				return ;
				}
		}
		
		signuprepo.save(s);

		
	}
	@PostMapping("/admin/society_info")
	public void saveSocietyInformation(@RequestBody SocietyInformation soc){
		System.out.println(soc);

		repo.save(soc);
		
		System.out.println(soc);
	}
	
	
	@GetMapping("/admin/getAllSociety")
	public List<SocietyInformation> getAllSociety(  ){

		all = repo.findAll();
		return (List<SocietyInformation>) all;
		
	}
	
	
	public void sayhi() {
		
	}
	
	
	
	@PostMapping("/admin/saveAccountMaster")
	public void saveAccountMaster(@RequestBody AccountMaster ac) {
		System.out.println(ac);
		accRepo.save(ac);
	}
	
	@PostMapping("/admin/saveCostAccountMaster")
	public void saveCostAccountMaster(@RequestBody CostCenterInfo cost) {
		System.out.println(cost);
		costRepo.save(cost);
	}
	
	@PostMapping("/admin/saveAssetsMaster")
	public void saveAssetsMaster(@RequestBody AssetsInfo asset) {
		System.out.println(asset);
		AssetsRepo.save(asset);
	}
	
	
	
	@PostMapping("/admin/saveEmployeeMaster")
	public void saveEmployeeMaster(@RequestBody EmployeeInfo emp) {
		System.out.println(emp);
		emprepo.save(emp);
	}
	@PostMapping("/admin/saveMembership")
	public void saveMembership(@RequestBody MembershipInfo membership) {
		System.out.println(membership);
		memberRepo.save(membership);
	}
	
	@GetMapping("/admin/getAllMember")
	public List<MembershipInfo> getallMemberInfo( ) {
		System.out.println();
//		all = repo.findAll();
//		return (List<SocietyInformation>) all;
		
		all3 = memberRepo.findAll();
		
		return   (List<MembershipInfo>) all3;
	}
	
	
	
	@PostMapping("/admin/saveHomeStaff")
	public void saveHomeStaff(@RequestBody HomeStaffInfo homestaff) {
		System.out.println(homestaff);
		homestaffRepo.save(homestaff);
	}
	
	@GetMapping("/admin/getHomeStaffInfo")
	public Iterable<HomeStaffInfo> getHomeStaffInfo(){
		all4 = homestaffRepo.findAll();
		return all4;
	}
	
	@PostMapping("/admin/saveParingAllotment")
	public void saveParingAllotment(@RequestBody ParkingAllotment parking) {
		System.out.println(parking);
		parkingAllotment.save(parking);
	}
	
	@PostMapping("/admin/saveComplains")
	public void saveComplains(@RequestBody ComplainsLog complains) {
		System.out.println(complains);
		complians.save(complains);
	}
	
//	saving building 
	@PostMapping("/admin/saveBuildingInformation")
	public void saveBuildingInformation(@RequestBody BuildingInfo buildingInfo) {
		System.out.println(buildingInfo);
		buildingRepo.save(buildingInfo);
	}
	
//	saving building 
	@GetMapping("/admin/showAllBuildingInfo")
	public Iterable<BuildingInfo>  showAllBuildingInfo() {
		System.out.println("getting all building info");
		all2 = buildingRepo.findAll();
		return all2;
	}
	
	
	@PostMapping("/admin/makeNotice")
	public void  saveMakeNotice(@RequestBody MakeNotice notice) {
		System.out.println(notice);
		makeNoticeRepo.save(notice);
	}
	
	
//	getting all notice; 
	
	@GetMapping("/admin/getAllNotice")
	public Iterable<MakeNotice>   getAllNotice( ) {
		System.out.println();
		Iterable<MakeNotice> all5 = makeNoticeRepo.findAll();
		return all5;
	}
	
	
//	getting all events; 
	
	@PostMapping("/admin/saveEvents")
	public  void saveEvents( @RequestBody Event event) {
		System.out.println(event);
		saveEventRepo.save(event);
	}
	
	
//	saving service 
	@PostMapping("/admin/saveService")
	public  void saveServiceProvider( @RequestBody Service service) {
		System.out.println(service);
		serviceRepo.save(service);
	}
	
	
	
//	serviceProvider 
	@GetMapping("/commons/getService")
	public Iterable<Service>  getdataOfServiceProvider(  ) {
		
		Iterable<Service> all5 = serviceRepo.findAll();
		return all5;
	}
	

}
