package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity

public class Service {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	int serviceId;

	String image;
	String serviceName;
	String serviceProvider;
	String mobileNumber;
	String email;
	String address;



	public Service() {
		super();
	}



	public Service(int serviceId, String image, String serviceName, String serviceProvider, String mobileNumber,
			String email, String address) {
		super();
		this.serviceId = serviceId;
		this.image = image;
		this.serviceName = serviceName;
		this.serviceProvider = serviceProvider;
		this.mobileNumber = mobileNumber;
		this.email = email;
		this.address = address;
	}



	public int getServiceId() {
		return serviceId;
	}



	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}



	public String getImage() {
		return image;
	}



	public void setImage(String image) {
		this.image = image;
	}



	public String getServiceName() {
		return serviceName;
	}



	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}



	public String getServiceProvider() {
		return serviceProvider;
	}



	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}



	public String getMobileNumber() {
		return mobileNumber;
	}



	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}



	public String getEmail() {
		return email;
	}



	public void setEmail(String email) {
		this.email = email;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	@Override
	public String toString() {
		return "Service [serviceId=" + serviceId + ", image=" + image + ", serviceName=" + serviceName
				+ ", serviceProvider=" + serviceProvider + ", mobileNumber=" + mobileNumber + ", email=" + email
				+ ", address=" + address + "]";
	}



}
