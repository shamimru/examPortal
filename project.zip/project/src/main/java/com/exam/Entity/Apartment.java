package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Apartment {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int apartment_table_id;


	int society_id;
	int building_id;
	int apartment_id;
	int total_room;
	String owener_id;
	double rent_per_month;
	boolean isRented;
	int rent_id;

	public Apartment() {
		super();
	}

	public Apartment(int apartment_table_id, int society_id, int building_id, int apartment_id, String owener_id,
			double rent_per_month, boolean isRented, int rent_id) {
		super();
		this.apartment_table_id = apartment_table_id;
		this.society_id = society_id;
		this.building_id = building_id;
		this.apartment_id = apartment_id;
		this.owener_id = owener_id;
		this.rent_per_month = rent_per_month;
		this.isRented = isRented;
		this.rent_id = rent_id;
	}

	public int getApartment_table_id() {
		return apartment_table_id;
	}

	public void setApartment_table_id(int apartment_table_id) {
		this.apartment_table_id = apartment_table_id;
	}

	public int getSociety_id() {
		return society_id;
	}

	public void setSociety_id(int society_id) {
		this.society_id = society_id;
	}

	public int getBuilding_id() {
		return building_id;
	}

	public void setBuilding_id(int building_id) {
		this.building_id = building_id;
	}

	public int getApartment_id() {
		return apartment_id;
	}

	public void setApartment_id(int apartment_id) {
		this.apartment_id = apartment_id;
	}

	public String getOwener_id() {
		return owener_id;
	}

	public void setOwener_id(String owener_id) {
		this.owener_id = owener_id;
	}

	public double getRent_per_month() {
		return rent_per_month;
	}

	public void setRent_per_month(double rent_per_month) {
		this.rent_per_month = rent_per_month;
	}

	public boolean isRented() {
		return isRented;
	}

	public void setRented(boolean isRented) {
		this.isRented = isRented;
	}

	public int getRent_id() {
		return rent_id;
	}

	public void setRent_id(int rent_id) {
		this.rent_id = rent_id;
	}

	@Override
	public String toString() {
		return "Apartment [apartment_table_id=" + apartment_table_id + ", society_id=" + society_id + ", building_id="
				+ building_id + ", apartment_id=" + apartment_id + ", owener_id=" + owener_id + ", rent_per_month="
				+ rent_per_month + ", isRented=" + isRented + ", rent_id=" + rent_id + "]";
	}




}
