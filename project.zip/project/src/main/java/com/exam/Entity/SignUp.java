package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class SignUp {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int signUp_id;
	
	String name;
	String user_name;
	String password;
	public SignUp() {
		super();
	}
	public SignUp(int signUp_id, String name, String user_name, String password) {
		super();
		this.signUp_id = signUp_id;
		this.name = name;
		this.user_name = user_name;
		this.password = password;
	}
	public int getSignUp_id() {
		return signUp_id;
	}
	public void setSignUp_id(int signUp_id) {
		this.signUp_id = signUp_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "SignUp [signUp_id=" + signUp_id + ", name=" + name + ", user_name=" + user_name + ", password="
				+ password + "]";
	}
	
	
	

}
