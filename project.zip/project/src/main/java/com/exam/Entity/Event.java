package com.exam.Entity;

import java.sql.Time;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Event {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int eventId;
	String image;
	String eventTitle;
	
	@Temporal(TemporalType.DATE)
	Date eventDate;
	
	@Temporal(TemporalType.DATE)
	Date eventEndDate;
	
	
	    
	@Temporal(TemporalType.TIME)
	Time startTime;
	
	@Temporal(TemporalType.TIME)
	Time endTime;
	
	String  whoMakeEvent;
	String  memberId;
	String  status;
	
	public Event() {
		super();
	}
	public Event(int eventId, String image, String eventTitle, Date eventDate, Date eventEndDate, Time startTime,
			Time endTime, String whoMakeEvent, String memberId, String status) {
		super();
		this.eventId = eventId;
		this.image = image;
		this.eventTitle = eventTitle;
		this.eventDate = eventDate;
		this.eventEndDate = eventEndDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.whoMakeEvent = whoMakeEvent;
		this.memberId = memberId;
		this.status = status;
	}
	@Override
	public String toString() {
		return "Event [eventId=" + eventId + ", image=" + image + ", eventTitle=" + eventTitle + ", eventDate="
				+ eventDate + ", eventEndDate=" + eventEndDate + ", startTime=" + startTime + ", endTime=" + endTime
				+ ", whoMakeEvent=" + whoMakeEvent + ", memberId=" + memberId + ", status=" + status + "]";
	}
	
	
	

}
