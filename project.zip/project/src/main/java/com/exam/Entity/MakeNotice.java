package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class MakeNotice {

	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int noticeId;
	
	String image;
	String notice;
	
	@Temporal(TemporalType.DATE)
	Date noticeStartDate;
	
	@Temporal(TemporalType.DATE)
	Date noticeEndDate;
	String noticeType;
	String status;
	String description;
	String whoMakeNotice;
	String memberId;
	public MakeNotice() {
		super();
	}
	public MakeNotice(int noticeId, String image, String notice, Date noticeStartDate, Date noticeEndDate,
			String noticeType, String status, String description, String whoMakeNotice, String memberId) {
		super();
		this.noticeId = noticeId;
		this.image = image;
		this.notice = notice;
		this.noticeStartDate = noticeStartDate;
		this.noticeEndDate = noticeEndDate;
		this.noticeType = noticeType;
		this.status = status;
		this.description = description;
		this.whoMakeNotice = whoMakeNotice;
		this.memberId = memberId;
	}
	public int getNoticeId() {
		return noticeId;
	}
	public void setNoticeId(int noticeId) {
		this.noticeId = noticeId;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getNotice() {
		return notice;
	}
	public void setNotice(String notice) {
		this.notice = notice;
	}
	public Date getNoticeStartDate() {
		return noticeStartDate;
	}
	public void setNoticeStartDate(Date noticeStartDate) {
		this.noticeStartDate = noticeStartDate;
	}
	public Date getNoticeEndDate() {
		return noticeEndDate;
	}
	public void setNoticeEndDate(Date noticeEndDate) {
		this.noticeEndDate = noticeEndDate;
	}
	public String getNoticeType() {
		return noticeType;
	}
	public void setNoticeType(String noticeType) {
		this.noticeType = noticeType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getWhoMakeNotice() {
		return whoMakeNotice;
	}
	public void setWhoMakeNotice(String whoMakeNotice) {
		this.whoMakeNotice = whoMakeNotice;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	@Override
	public String toString() {
		return "MakeNotice [noticeId=" + noticeId + ", image=" + image + ", notice=" + notice + ", noticeStartDate="
				+ noticeStartDate + ", noticeEndDate=" + noticeEndDate + ", noticeType=" + noticeType + ", status="
				+ status + ", description=" + description + ", whoMakeNotice=" + whoMakeNotice + ", memberId="
				+ memberId + "]";
	}
	
	
	
}
