import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-complaints',
  templateUrl: './complaints.component.html',
  styleUrls: ['./complaints.component.css']
})
export class ComplaintsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  complaints: any = {

    "complaint_id": "",
    "complaint_nature": "",
    "complaint_title": "",
    "complaint_by": "",
    "complain_date": "",
    "complaint_time": "",
    "complaint_status": "",
    "description": "",

    "apartment_no": "",
    "building_no": "",

    "resolustion": "",
    "resolve_by": "",
    "resolve_date": "",
    "resolve_time": ""

  }

  saveComplaints(){
    
  }

}
