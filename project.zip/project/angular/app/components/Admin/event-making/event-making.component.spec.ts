import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EventMakingComponent } from './event-making.component';

describe('EventMakingComponent', () => {
  let component: EventMakingComponent;
  let fixture: ComponentFixture<EventMakingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EventMakingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EventMakingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
