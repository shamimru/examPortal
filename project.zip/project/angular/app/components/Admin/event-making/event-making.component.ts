import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-making',
  templateUrl: './event-making.component.html',
  styleUrls: ['./event-making.component.css']
})
export class EventMakingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  Events: any = {
    "eventId": "",
    "image": "",
    "eventTitle": "",
    "eventDate": "",
    'eventEndDate': "",
    'startTime': "",
    "endTime": "",
    "whoMakeEvent": "",
    "memberId":"",
    "status": ""
  }

  eventSubmit(){
    
  }
}
