import { Component, OnInit } from '@angular/core';
import { EmployeeMaster } from 'src/app/Model/employee-master';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-empoyee-maseter',
  templateUrl: './empoyee-maseter.component.html',
  styleUrls: ['./empoyee-maseter.component.css']
})
export class EmpoyeeMaseterComponent implements OnInit {

  constructor(
    private service: ServiceService
  ) { }

  ngOnInit(): void {
  }

  emp_code:any;
  emp_name:any;
  gardian:any;
  spuse:any;
  joiningDate:any;
  dateOfBirth:any;
  jobType:any;
  department:any;
  designation:any;
  contactNumber:any;
  email:any;
  referenceName:any;
  referenceNumber:any;

	

  employee_object:any;

  employee_Submit(){
    this.employee_object=new EmployeeMaster("",this.emp_name,this.gardian,this.spuse,this.joiningDate,this.dateOfBirth,this.jobType,this.department,this.designation,this.contactNumber,this.email,this.referenceName,this.referenceNumber)

    this.service.saveEmployeeMaster(this.employee_object).subscribe((response)=>{

    })

  }

}
