import { Component, OnInit } from '@angular/core';
import { AssetsInfo } from 'src/app/Model/assets-info';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-assets-master',
  templateUrl: './assets-master.component.html',
  styleUrls: ['./assets-master.component.css']
})
export class AssetsMasterComponent implements OnInit {

  constructor(
    private service : ServiceService
  ) { }

  ngOnInit(): void {
  }


  assets_id: any;
  code: any;
  assets_Name: any;
  mobile_Number: any;
  assets_description: any;
  use_Of_assets: any;
  location_of_use: any;
  unit_price: any;
  quantity: any;
  total_price: any;
  serviceCenter_name: any;
  acquisition_Date: any;
  assets_commense_date: any;
  return_date: any;


  assets_object:any;
  assetsSubmit() {

    this.assets_object=new AssetsInfo("",this.code,this.assets_Name,this.mobile_Number,this.assets_description,this.use_Of_assets,this.location_of_use,this.unit_price,this.quantity, this.total_price,this.serviceCenter_name,this.acquisition_Date,this.assets_commense_date,this.return_date);


    this.service.saveAssetsInfo(this.assets_object).subscribe((response)=>{
      
    })

  }

}
