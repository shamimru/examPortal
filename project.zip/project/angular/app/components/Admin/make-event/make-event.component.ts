import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-make-event',
  templateUrl: './make-event.component.html',
  styleUrls: ['./make-event.component.css']
})
export class MakeEventComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }


  makeEvent: any = {
    "eventId": "",
    "image": "",
    'eventTitle': "",
    'eventDate': "",
    'eventEndDate': "",
    'startTime': "",
    'endTime': "",
    'whoMakeEvent': "",
    'memberId': "",
    'status': "",
  }

  eventSubmit(){
    this.service.saveEvent(this.makeEvent).subscribe((response)=>{

    })
  }
}
