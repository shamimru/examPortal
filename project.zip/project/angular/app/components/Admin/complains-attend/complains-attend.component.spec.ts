import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComplainsAttendComponent } from './complains-attend.component';

describe('ComplainsAttendComponent', () => {
  let component: ComplainsAttendComponent;
  let fixture: ComponentFixture<ComplainsAttendComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComplainsAttendComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ComplainsAttendComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
