import { Component, OnInit } from '@angular/core';
import { SocietyInformation } from 'src/app/Model/society-information';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-society-information',
  templateUrl: './society-information.component.html',
  styleUrls: ['./society-information.component.css']
})
export class SocietyInformationComponent implements OnInit {

  society_id:any;
  full_name:any;
  long_Name:any;
  email:any;
  address:any;
  city:any;
  zip_code:any;

  society_information_object:any;

  constructor(
    private myservice:ServiceService
  ) { }

  ngOnInit(): void {
  }

  soc_info_submit(){
    this.society_information_object=new SocietyInformation("",this.full_name,this.long_Name,this.email,this.address,this.city,this.zip_code);

    this.myservice.soc_info(this.society_information_object).subscribe((response)=>{

    })

    this.myservice.sayHello()


  }

}
