import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-staff-info',
  templateUrl: './staff-info.component.html',
  styleUrls: ['./staff-info.component.css']
})
export class StaffInfoComponent implements OnInit {
allHomeStaffInfo:any
  constructor(
    private service:ServiceService
  ) { 
    this.service.getHomeStaffInfo().subscribe((response)=>{
      this.allHomeStaffInfo=response

    })
  }

  ngOnInit(): void {
  }

}
