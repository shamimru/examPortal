import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-service-provider',
  templateUrl: './service-provider.component.html',
  styleUrls: ['./service-provider.component.css']
})
export class ServiceProviderComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }

  ServiceProvider:any={
     "serviceId":"",
     'image':"",
     'serviceName':"",
     'serviceProvider':"",
     "mobileNumber":"",
     "email":"",
     "address":"",
   
  }

  serviceProviderSubmit(){
    this.service.saveServiceProvider(this.ServiceProvider).subscribe((response)=>{

    })
  }

}
