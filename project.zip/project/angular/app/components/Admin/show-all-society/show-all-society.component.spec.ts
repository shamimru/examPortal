import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowAllSocietyComponent } from './show-all-society.component';

describe('ShowAllSocietyComponent', () => {
  let component: ShowAllSocietyComponent;
  let fixture: ComponentFixture<ShowAllSocietyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowAllSocietyComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowAllSocietyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
