import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-show-building-info',
  templateUrl: './show-building-info.component.html',
  styleUrls: ['./show-building-info.component.css']
})
export class ShowBuildingInfoComponent implements OnInit {

  constructor(
    private service : ServiceService
  ) { 
    this.service.showAllBuildingInfo().subscribe((response)=>{
      this.getAllbuilding=response
    })
  }

  ngOnInit(): void {
  }

  getAllbuilding:any;

}
