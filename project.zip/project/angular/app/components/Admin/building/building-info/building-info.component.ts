import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-info',
  templateUrl: './building-info.component.html',
  styleUrls: ['./building-info.component.css']
})
export class BuildingInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
