import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-details',
  templateUrl: './building-details.component.html',
  styleUrls: ['./building-details.component.css']
})
export class BuildingDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
