import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingStaffComponent } from './building-staff.component';

describe('BuildingStaffComponent', () => {
  let component: BuildingStaffComponent;
  let fixture: ComponentFixture<BuildingStaffComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuildingStaffComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuildingStaffComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
