import { Component, OnInit } from '@angular/core';
import { CostCenterMaster } from 'src/app/Model/cost-center-master';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-cost-center',
  templateUrl: './cost-center.component.html',
  styleUrls: ['./cost-center.component.css']
})
export class CostCenterComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }

  cost_id:any;
  cost_code:any;
  name:any;
  descriptin:any;
  remark:any;

  costCenterMaster_Object:any;
  saveCostMaster(){

    this.costCenterMaster_Object = new CostCenterMaster("",this.cost_code,this.name,this.descriptin,this.remark);

    this.service.saveCostAccountMaster(this.costCenterMaster_Object).subscribe((response)=>{

    },
  (error)=>{
    alert("error")
  })

  }
}
