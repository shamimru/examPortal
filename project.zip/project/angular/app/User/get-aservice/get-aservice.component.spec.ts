import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAServiceComponent } from './get-aservice.component';

describe('GetAServiceComponent', () => {
  let component: GetAServiceComponent;
  let fixture: ComponentFixture<GetAServiceComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetAServiceComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetAServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
