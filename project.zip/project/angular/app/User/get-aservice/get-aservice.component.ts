import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-aservice',
  templateUrl: './get-aservice.component.html',
  styleUrls: ['./get-aservice.component.css']
})
export class GetAServiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
