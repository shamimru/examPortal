import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-show-ser-provider-info',
  templateUrl: './show-ser-provider-info.component.html',
  styleUrls: ['./show-ser-provider-info.component.css']
})
export class ShowSerProviderInfoComponent implements OnInit {

  getAllserviceProviderData:any
  constructor(
    private service:ServiceService
  ) { 
 this.service.getServiceProviderData().subscribe((response)=>{
  this.getAllserviceProviderData=response
 })
  }

  ngOnInit(): void {
  }


  ServiceProvider:any={
    "serviceId":"",
    'image':"",
    'serviceName':"",
    'serviceProvider':"",
    "mobileNumber":"",
    "email":"",
    "address":"",
  
 }
}
