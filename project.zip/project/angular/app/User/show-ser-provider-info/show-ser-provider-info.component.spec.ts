import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowSerProviderInfoComponent } from './show-ser-provider-info.component';

describe('ShowSerProviderInfoComponent', () => {
  let component: ShowSerProviderInfoComponent;
  let fixture: ComponentFixture<ShowSerProviderInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowSerProviderInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowSerProviderInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
