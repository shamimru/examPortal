import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/MyService/user.service';

@Component({
  selector: 'app-notice-show',
  templateUrl: './notice-show.component.html',
  styleUrls: ['./notice-show.component.css']
})
export class NoticeShowComponent implements OnInit {

  getAllNotice:any;
  constructor(
    private userService:UserService
  ) {
this.userService.getAllNotice().subscribe((respone)=>{
  this.getAllNotice=respone;
})
   }

  ngOnInit(): void {
  }

  showAllNotice (){

  }
  makeNotice:any={
  
    "noticeId":"",
    "image":"",
    "notice":"",
    "noticeStartDate":"",
    "noticeEndDate":"",
    "noticeType":"",
    "status":"",
    "description":"",
    "whoMakeNotice":"",
    "memberId":""
  }
}
