import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }

  url="http://localhost:8080";

  getAllNotice():Observable<any>{
    this.url="http://localhost:8080/admin/getAllNotice";
    return this.http.get<any>(this.url)
  }
}
