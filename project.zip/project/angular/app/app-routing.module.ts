import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SocietyInformationComponent } from './components/Admin/society-information/society-information.component';
import { AccountMasterComponent } from './components/account-master/account-master.component';
import { CostCenterComponent } from './components/Admin/cost-center/cost-center.component';
import { AssetsMasterComponent } from './components/Admin/assets-master/assets-master.component';
import { ComHomepageComponent } from './commons/com-homepage/com-homepage.component';
import { AreaSqFtRatesComponent } from './components/Admin/area-sq-ft-rates/area-sq-ft-rates.component';
import { DepartmentComponent } from './components/Admin/department/department.component';
import { EmpoyeeMaseterComponent } from './components/Admin/empoyee-maseter/empoyee-maseter.component';
import { MebmersInfoComponent } from './components/Admin/mebmers-info/mebmers-info.component';
import { HomeStaffComponent } from './components/Admin/MemberOfStaffInfo/home-staff/home-staff.component';
import { MemberListComponent } from './components/Admin/member-list/member-list.component';
import { AllotmentComponent } from './components/Admin/allotment/allotment.component';
import { VehicleDetailsComponent } from './components/Admin/vehicle-details/vehicle-details.component';
import { PersonalComponent } from './components/gallery/personal/personal.component';
import { MonthlyFeeComponent } from './components/Admin/monthly-fee/monthly-fee.component';
import { AccountVoucherComponent } from './components/account-voucher/account-voucher.component';
import { PendingFeeComponent } from './components/Admin/pending-fee/pending-fee.component';
import { BillCostCenterComponent } from './components/Admin/bill-cost-center/bill-cost-center.component';
import { BillAccountLedgerComponent } from './components/Admin/bill-account-ledger/bill-account-ledger.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { SendInvitationComponent } from './components/Admin/send-invitation/send-invitation.component';
import { AnnouncementComponent } from './components/Admin/announcement/announcement.component';
import { ShowAllSocietyComponent } from './components/Admin/show-all-society/show-all-society.component';
import { BuildingComponent } from './components/Admin/building/building.component';
import { ShowBuildingInfoComponent } from './components/Admin/building/show-building-info/show-building-info.component';
import { ShowMemberDetailsComponent } from './components/Admin/show-member-details/show-member-details.component';
import { ViewMemberDetailsComponent } from './components/Admin/view-member-details/view-member-details.component';
import { StaffInfoComponent } from './components/Admin/MemberOfStaffInfo/staff-info/staff-info.component';
import { BuildingDetailsComponent } from './components/Admin/building/building-details/building-details.component';
import { BuildingStaffComponent } from './components/Admin/building/building-staff/building-staff.component';
import { AddMemberComponent } from './components/Admin/building/add-member/add-member.component';
import { LogInComponent } from './commons/log-in/log-in.component';
import { SignUpComponent } from './commons/sign-up/sign-up.component';
import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './User/user-dashboard/user-dashboard.component';
import { NoticeBoardComponent } from './components/Admin/notice-board/notice-board.component';
import { MakeNoticeComponent } from './components/Admin/make-notice/make-notice.component';
import { NoticeShowComponent } from './User/notice-show/notice-show.component';
import { MakeEventComponent } from './components/Admin/make-event/make-event.component';
import { ServiceProviderComponent } from './components/Admin/service-provider/service-provider.component';
import { ShowSerProviderInfoComponent } from './User/show-ser-provider-info/show-ser-provider-info.component';
import { GetAServiceComponent } from './User/get-aservice/get-aservice.component';


const routes: Routes = [
  {
    path: "", component: ComHomepageComponent, pathMatch: "full"

  },
  {
    path: "signin", component: LogInComponent
  },
  {
    path: "signUp", component: SignUpComponent
  },
  // {path:"",component:DashboardComponent},

  {
    path: "Admin", component: DashboardComponent,
    children: [

      {
        path: "societyInfo", component: SocietyInformationComponent
      },
      {
        path: "accMaster", component: AccountMasterComponent
      },
      {
        path: "costCenter", component: CostCenterComponent
      },
      {
        path: "assetsMaster", component: AssetsMasterComponent
      },
      {
        path: "area", component: AreaSqFtRatesComponent
      },
      {
        path: "department", component: DepartmentComponent
      },
      {
        path: "employee", component: EmpoyeeMaseterComponent

      },
      {
        path: "membersInfo", component: MebmersInfoComponent
      },
      {
        path: "homeStaff", component: HomeStaffComponent
      },
      {
        path: "memberList", component: MemberListComponent
      },
      {
        path: "noticeBoard", component: NoticeBoardComponent
      },
      {
        path: "makeNotice",
        component: MakeNoticeComponent
      },
      {
        path: "allotment", component: AllotmentComponent
      },
      {
        path: "vehicle", component: VehicleDetailsComponent
      },
      {
        path: "personal", component: PersonalComponent
      },
      {
        path: "monthlyFee", component: MonthlyFeeComponent
      },
      {
        path: "accVoucher", component: AccountVoucherComponent
      },
      {
        path: "pendingList", component: PendingFeeComponent
      },
      {
        path: "constCenterLedger", component: BillCostCenterComponent
      },
      {
        path: "accountLedger", component: BillAccountLedgerComponent
      },
      {
        path: "complains", component: ComplaintsComponent
      },
      {
        path: "sendInvitation", component: SendInvitationComponent
      },
      {
        path: "announcement", component: AnnouncementComponent
      },
      {
        path: "showAllSociety", component: ShowAllSocietyComponent
      },
      {
        path: "buildingInfo", component: BuildingComponent
      },
      {
        path: "showBuildingInfo", component: ShowBuildingInfoComponent
      },
      {
        path: "showMemberInfo", component: ShowMemberDetailsComponent
      },
      {
        path: "ViewMemberDetails/:member_id", component: ViewMemberDetailsComponent
      },
      {
        path: "StaffInfo", component: StaffInfoComponent
      },
      { path: "noticeBoard", component: NoticeBoardComponent },
      {
        path: "makeEvent", component: MakeEventComponent
      },
      {
        path: "serviceProvider", component: ServiceProviderComponent
      },


    ]
  },

  // normal user 

  {
    path: "user", component: UserDashboardComponent,

    children: [
      { path: "showNotice", component: NoticeShowComponent },
      { path: "serProvider", component: ShowSerProviderInfoComponent},
      {path:"getaService/:serviceId",component:GetAServiceComponent}

    ]

    
  },
  // {path:"getaService/:serviceId",component:GetAServiceComponent},

  

  {
    path: "buildingDetails/:building_id", component: BuildingDetailsComponent,
    children: [

      {
        path: "memberDetails", component: ShowMemberDetailsComponent
      },
      {
        path: "buildingStaff", component: BuildingStaffComponent
      },
      {
        path: "addMember", component: AddMemberComponent

      },





    ]
  },




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
