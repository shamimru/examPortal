import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './commons/header/header.component';
import { FooterComponent } from './commons/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule} from '@angular/material/card';
import { SidebarComponent } from './components/Admin/sidebar/sidebar.component';
import {MatListModule} from '@angular/material/list';
import { HomeComponent } from './components/home/home.component';
import {MatButtonModule} from '@angular/material/button';
import { SocietyInformationComponent } from './components/Admin/society-information/society-information.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { AccountMasterComponent } from './components/account-master/account-master.component';
import { CostCenterComponent } from './components/Admin/cost-center/cost-center.component';
import { AssetsMasterComponent } from './components/Admin/assets-master/assets-master.component';
import { AreaSqFtRatesComponent } from './components/Admin/area-sq-ft-rates/area-sq-ft-rates.component';
import { DepartmentComponent } from './components/Admin/department/department.component';
import { EmpoyeeMaseterComponent } from './components/Admin/empoyee-maseter/empoyee-maseter.component';
import { HelplineComponent } from './components/helpline/helpline.component';
import { ParkingAreaComponent } from './components/Admin/parking-area/parking-area.component';
import { MebmersInfoComponent } from './components/Admin/mebmers-info/mebmers-info.component';
import { HomeStaffComponent } from './components/Admin/MemberOfStaffInfo/home-staff/home-staff.component';
import { MemberListComponent } from './components/Admin/member-list/member-list.component';
import { NoticeBoardComponent } from './components/Admin/notice-board/notice-board.component';
import { AllotmentComponent } from './components/Admin/allotment/allotment.component';
import { VehicleDetailsComponent } from './components/Admin/vehicle-details/vehicle-details.component';
import { PersonalComponent } from './components/gallery/personal/personal.component';
import { MonthlyFeeComponent } from './components/Admin/monthly-fee/monthly-fee.component';
import { AccountVoucherComponent } from './components/account-voucher/account-voucher.component';
import { PendingFeeComponent } from './components/Admin/pending-fee/pending-fee.component';
import { BillCostCenterComponent } from './components/Admin/bill-cost-center/bill-cost-center.component';
import { BillAccountLedgerComponent } from './components/Admin/bill-account-ledger/bill-account-ledger.component';
import { ServiceComplainsComponent } from './components/Admin/service-complains/service-complains.component';
import { ComplainsAttendComponent } from './components/Admin/complains-attend/complains-attend.component';
import { SendInvitationComponent } from './components/Admin/send-invitation/send-invitation.component';
import { AnnouncementComponent } from './components/Admin/announcement/announcement.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from  '@angular/common/http';
import { ServiceService } from './MyService/service.service';
import { BuildingComponent } from './components/Admin/building/building.component';
import { ShowAllSocietyComponent } from './components/Admin/show-all-society/show-all-society.component';
import { BuildingInfoComponent } from './components/Admin/building/building-info/building-info.component';
import { ShowBuildingInfoComponent } from './components/Admin/building/show-building-info/show-building-info.component';
import { BuildingDetailsComponent } from './components/Admin/building/building-details/building-details.component';
import { BuildingsSideNaveComponent } from './components/Admin/building/buildings-side-nave/buildings-side-nave.component';
import { ShowMemberDetailsComponent } from './components/Admin/show-member-details/show-member-details.component';
import { BuildingWelcomeComponent } from './components/Admin/building/building-welcome/building-welcome.component';
import { BuildingStaffComponent } from './components/Admin/building/building-staff/building-staff.component';
import { AddMemberComponent } from './components/Admin/building/add-member/add-member.component';
import { ViewMemberDetailsComponent } from './components/Admin/view-member-details/view-member-details.component';
import { StaffInfoComponent } from './components/Admin/MemberOfStaffInfo/staff-info/staff-info.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { SignUpComponent } from './commons/sign-up/sign-up.component';
import { LogInComponent } from './commons/log-in/log-in.component';
import { ComHomepageComponent } from './commons/com-homepage/com-homepage.component';
import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './User/user-dashboard/user-dashboard.component';
import { UserSidenavComponent } from './User/user-sidenav/user-sidenav.component';
import { MakeNoticeComponent } from './components/Admin/make-notice/make-notice.component';
import { NoticeShowComponent } from './User/notice-show/notice-show.component';
import { UserService } from './MyService/user.service';
import { EventMakingComponent } from './components/Admin/event-making/event-making.component';
import { MakeEventComponent } from './components/Admin/make-event/make-event.component';
import { ServiceProviderComponent } from './components/Admin/service-provider/service-provider.component';
import { ShowSerProviderInfoComponent } from './User/show-ser-provider-info/show-ser-provider-info.component';
import { GetAServiceComponent } from './User/get-aservice/get-aservice.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    HomeComponent,
    SocietyInformationComponent,
    AccountMasterComponent,
    CostCenterComponent,
    AssetsMasterComponent,
    AreaSqFtRatesComponent,
    DepartmentComponent,
    EmpoyeeMaseterComponent,
    HelplineComponent,
    DashboardComponent,
    ParkingAreaComponent,
    MebmersInfoComponent,
    HomeStaffComponent,
    MemberListComponent,
    NoticeBoardComponent,
    AllotmentComponent,
    VehicleDetailsComponent,
    PersonalComponent,
    MonthlyFeeComponent,
    AccountVoucherComponent,
    PendingFeeComponent,
    BillCostCenterComponent,
    BillAccountLedgerComponent,
    ServiceComplainsComponent,
    ComplainsAttendComponent,
    SendInvitationComponent,
    AnnouncementComponent,
    BuildingComponent,
    ShowAllSocietyComponent,
    BuildingInfoComponent,
    ShowBuildingInfoComponent,
    BuildingDetailsComponent,
    BuildingsSideNaveComponent,
    ShowMemberDetailsComponent,
    BuildingWelcomeComponent,
    BuildingStaffComponent,
    AddMemberComponent,
    ViewMemberDetailsComponent,
    StaffInfoComponent,
    ComplaintsComponent,
    SignUpComponent,
  LogInComponent,
  ComHomepageComponent,
  UserDashboardComponent,
  UserSidenavComponent,
  MakeNoticeComponent,
  NoticeShowComponent,
  EventMakingComponent,
  MakeEventComponent,
  ServiceProviderComponent,
  ShowSerProviderInfoComponent,
  GetAServiceComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    HttpClientModule
    

  ],
  providers: [ServiceService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
