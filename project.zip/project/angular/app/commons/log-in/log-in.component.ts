import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  constructor(
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  signIn:any={
    "user_name":"",
    "password":""
  }
  signIn_to_database(){
    if(this.signIn.user_name=="" || this.signIn.user_name == null && this.signIn.password == "" || this.signIn.password == null){
      return
    }

    this.router.navigate(["Admin"])

    

  }
}
