import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-com-homepage',
  templateUrl: './com-homepage.component.html',
  styleUrls: ['./com-homepage.component.css']
})
export class ComHomepageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
