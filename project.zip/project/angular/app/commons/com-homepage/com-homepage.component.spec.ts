import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComHomepageComponent } from './com-homepage.component';

describe('ComHomepageComponent', () => {
  let component: ComHomepageComponent;
  let fixture: ComponentFixture<ComHomepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComHomepageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ComHomepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
