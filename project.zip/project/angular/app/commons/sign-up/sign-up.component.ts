import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  constructor(
    private service:ServiceService,
    private router:Router

  ) { }

  ngOnInit(): void {
  }

  signUp:any={
    "name":"",
    "user_name":"",
    "password":"",
    
  }

  signUp_to_database(){
    if(this.signUp.user_name == "" || this.signUp.user_name== null  && this.signUp.password == "" || this.signUp.password==null) {
      return 
    }
    this.service.signUp(this.signUp).subscribe((response)=>{

      this.router.navigateByUrl("signin");
    })
  }

}
