export class SocietyInformation {

    society_id:any;
	 full_name:any;
	 long_Name:any;
	 email:any;
	 address:any;
	 city:any;
	 zip_code:any;

     constructor(society_id:any, fullName:any,longName:any,email:any,address:any,city:any,zip_code:any){

        this.society_id=society_id;
        this.full_name=fullName;
        this.long_Name=longName;
        this.email=email;
        this.address=address;
        this.city=city;
        this.zip_code=zip_code;
     }
}
