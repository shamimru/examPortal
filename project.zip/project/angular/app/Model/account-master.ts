export class AccountMaster {


    acc_id: any;
    accountNumber: any;
    name: any;
    transferMoneyAccount: any;
    description: any;
    remark: any;


    constructor(acc_id:any,accountNumber: any, name: any, transferMoneyAccount: any, description: any,  remark: any   ) {

        this.acc_id=acc_id;
        this.accountNumber=accountNumber;
        this.name=name;
        this.transferMoneyAccount=transferMoneyAccount;
        this.description=description;
        this.remark=remark
    }
}
