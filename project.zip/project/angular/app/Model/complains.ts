export class Complains {

     TicketNo:any;
	
	 complain_date:any;
	 member_code:any;
	 member_name:any;
	 complains_type:any;
	 brifly_describe:any;
	 elaborate_problem:any;
     constructor( TicketNo:any, complain_date:any,member_code:any, member_name:any,complains_type:any,brifly_describe:any, elaborate_problem:any){
        this.TicketNo=TicketNo;
        this.complain_date=complain_date;
        this.member_code=member_code;
        this.member_name=member_name;
        this.complains_type=complains_type;
        this.brifly_describe=brifly_describe;
        this.elaborate_problem=elaborate_problem;

        

     }


}
