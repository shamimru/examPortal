package com.exam.Repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


import com.exam.Entity.SignUp;

public class SignInDAO {
	Connection con;
	PreparedStatement stm;

	public SignInDAO() {
		// TODO Auto-generated constructor stub
	}
	
	public SignUp signIn(String username, String password, String role) {
		
		SignUp signin=null;
			try {
//				System.out.println(con);
				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/residential_society_management", "root", "root");
				stm = con.prepareStatement("select * from sign_up where user_name=? and password=? and role=?");
//				sign_id, name, password, user_name
				stm.setString(1, username);
				stm.setString(2, password);
				stm.setString(3, role);

				ResultSet re = stm.executeQuery();
				while (re.next()) {
//					int signId;
//					private String name;
//					private String user_name;
//					private String password;
//					private String role;
					
					
//					sign_id, name, password, role, user_name
					signin = new SignUp(re.getInt("sign_id"), re.getString("name"), re.getString("password"), re.getString("role"), re.getString("user_name"));
							
				}

				con.close();
			} catch (Exception e) {
				System.out.println(e);
			}

			return signin;
		
		}
	}


