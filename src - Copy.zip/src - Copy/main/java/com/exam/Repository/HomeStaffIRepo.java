package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.HomeStaffInfo;

@Repository
public interface HomeStaffIRepo extends CrudRepository<HomeStaffInfo, Integer>{

}
