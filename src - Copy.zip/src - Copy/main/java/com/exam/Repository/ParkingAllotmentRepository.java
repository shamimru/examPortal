package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.ParkingAllotment;

@Repository
public interface ParkingAllotmentRepository extends CrudRepository<ParkingAllotment, Integer>{

}
