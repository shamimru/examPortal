package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.ComplainsLog;

@Repository
public interface Complains_logRepository extends CrudRepository<ComplainsLog, Integer>{

}
