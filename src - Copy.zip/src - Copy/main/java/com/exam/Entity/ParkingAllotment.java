package com.exam.Entity;

import com.fasterxml.jackson.annotation.JsonIgnoreType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class ParkingAllotment {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int allotmentNo;
	
	String vehicle_registration_no;
	String member_code;
	String memberName;
	String parking_area;
	String vehicle_type;
	public ParkingAllotment() {
		super();
	}
	public ParkingAllotment(int allotmentNo, String vehicle_registration_no, String member_code, String memberName,
			String parking_area, String vehicle_type) {
		super();
		this.allotmentNo = allotmentNo;
		this.vehicle_registration_no = vehicle_registration_no;
		this.member_code = member_code;
		this.memberName = memberName;
		this.parking_area = parking_area;
		this.vehicle_type = vehicle_type;
	}
	public int getAllotmentNo() {
		return allotmentNo;
	}
	public void setAllotmentNo(int allotmentNo) {
		this.allotmentNo = allotmentNo;
	}
	public String getVehicle_registration_no() {
		return vehicle_registration_no;
	}
	public void setVehicle_registration_no(String vehicle_registration_no) {
		this.vehicle_registration_no = vehicle_registration_no;
	}
	public String getMember_code() {
		return member_code;
	}
	public void setMember_code(String member_code) {
		this.member_code = member_code;
	}
	public String getMemberName() {
		return memberName;
	}
	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}
	public String getParking_area() {
		return parking_area;
	}
	public void setParking_area(String parking_area) {
		this.parking_area = parking_area;
	}
	public String getVehicle_type() {
		return vehicle_type;
	}
	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}
	@Override
	public String toString() {
		return "ParkingAllotment [allotmentNo=" + allotmentNo + ", vehicle_registration_no=" + vehicle_registration_no
				+ ", member_code=" + member_code + ", memberName=" + memberName + ", parking_area=" + parking_area
				+ ", vehicle_type=" + vehicle_type + "]";
	}
	
	
}
