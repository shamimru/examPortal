package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class SignUp {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
   
	int signId;
	private String name;
	private String user_name;
	private String password;
	private String role;
	
	
	public SignUp() {
		// TODO Auto-generated constructor stub
	}


	public SignUp(int signId, String name, String user_name, String password, String role) {
		super();
		this.signId = signId;
		this.name = name;
		this.user_name = user_name;
		this.password = password;
		this.role = role;
	}


	public int getSignId() {
		return signId;
	}


	public void setSignId(int signId) {
		this.signId = signId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUser_name() {
		return user_name;
	}


	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString() {
		return "SignUp [signId=" + signId + ", name=" + name + ", user_name=" + user_name + ", password=" + password
				+ ", role=" + role + "]";
	}
	
}
