package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class SignIn {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private String signIn_id;
	private String user_name;
	private String password;
	public SignIn() {
		// TODO Auto-generated constructor stub
	}
	public SignIn(String signIn_id, String user_name, String password) {
		super();
		this.signIn_id = signIn_id;
		this.user_name = user_name;
		this.password = password;
	}
	public String getSignIn_id() {
		return signIn_id;
	}
	public void setSignIn_id(String signIn_id) {
		this.signIn_id = signIn_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "SignIn [signIn_id=" + signIn_id + ", user_name=" + user_name + ", password=" + password + "]";
	}

	
	
}
