package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class RentTable {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	int rent_id;
	@Temporal(TemporalType.DATE)
	Date rent_date;
	@Temporal(TemporalType.DATE)
	Date release_date;
	double rent_per_month;
	double advance_rent;
	int tenant_id;
	
	
}
