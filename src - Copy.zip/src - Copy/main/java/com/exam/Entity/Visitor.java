package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Visitor {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int visitor_id;
	String visitor_name;
	String visitor_phone;
	
	int tenant_id;
	 
	String tenant_name;
	String tenant_phone;
	
	@Temporal(TemporalType.DATE)
	Date entry_date;
	
	@Temporal(TemporalType.DATE)
	Date out_date;
	int total_day_stay;
	String reason;
	public Visitor() {
		super();
	}
	public Visitor(int visitor_id, String visitor_name, String visitor_phone, int tenant_id, String tenant_name,
			String tenant_phone, Date entry_date, Date out_date, int total_day_stay, String reason) {
		super();
		this.visitor_id = visitor_id;
		this.visitor_name = visitor_name;
		this.visitor_phone = visitor_phone;
		this.tenant_id = tenant_id;
		this.tenant_name = tenant_name;
		this.tenant_phone = tenant_phone;
		this.entry_date = entry_date;
		this.out_date = out_date;
		this.total_day_stay = total_day_stay;
		this.reason = reason;
	}
	public int getVisitor_id() {
		return visitor_id;
	}
	public void setVisitor_id(int visitor_id) {
		this.visitor_id = visitor_id;
	}
	public String getVisitor_name() {
		return visitor_name;
	}
	public void setVisitor_name(String visitor_name) {
		this.visitor_name = visitor_name;
	}
	public String getVisitor_phone() {
		return visitor_phone;
	}
	public void setVisitor_phone(String visitor_phone) {
		this.visitor_phone = visitor_phone;
	}
	public int getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(int tenant_id) {
		this.tenant_id = tenant_id;
	}
	public String getTenant_name() {
		return tenant_name;
	}
	public void setTenant_name(String tenant_name) {
		this.tenant_name = tenant_name;
	}
	public String getTenant_phone() {
		return tenant_phone;
	}
	public void setTenant_phone(String tenant_phone) {
		this.tenant_phone = tenant_phone;
	}
	public Date getEntry_date() {
		return entry_date;
	}
	public void setEntry_date(Date entry_date) {
		this.entry_date = entry_date;
	}
	public Date getOut_date() {
		return out_date;
	}
	public void setOut_date(Date out_date) {
		this.out_date = out_date;
	}
	public int getTotal_day_stay() {
		return total_day_stay;
	}
	public void setTotal_day_stay(int total_day_stay) {
		this.total_day_stay = total_day_stay;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	@Override
	public String toString() {
		return "Visitor [visitor_id=" + visitor_id + ", visitor_name=" + visitor_name + ", visitor_phone="
				+ visitor_phone + ", tenant_id=" + tenant_id + ", tenant_name=" + tenant_name + ", tenant_phone="
				+ tenant_phone + ", entry_date=" + entry_date + ", out_date=" + out_date + ", total_day_stay="
				+ total_day_stay + ", reason=" + reason + "]";
	}
	
	

}
