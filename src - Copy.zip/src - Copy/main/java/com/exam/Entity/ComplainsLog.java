package com.exam.Entity;

import java.sql.Time;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class ComplainsLog {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int complaint_id;
	
	String complaint_nature;
	String complaint_title;
	String complaint_by;
	
	@Temporal(TemporalType.DATE)
	Date complain_date;
	
	@Temporal(TemporalType.TIME)
	java.sql.Time complaint_time;
	
	String complaint_status;
	String description ;
	
	String apartment_no;
	String building_no;
	
	
	
	String resolustion;
	String resolve_by;
	
	@Temporal(TemporalType.DATE)
	Date resolve_date;
	
	@Temporal(TemporalType.TIME)
	java.sql.Time resolve_time;

	public ComplainsLog() {
		super();
	}

	public ComplainsLog(int complaint_id, String complaint_nature, String complaint_title, String complaint_by,
			Date complain_date, Time complaint_time, String complaint_status, String description, String apartment_no,
			String building_no, String resolustion, String resolve_by, Date resolve_date, Time resolve_time) {
		super();
		this.complaint_id = complaint_id;
		this.complaint_nature = complaint_nature;
		this.complaint_title = complaint_title;
		this.complaint_by = complaint_by;
		this.complain_date = complain_date;
		this.complaint_time = complaint_time;
		this.complaint_status = complaint_status;
		this.description = description;
		this.apartment_no = apartment_no;
		this.building_no = building_no;
		this.resolustion = resolustion;
		this.resolve_by = resolve_by;
		this.resolve_date = resolve_date;
		this.resolve_time = resolve_time;
	}

	public int getComplaint_id() {
		return complaint_id;
	}

	public void setComplaint_id(int complaint_id) {
		this.complaint_id = complaint_id;
	}

	public String getComplaint_nature() {
		return complaint_nature;
	}

	public void setComplaint_nature(String complaint_nature) {
		this.complaint_nature = complaint_nature;
	}

	public String getComplaint_title() {
		return complaint_title;
	}

	public void setComplaint_title(String complaint_title) {
		this.complaint_title = complaint_title;
	}

	public String getComplaint_by() {
		return complaint_by;
	}

	public void setComplaint_by(String complaint_by) {
		this.complaint_by = complaint_by;
	}

	public Date getComplain_date() {
		return complain_date;
	}

	public void setComplain_date(Date complain_date) {
		this.complain_date = complain_date;
	}

	public java.sql.Time getComplaint_time() {
		return complaint_time;
	}

	public void setComplaint_time(java.sql.Time complaint_time) {
		this.complaint_time = complaint_time;
	}

	public String getComplaint_status() {
		return complaint_status;
	}

	public void setComplaint_status(String complaint_status) {
		this.complaint_status = complaint_status;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApartment_no() {
		return apartment_no;
	}

	public void setApartment_no(String apartment_no) {
		this.apartment_no = apartment_no;
	}

	public String getBuilding_no() {
		return building_no;
	}

	public void setBuilding_no(String building_no) {
		this.building_no = building_no;
	}

	public String getResolustion() {
		return resolustion;
	}

	public void setResolustion(String resolustion) {
		this.resolustion = resolustion;
	}

	public String getResolve_by() {
		return resolve_by;
	}

	public void setResolve_by(String resolve_by) {
		this.resolve_by = resolve_by;
	}

	public Date getResolve_date() {
		return resolve_date;
	}

	public void setResolve_date(Date resolve_date) {
		this.resolve_date = resolve_date;
	}

	public java.sql.Time getResolve_time() {
		return resolve_time;
	}

	public void setResolve_time(java.sql.Time resolve_time) {
		this.resolve_time = resolve_time;
	}

	@Override
	public String toString() {
		return "ComplainsLog [complaint_id=" + complaint_id + ", complaint_nature=" + complaint_nature
				+ ", complaint_title=" + complaint_title + ", complaint_by=" + complaint_by + ", complain_date="
				+ complain_date + ", complaint_time=" + complaint_time + ", complaint_status=" + complaint_status
				+ ", description=" + description + ", apartment_no=" + apartment_no + ", building_no=" + building_no
				+ ", resolustion=" + resolustion + ", resolve_by=" + resolve_by + ", resolve_date=" + resolve_date
				+ ", resolve_time=" + resolve_time + "]";
	}

	
	
}
