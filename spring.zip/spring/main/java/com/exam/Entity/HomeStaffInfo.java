package com.exam.Entity;

import java.sql.Time;
import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class HomeStaffInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int membershipCode;
	
	String memberName;
	String flat_of_house_name;
	String employee_code_of_name;

	String employee_code;
	String police_varification_code;
	
	String employee_name;
	String father_husband_name;
	String spouse_name;
	@Temporal(TemporalType.DATE)
	Date date_of_joining;
	
	@Temporal(TemporalType.DATE)
	Date date_of_birth;

	String employee_type;
	String contact_number;
	String driving_Licence;
	String password_number;
	String reference_name;
	String reference_phone;
	String reference_address;
	
	String employee_pressent_address;
	String employee_old_address;
	
	String image;
	
	public HomeStaffInfo() {
		super();
	}

	public HomeStaffInfo(int membershipCode, String memberName, String flat_of_house_name, String employee_code_of_name,
			String employee_code, String police_varification_code, String employee_name, String father_husband_name,
			String spouse_name, Date date_of_joining, Date date_of_birth, String employee_type, String contact_number,
			String driving_Licence, String password_number, String reference_name, String reference_phone,
			String reference_address, String employee_pressent_address, String employee_old_address, String image) {
		super();
		this.membershipCode = membershipCode;
		this.memberName = memberName;
		this.flat_of_house_name = flat_of_house_name;
		this.employee_code_of_name = employee_code_of_name;
		this.employee_code = employee_code;
		this.police_varification_code = police_varification_code;
		this.employee_name = employee_name;
		this.father_husband_name = father_husband_name;
		this.spouse_name = spouse_name;
		this.date_of_joining = date_of_joining;
		this.date_of_birth = date_of_birth;
		this.employee_type = employee_type;
		this.contact_number = contact_number;
		this.driving_Licence = driving_Licence;
		this.password_number = password_number;
		this.reference_name = reference_name;
		this.reference_phone = reference_phone;
		this.reference_address = reference_address;
		this.employee_pressent_address = employee_pressent_address;
		this.employee_old_address = employee_old_address;
		this.image = image;
	}

	public int getMembershipCode() {
		return membershipCode;
	}

	public void setMembershipCode(int membershipCode) {
		this.membershipCode = membershipCode;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getFlat_of_house_name() {
		return flat_of_house_name;
	}

	public void setFlat_of_house_name(String flat_of_house_name) {
		this.flat_of_house_name = flat_of_house_name;
	}

	public String getEmployee_code_of_name() {
		return employee_code_of_name;
	}

	public void setEmployee_code_of_name(String employee_code_of_name) {
		this.employee_code_of_name = employee_code_of_name;
	}

	public String getEmployee_code() {
		return employee_code;
	}

	public void setEmployee_code(String employee_code) {
		this.employee_code = employee_code;
	}

	public String getPolice_varification_code() {
		return police_varification_code;
	}

	public void setPolice_varification_code(String police_varification_code) {
		this.police_varification_code = police_varification_code;
	}

	public String getEmployee_name() {
		return employee_name;
	}

	public void setEmployee_name(String employee_name) {
		this.employee_name = employee_name;
	}

	public String getFather_husband_name() {
		return father_husband_name;
	}

	public void setFather_husband_name(String father_husband_name) {
		this.father_husband_name = father_husband_name;
	}

	public String getSpouse_name() {
		return spouse_name;
	}

	public void setSpouse_name(String spouse_name) {
		this.spouse_name = spouse_name;
	}

	public Date getDate_of_joining() {
		return date_of_joining;
	}

	public void setDate_of_joining(Date date_of_joining) {
		this.date_of_joining = date_of_joining;
	}

	public Date getDate_of_birth() {
		return date_of_birth;
	}

	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}

	public String getEmployee_type() {
		return employee_type;
	}

	public void setEmployee_type(String employee_type) {
		this.employee_type = employee_type;
	}

	public String getContact_number() {
		return contact_number;
	}

	public void setContact_number(String contact_number) {
		this.contact_number = contact_number;
	}

	public String getDriving_Licence() {
		return driving_Licence;
	}

	public void setDriving_Licence(String driving_Licence) {
		this.driving_Licence = driving_Licence;
	}

	public String getPassword_number() {
		return password_number;
	}

	public void setPassword_number(String password_number) {
		this.password_number = password_number;
	}

	public String getReference_name() {
		return reference_name;
	}

	public void setReference_name(String reference_name) {
		this.reference_name = reference_name;
	}

	public String getReference_phone() {
		return reference_phone;
	}

	public void setReference_phone(String reference_phone) {
		this.reference_phone = reference_phone;
	}

	public String getReference_address() {
		return reference_address;
	}

	public void setReference_address(String reference_address) {
		this.reference_address = reference_address;
	}

	public String getEmployee_pressent_address() {
		return employee_pressent_address;
	}

	public void setEmployee_pressent_address(String employee_pressent_address) {
		this.employee_pressent_address = employee_pressent_address;
	}

	public String getEmployee_old_address() {
		return employee_old_address;
	}

	public void setEmployee_old_address(String employee_old_address) {
		this.employee_old_address = employee_old_address;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "HomeStaffInfo [membershipCode=" + membershipCode + ", memberName=" + memberName
				+ ", flat_of_house_name=" + flat_of_house_name + ", employee_code_of_name=" + employee_code_of_name
				+ ", employee_code=" + employee_code + ", police_varification_code=" + police_varification_code
				+ ", employee_name=" + employee_name + ", father_husband_name=" + father_husband_name + ", spouse_name="
				+ spouse_name + ", date_of_joining=" + date_of_joining + ", date_of_birth=" + date_of_birth
				+ ", employee_type=" + employee_type + ", contact_number=" + contact_number + ", driving_Licence="
				+ driving_Licence + ", password_number=" + password_number + ", reference_name=" + reference_name
				+ ", reference_phone=" + reference_phone + ", reference_address=" + reference_address
				+ ", employee_pressent_address=" + employee_pressent_address + ", employee_old_address="
				+ employee_old_address + ", image=" + image + "]";
	}
	

	
	
	
	
	

}
