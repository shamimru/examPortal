package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Tenant {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int tenant_id;
	String name;
	String NID;
	int total_member;
	String job;
	String designation;
	String phone;
	String email;
	String  parmanent_address;
	
	String image;
	
	public Tenant() {
		super();
	}
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public Tenant(int tenant_id, String name, String nID, int total_member, String job, String designation,
			String phone, String email, String parmanent_address, String image) {
		super();
		this.tenant_id = tenant_id;
		this.name = name;
		NID = nID;
		this.total_member = total_member;
		this.job = job;
		this.designation = designation;
		this.phone = phone;
		this.email = email;
		this.parmanent_address = parmanent_address;
		this.image = image;
	}

	public int getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(int tenant_id) {
		this.tenant_id = tenant_id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNID() {
		return NID;
	}
	public void setNID(String nID) {
		NID = nID;
	}
	public int getTotal_member() {
		return total_member;
	}
	public void setTotal_member(int total_member) {
		this.total_member = total_member;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getParmanent_address() {
		return parmanent_address;
	}
	public void setParmanent_address(String parmanent_address) {
		this.parmanent_address = parmanent_address;
	}

	@Override
	public String toString() {
		return "Tenant [tenant_id=" + tenant_id + ", name=" + name + ", NID=" + NID + ", total_member=" + total_member
				+ ", job=" + job + ", designation=" + designation + ", phone=" + phone + ", email=" + email
				+ ", parmanent_address=" + parmanent_address + ", image=" + image + "]";
	}
	
	
	
	
}
