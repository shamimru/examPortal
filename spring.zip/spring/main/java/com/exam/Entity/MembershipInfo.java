package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


@Entity
public class MembershipInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int member_id;
	String member_name;
	
	String residential_type;
	
	String password;
	
	@Temporal(TemporalType.DATE)
	Date membership_date;
	
	@Temporal(TemporalType.DATE)
	Date birth_date;
	
	String son_of_dauhther_of_husband;

	String register_phone_number;
	String alternative_phone_number;
	String email;
	

	String unit_Type;
	String flate_house_shop_number;
	
	double total_area;
	String permanent_or_previous_address;
	String occupation;
	String emergency_contact_details;
	String image;
	
	public MembershipInfo() {
		super();
	}

	public MembershipInfo(int member_id, String member_name, String residential_type, String password,
			Date membership_date, Date birth_date, String son_of_dauhther_of_husband, String register_phone_number,
			String alternative_phone_number, String email, String unit_Type, String flate_house_shop_number,
			double total_area, String permanent_or_previous_address, String occupation,
			String emergency_contact_details, String image) {
		super();
		this.member_id = member_id;
		this.member_name = member_name;
		this.residential_type = residential_type;
		this.password = password;
		this.membership_date = membership_date;
		this.birth_date = birth_date;
		this.son_of_dauhther_of_husband = son_of_dauhther_of_husband;
		this.register_phone_number = register_phone_number;
		this.alternative_phone_number = alternative_phone_number;
		this.email = email;
		this.unit_Type = unit_Type;
		this.flate_house_shop_number = flate_house_shop_number;
		this.total_area = total_area;
		this.permanent_or_previous_address = permanent_or_previous_address;
		this.occupation = occupation;
		this.emergency_contact_details = emergency_contact_details;
		this.image = image;
	}

	public int getMember_id() {
		return member_id;
	}

	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}

	public String getMember_name() {
		return member_name;
	}

	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}

	public String getResidential_type() {
		return residential_type;
	}

	public void setResidential_type(String residential_type) {
		this.residential_type = residential_type;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getMembership_date() {
		return membership_date;
	}

	public void setMembership_date(Date membership_date) {
		this.membership_date = membership_date;
	}

	public Date getBirth_date() {
		return birth_date;
	}

	public void setBirth_date(Date birth_date) {
		this.birth_date = birth_date;
	}

	public String getSon_of_dauhther_of_husband() {
		return son_of_dauhther_of_husband;
	}

	public void setSon_of_dauhther_of_husband(String son_of_dauhther_of_husband) {
		this.son_of_dauhther_of_husband = son_of_dauhther_of_husband;
	}

	public String getRegister_phone_number() {
		return register_phone_number;
	}

	public void setRegister_phone_number(String register_phone_number) {
		this.register_phone_number = register_phone_number;
	}

	public String getAlternative_phone_number() {
		return alternative_phone_number;
	}

	public void setAlternative_phone_number(String alternative_phone_number) {
		this.alternative_phone_number = alternative_phone_number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUnit_Type() {
		return unit_Type;
	}

	public void setUnit_Type(String unit_Type) {
		this.unit_Type = unit_Type;
	}

	public String getFlate_house_shop_number() {
		return flate_house_shop_number;
	}

	public void setFlate_house_shop_number(String flate_house_shop_number) {
		this.flate_house_shop_number = flate_house_shop_number;
	}

	public double getTotal_area() {
		return total_area;
	}

	public void setTotal_area(double total_area) {
		this.total_area = total_area;
	}

	public String getPermanent_or_previous_address() {
		return permanent_or_previous_address;
	}

	public void setPermanent_or_previous_address(String permanent_or_previous_address) {
		this.permanent_or_previous_address = permanent_or_previous_address;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmergency_contact_details() {
		return emergency_contact_details;
	}

	public void setEmergency_contact_details(String emergency_contact_details) {
		this.emergency_contact_details = emergency_contact_details;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "MembershipInfo [member_id=" + member_id + ", member_name=" + member_name + ", residential_type="
				+ residential_type + ", password=" + password + ", membership_date=" + membership_date + ", birth_date="
				+ birth_date + ", son_of_dauhther_of_husband=" + son_of_dauhther_of_husband + ", register_phone_number="
				+ register_phone_number + ", alternative_phone_number=" + alternative_phone_number + ", email=" + email
				+ ", unit_Type=" + unit_Type + ", flate_house_shop_number=" + flate_house_shop_number + ", total_area="
				+ total_area + ", permanent_or_previous_address=" + permanent_or_previous_address + ", occupation="
				+ occupation + ", emergency_contact_details=" + emergency_contact_details + ", image=" + image + "]";
	}

	
	
	

}
