package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.MembershipInfo;

@Repository
public interface MermershipInfo extends CrudRepository<MembershipInfo, Integer>{

}
