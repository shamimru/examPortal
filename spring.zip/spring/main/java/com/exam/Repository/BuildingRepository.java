package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.exam.Entity.BuildingInfo;

@Repository
public interface BuildingRepository  extends CrudRepository<BuildingInfo, Integer>{

}
