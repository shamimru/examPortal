import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showdatabyid',
  templateUrl: './showdatabyid.component.html',
  styleUrls: ['./showdatabyid.component.css']
})
export class ShowdatabyidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  id:any;
  allData:any;
  submitSearchById(){
    
  }
}
