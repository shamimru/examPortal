import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';

import { ViewCategoriesComponent } from './components/Admin/view-categories/view-categories.component';
import { HomeComponent } from './components/Admin/home/home.component';
import { SigninComponent } from './pages/signin/signin.component';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { ProfileComponent } from './components/Admin/profile/profile.component';
import { ShowdatabyidComponent } from './components/Admin/showdatabyid/showdatabyid.component';
import { AddCategoryComponent } from './components/Admin/add-category/add-category.component';
import { SignupComponent } from './pages/signup/signup.component';

const routes: Routes = [
  {path:"", component:HomeComponent,pathMatch:"full"},
  {path:"signup", component:SignupComponent,pathMatch:"full"},
  {path:"login", component:SigninComponent,pathMatch:"full"},
  {path:"admin", component:DashboardComponent,pathMatch:"full"},
  {
     path:"admin",
     component:DashboardComponent,
     children:[
      {
        path:"",
        component:WelcomeComponent
      },
      {path:'profile',
      component:ProfileComponent
      },
      {
        path:'showDataById',component:ShowdatabyidComponent
      },
      {
        path:"categories",component:ViewCategoriesComponent
      },

      {
        path:"add-category",component:AddCategoryComponent
      },
      // {
      //   path:'dashboard',component:DashboardComponent
      // }

      
     
     ]
    
    
    },
    



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
