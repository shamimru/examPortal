import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private userService:UserService,private snack:MatSnackBar,private router:Router) { }

  ngOnInit(): void {
  }
id:any
password:any;

  loginData:any;

  submitLogin(){
       //adduser: userServices
       this.userService.logIn(this.id,this.password).subscribe((data)=>{
        this.loginData=data;
        if(data != null){
          this.router.navigateByUrl("success",{state:{response:this.loginData}})
        }
        //success
        // this.snack.open("Success",'',
        //   {
        //     duration:3000,
        //     verticalPosition:'top',
        //     horizontalPosition:'center'
        //   }
        // )
        alert("success")
      },
      (error)=>{

        this.router.navigateByUrl("fail");
        // alert("error")
        // this.snack.open("Something Went Wrong",'',
        //   {
        //     duration:3000,
        //     verticalPosition:'top',
        //     horizontalPosition:'center'
        //   }
        // )
      }
    );
    }
  }

