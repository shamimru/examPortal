export class Registration {

    id:any;
    username:any;
    password:any;
    firstname:any;
    lastname:any;
    email:any;
    phone:any;

    constructor(id:any,u:any,pass:any,fname:any,lname:any,email:any,phone:any){
        this.id=id;
        this.username=u;
        this.password=pass;
        this.firstname=fname;
        this.lastname=lname;
        this.email=email;
        this.phone=this.phone;
    }
}
