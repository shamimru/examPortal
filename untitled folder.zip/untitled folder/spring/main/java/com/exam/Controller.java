package com.exam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.Entity.AccountMaster;
import com.exam.Entity.AssetsInfo;
import com.exam.Entity.ComplainsLog;
import com.exam.Entity.CostCenterInfo;
import com.exam.Entity.EmployeeInfo;
import com.exam.Entity.HomeStaffInfo;
import com.exam.Entity.MembershipInfo;
import com.exam.Entity.ParkingAllotment;
import com.exam.Entity.SocietyInformation;
import com.exam.Repository.AccountMasterRepo;
import com.exam.Repository.Complains_logRepository;
import com.exam.Repository.HomeStaffIRepo;
import com.exam.Repository.MermershipInfo;
import com.exam.Repository.ParkingAllotmentRepository;
import com.exam.Repository.SocietyInfoRepo;
import com.exam.Repository.UserAssetsInfo;
import com.exam.Repository.UserCostRepository;
import com.exam.Repository.UserEmployeeInfo;

@RestController
@CrossOrigin(origins = "http://localhost:4200")

//@CrossOrigin("")
public class Controller {
	@Autowired
	private SocietyInfoRepo repo;
	
	@Autowired
	private AccountMasterRepo accRepo;
	
	
	@Autowired
	private UserCostRepository costRepo;
	
	@Autowired
	private UserAssetsInfo AssetsRepo;
	
	@Autowired
	private UserEmployeeInfo emprepo;
	
	@Autowired
	private MermershipInfo memberRepo;
	
	@Autowired
	private HomeStaffIRepo homestaffRepo;
	
	@Autowired
	private ParkingAllotmentRepository parkingAllotment;
	
	@Autowired
	private Complains_logRepository complians;

	private Iterable<SocietyInformation> all;
	
	
	
	@GetMapping("/")
	public String sayhello() {
		System.out.println("hello");
		return "hello";
	}
	
	@PostMapping("/admin/society_info")
	public void saveSocietyInformation(@RequestBody SocietyInformation soc){
		System.out.println(soc);

		repo.save(soc);
		
		System.out.println(soc);
	}
	
	
	@GetMapping("/admin/getAllSociety")
	public List<SocietyInformation> getAllSociety(  ){

		all = repo.findAll();
		return (List<SocietyInformation>) all;
		
	}
	
	
	public void sayhi() {
		
	}
	
	
	
	@PostMapping("/admin/saveAccountMaster")
	public void saveAccountMaster(@RequestBody AccountMaster ac) {
		System.out.println(ac);
		accRepo.save(ac);
	}
	
	@PostMapping("/admin/saveCostAccountMaster")
	public void saveCostAccountMaster(@RequestBody CostCenterInfo cost) {
		System.out.println(cost);
		costRepo.save(cost);
	}
	
	@PostMapping("/admin/saveAssetsMaster")
	public void saveAssetsMaster(@RequestBody AssetsInfo asset) {
		System.out.println(asset);
		AssetsRepo.save(asset);
	}
	
	
	
	@PostMapping("/admin/saveEmployeeMaster")
	public void saveEmployeeMaster(@RequestBody EmployeeInfo emp) {
		System.out.println(emp);
		emprepo.save(emp);
	}
	@PostMapping("/admin/saveMembership")
	public void saveMembership(@RequestBody MembershipInfo membership) {
		System.out.println(membership);
		memberRepo.save(membership);
	}
	
	@PostMapping("/admin/saveHomeStaff")
	public void saveHomeStaff(@RequestBody HomeStaffInfo homestaff) {
		System.out.println(homestaff);
		homestaffRepo.save(homestaff);
	}
	
	@PostMapping("/admin/saveParingAllotment")
	public void saveParingAllotment(@RequestBody ParkingAllotment parking) {
		System.out.println(parking);
		parkingAllotment.save(parking);
	}
	
	@PostMapping("/admin/saveComplains")
	public void saveComplains(@RequestBody ComplainsLog complains) {
		System.out.println(complains);
		complians.save(complains);
	}
	
	
	
	
	
	
	

}
