package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class EmployeeInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int emp_code;
	String emp_name;
	String gardian;
	String spuse;

	@Temporal(TemporalType.DATE)
	Date joiningDate;

	@Temporal(TemporalType.DATE)
	Date dateOfBirth;
	String jobType;
	String department;

	String designation;
	String contactNumber;
	String email;
	String referenceName;
	String referenceNumber;

	public EmployeeInfo() {
		super();
	}

	public EmployeeInfo(int emp_code, String emp_name, String gardian, String spuse, Date joiningDate, Date dateOfBirth,
			String jobType, String department, String designation, String contactNumber, String email,
			String referenceName, String referenceNumber) {
		super();
		this.emp_code = emp_code;
		this.emp_name = emp_name;
		this.gardian = gardian;
		this.spuse = spuse;
		this.joiningDate = joiningDate;
		this.dateOfBirth = dateOfBirth;
		this.jobType = jobType;
		this.department = department;
		this.designation = designation;
		this.contactNumber = contactNumber;
		this.email = email;
		this.referenceName = referenceName;
		this.referenceNumber = referenceNumber;
	}

	public int getEmp_code() {
		return emp_code;
	}

	public void setEmp_code(int emp_code) {
		this.emp_code = emp_code;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public String getGardian() {
		return gardian;
	}

	public void setGardian(String gardian) {
		this.gardian = gardian;
	}

	public String getSpuse() {
		return spuse;
	}

	public void setSpuse(String spuse) {
		this.spuse = spuse;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReferenceName() {
		return referenceName;
	}

	public void setReferenceName(String referenceName) {
		this.referenceName = referenceName;
	}

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	@Override
	public String toString() {
		return "EmployeeInfo [emp_code=" + emp_code + ", emp_name=" + emp_name + ", gardian=" + gardian + ", spuse="
				+ spuse + ", joiningDate=" + joiningDate + ", dateOfBirth=" + dateOfBirth + ", jobType=" + jobType
				+ ", department=" + department + ", designation=" + designation + ", contactNumber=" + contactNumber
				+ ", email=" + email + ", referenceName=" + referenceName + ", referenceNumber=" + referenceNumber
				+ "]";
	}

}
