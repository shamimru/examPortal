package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class Electricity_bill {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	
	int bill_number;
	int owner_id;
	String owner_name;
	
	@Temporal(TemporalType.DATE)
	Date issue_date;
	@Temporal(TemporalType.DATE)
	Date current_bill_Date;
	
	double due;
	double total_bill;
	double net_bill;
	public Electricity_bill() {
		super();
	}
	
	public Electricity_bill(int bill_number, int owner_id, String owner_name, Date issue_date, Date current_bill_Date,
			double due, double total_bill, double net_bill) {
		super();
		this.bill_number = bill_number;
		this.owner_id = owner_id;
		this.owner_name = owner_name;
		this.issue_date = issue_date;
		this.current_bill_Date = current_bill_Date;
		this.due = due;
		this.total_bill = total_bill;
		this.net_bill = net_bill;
	}

	public int getBill_number() {
		return bill_number;
	}
	public void setBill_number(int bill_number) {
		this.bill_number = bill_number;
	}
	public int getOwner_id() {
		return owner_id;
	}
	public void setOwner_id(int owner_id) {
		this.owner_id = owner_id;
	}
	public String getOwner_name() {
		return owner_name;
	}
	public void setOwner_name(String owner_name) {
		this.owner_name = owner_name;
	}
	public Date getIssue_date() {
		return issue_date;
	}
	public void setIssue_date(Date issue_date) {
		this.issue_date = issue_date;
	}
	
	public Date getCurrent_bill_Date() {
		return current_bill_Date;
	}
	public void setCurrent_bill_Date(Date current_bill_Date) {
		this.current_bill_Date = current_bill_Date;
	}
	public double getDue() {
		return due;
	}
	public void setDue(double due) {
		this.due = due;
	}
	public double getTotal_bill() {
		return total_bill;
	}
	public void setTotal_bill(double total_bill) {
		this.total_bill = total_bill;
	}
	public double getNet_bill() {
		return net_bill;
	}
	public void setNet_bill(double net_bill) {
		this.net_bill = net_bill;
	}
	@Override
	public String toString() {
		return "Electricity_bill [bill_number=" + bill_number + ", owner_id=" + owner_id + ", owner_name=" + owner_name
				+ ", issue_date=" + issue_date + ", current_bill_Date=" + current_bill_Date + ", due=" + due
				+ ", total_bill=" + total_bill + ", net_bill=" + net_bill + "]";
	}
	
	
	
	

}
