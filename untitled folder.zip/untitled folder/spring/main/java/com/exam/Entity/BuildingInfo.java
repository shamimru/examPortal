package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class BuildingInfo {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int building_id;
	String building_name;
	int floor;
	int apartment_number;
	int room_number;
	double rent;
	String society_id;
	String building_owner;
	String owener_number;
	String email;
	double landSize;
	
	String image; 
	
	public BuildingInfo() {
		super();
	}
	
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public BuildingInfo(int building_id, String building_name, int floor, int apartment_number, int room_number,
			double rent, String society_id, String building_owner, String owener_number, String email, double landSize,
			String image) {
		super();
		this.building_id = building_id;
		this.building_name = building_name;
		this.floor = floor;
		this.apartment_number = apartment_number;
		this.room_number = room_number;
		this.rent = rent;
		this.society_id = society_id;
		this.building_owner = building_owner;
		this.owener_number = owener_number;
		this.email = email;
		this.landSize = landSize;
		this.image = image;
	}

	public int getBuilding_id() {
		return building_id;
	}
	public void setBuilding_id(int building_id) {
		this.building_id = building_id;
	}
	public String getBuilding_name() {
		return building_name;
	}
	public void setBuilding_name(String building_name) {
		this.building_name = building_name;
	}
	public int getFloor() {
		return floor;
	}
	public void setFloor(int floor) {
		this.floor = floor;
	}
	public int getApartment_number() {
		return apartment_number;
	}
	public void setApartment_number(int apartment_number) {
		this.apartment_number = apartment_number;
	}
	public int getRoom_number() {
		return room_number;
	}
	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}
	public double getRent() {
		return rent;
	}
	public void setRent(double rent) {
		this.rent = rent;
	}
	public String getSociety_id() {
		return society_id;
	}
	public void setSociety_id(String society_id) {
		this.society_id = society_id;
	}
	public String getBuilding_owner() {
		return building_owner;
	}
	public void setBuilding_owner(String building_owner) {
		this.building_owner = building_owner;
	}
	public String getOwener_number() {
		return owener_number;
	}
	public void setOwener_number(String owener_number) {
		this.owener_number = owener_number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getLandSize() {
		return landSize;
	}
	public void setLandSize(double landSize) {
		this.landSize = landSize;
	}

	@Override
	public String toString() {
		return "BuildingInfo [building_id=" + building_id + ", building_name=" + building_name + ", floor=" + floor
				+ ", apartment_number=" + apartment_number + ", room_number=" + room_number + ", rent=" + rent
				+ ", society_id=" + society_id + ", building_owner=" + building_owner + ", owener_number="
				+ owener_number + ", email=" + email + ", landSize=" + landSize + ", image=" + image + "]";
	}
	
	
	

}
