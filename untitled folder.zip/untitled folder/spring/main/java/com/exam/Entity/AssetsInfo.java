package com.exam.Entity;


import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


@Entity
public class AssetsInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int assets_id;
	
	String code;
	String assets_Name;
	String mobile_Number;
	String assets_description;
	String use_Of_assets;
	String location_of_use;
	double unit_price;
	
	int quantity;
	double total_price;
	String serviceCenter_name;
	
	
    @Temporal(TemporalType.DATE)
	Date acquisition_Date; 
    
    @Temporal(TemporalType.DATE)
    Date assets_commense_date;
    
    @Temporal(TemporalType.DATE)
    Date return_date;

	public AssetsInfo(int assets_id, String code, String assets_Name, String mobile_Number, String assets_description,
			String use_Of_assets, String location_of_use, double unit_price, int quantity, double total_price,
			String serviceCenter_name, Date acquisition_Date, Date assets_commense_date, Date return_date) {
		super();
		this.assets_id = assets_id;
		this.code = code;
		this.assets_Name = assets_Name;
		this.mobile_Number = mobile_Number;
		this.assets_description = assets_description;
		this.use_Of_assets = use_Of_assets;
		this.location_of_use = location_of_use;
		this.unit_price = unit_price;
		this.quantity = quantity;
		this.total_price = total_price;
		this.serviceCenter_name = serviceCenter_name;
		this.acquisition_Date = acquisition_Date;
		this.assets_commense_date = assets_commense_date;
		this.return_date = return_date;
	}

	public int getAssets_id() {
		return assets_id;
	}

	public void setAssets_id(int assets_id) {
		this.assets_id = assets_id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getAssets_Name() {
		return assets_Name;
	}

	public void setAssets_Name(String assets_Name) {
		this.assets_Name = assets_Name;
	}

	public String getMobile_Number() {
		return mobile_Number;
	}

	public void setMobile_Number(String mobile_Number) {
		this.mobile_Number = mobile_Number;
	}

	public String getAssets_description() {
		return assets_description;
	}

	public void setAssets_description(String assets_description) {
		this.assets_description = assets_description;
	}

	public String getUse_Of_assets() {
		return use_Of_assets;
	}

	public void setUse_Of_assets(String use_Of_assets) {
		this.use_Of_assets = use_Of_assets;
	}

	public String getLocation_of_use() {
		return location_of_use;
	}

	public void setLocation_of_use(String location_of_use) {
		this.location_of_use = location_of_use;
	}

	public double getUnit_price() {
		return unit_price;
	}

	public void setUnit_price(double unit_price) {
		this.unit_price = unit_price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotal_price() {
		return total_price;
	}

	public void setTotal_price(double total_price) {
		this.total_price = total_price;
	}

	public String getServiceCenter_name() {
		return serviceCenter_name;
	}

	public void setServiceCenter_name(String serviceCenter_name) {
		this.serviceCenter_name = serviceCenter_name;
	}

	public Date getAcquisition_Date() {
		return acquisition_Date;
	}

	public void setAcquisition_Date(Date acquisition_Date) {
		this.acquisition_Date = acquisition_Date;
	}

	public Date getAssets_commense_date() {
		return assets_commense_date;
	}

	public void setAssets_commense_date(Date assets_commense_date) {
		this.assets_commense_date = assets_commense_date;
	}

	public Date getReturn_date() {
		return return_date;
	}

	public void setReturn_date(Date return_date) {
		this.return_date = return_date;
	}

	@Override
	public String toString() {
		return "AssetsInfo [assets_id=" + assets_id + ", code=" + code + ", assets_Name=" + assets_Name
				+ ", mobile_Number=" + mobile_Number + ", assets_description=" + assets_description + ", use_Of_assets="
				+ use_Of_assets + ", location_of_use=" + location_of_use + ", unit_price=" + unit_price + ", quantity="
				+ quantity + ", total_price=" + total_price + ", serviceCenter_name=" + serviceCenter_name
				+ ", acquisition_Date=" + acquisition_Date + ", assets_commense_date=" + assets_commense_date
				+ ", return_date=" + return_date + "]";
	}
    
    
	
    
}
