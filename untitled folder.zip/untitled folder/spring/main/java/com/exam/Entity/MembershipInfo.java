package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


@Entity
public class MembershipInfo {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int member_id;
	String member_name;
	String members_login_id;
	String password;
	String confirm_password;
	
	@Temporal(TemporalType.DATE)
	Date membership_date;
	
	@Temporal(TemporalType.DATE)
	Date birth_date;
	
	String son_of_dauhther_of_husband;
	
	boolean isBangladeshi;
	boolean isForeigner;
	boolean isPhysically_chanllenged;
	boolean isFreedomFighter;
	boolean isEx_serviceman;
	boolean isSocial_activities;
	
	String register_phone_number;
	String alternative_phone_number;
	String email;
	String identity_proof;
	String residential_Type;
	String unit_Type;
	String flate_house_shop_number;
	double monthly_maintenance_rate;
	double total_area;
	double total_monthly_charge;
	String permanent_or_previous_address;
	String occupation;
	String emergency_contact_details;
	
	public MembershipInfo() {
		super();
	}
	public MembershipInfo(int member_id, String member_name, String members_login_id, String password,
			String confirm_password, Date membership_date, Date birth_date, String son_of_dauhther_of_husband,
			boolean isBangladeshi, boolean isForeigner, boolean isPhysically_chanllenged, boolean isFreedomFighter,
			boolean isEx_serviceman, boolean isSocial_activities, String register_phone_number,
			String alternative_phone_number, String email, String identity_proof, String residential_Type,
			String unit_Type, String flate_house_shop_number, double monthly_maintenance_rate, double total_area,
			double total_monthly_charge, String permanent_or_previous_address, String occupation,
			String emergency_contact_details) {
		super();
		this.member_id = member_id;
		this.member_name = member_name;
		this.members_login_id = members_login_id;
		this.password = password;
		this.confirm_password = confirm_password;
		this.membership_date = membership_date;
		this.birth_date = birth_date;
		this.son_of_dauhther_of_husband = son_of_dauhther_of_husband;
		this.isBangladeshi = isBangladeshi;
		this.isForeigner = isForeigner;
		this.isPhysically_chanllenged = isPhysically_chanllenged;
		this.isFreedomFighter = isFreedomFighter;
		this.isEx_serviceman = isEx_serviceman;
		this.isSocial_activities = isSocial_activities;
		this.register_phone_number = register_phone_number;
		this.alternative_phone_number = alternative_phone_number;
		this.email = email;
		this.identity_proof = identity_proof;
		this.residential_Type = residential_Type;
		this.unit_Type = unit_Type;
		this.flate_house_shop_number = flate_house_shop_number;
		this.monthly_maintenance_rate = monthly_maintenance_rate;
		this.total_area = total_area;
		this.total_monthly_charge = total_monthly_charge;
		this.permanent_or_previous_address = permanent_or_previous_address;
		this.occupation = occupation;
		this.emergency_contact_details = emergency_contact_details;
	}
	public int getMember_id() {
		return member_id;
	}
	public void setMember_id(int member_id) {
		this.member_id = member_id;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getMembers_login_id() {
		return members_login_id;
	}
	public void setMembers_login_id(String members_login_id) {
		this.members_login_id = members_login_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirm_password() {
		return confirm_password;
	}
	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}
	public Date getMembership_date() {
		return membership_date;
	}
	public void setMembership_date(Date membership_date) {
		this.membership_date = membership_date;
	}
	public Date getBirth_date() {
		return birth_date;
	}
	public void setBirth_date(Date birth_date) {
		this.birth_date = birth_date;
	}
	public String getSon_of_dauhther_of_husband() {
		return son_of_dauhther_of_husband;
	}
	public void setSon_of_dauhther_of_husband(String son_of_dauhther_of_husband) {
		this.son_of_dauhther_of_husband = son_of_dauhther_of_husband;
	}
	public boolean isBangladeshi() {
		return isBangladeshi;
	}
	public void setBangladeshi(boolean isBangladeshi) {
		this.isBangladeshi = isBangladeshi;
	}
	public boolean isForeigner() {
		return isForeigner;
	}
	public void setForeigner(boolean isForeigner) {
		this.isForeigner = isForeigner;
	}
	public boolean isPhysically_chanllenged() {
		return isPhysically_chanllenged;
	}
	public void setPhysically_chanllenged(boolean isPhysically_chanllenged) {
		this.isPhysically_chanllenged = isPhysically_chanllenged;
	}
	public boolean isFreedomFighter() {
		return isFreedomFighter;
	}
	public void setFreedomFighter(boolean isFreedomFighter) {
		this.isFreedomFighter = isFreedomFighter;
	}
	public boolean isEx_serviceman() {
		return isEx_serviceman;
	}
	public void setEx_serviceman(boolean isEx_serviceman) {
		this.isEx_serviceman = isEx_serviceman;
	}
	public boolean isSocial_activities() {
		return isSocial_activities;
	}
	public void setSocial_activities(boolean isSocial_activities) {
		this.isSocial_activities = isSocial_activities;
	}
	public String getRegister_phone_number() {
		return register_phone_number;
	}
	public void setRegister_phone_number(String register_phone_number) {
		this.register_phone_number = register_phone_number;
	}
	public String getAlternative_phone_number() {
		return alternative_phone_number;
	}
	public void setAlternative_phone_number(String alternative_phone_number) {
		this.alternative_phone_number = alternative_phone_number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getIdentity_proof() {
		return identity_proof;
	}
	public void setIdentity_proof(String identity_proof) {
		this.identity_proof = identity_proof;
	}
	public String getResidential_Type() {
		return residential_Type;
	}
	public void setResidential_Type(String residential_Type) {
		this.residential_Type = residential_Type;
	}
	public String getUnit_Type() {
		return unit_Type;
	}
	public void setUnit_Type(String unit_Type) {
		this.unit_Type = unit_Type;
	}
	public String getFlate_house_shop_number() {
		return flate_house_shop_number;
	}
	public void setFlate_house_shop_number(String flate_house_shop_number) {
		this.flate_house_shop_number = flate_house_shop_number;
	}
	public double getMonthly_maintenance_rate() {
		return monthly_maintenance_rate;
	}
	public void setMonthly_maintenance_rate(double monthly_maintenance_rate) {
		this.monthly_maintenance_rate = monthly_maintenance_rate;
	}
	public double getTotal_area() {
		return total_area;
	}
	public void setTotal_area(double total_area) {
		this.total_area = total_area;
	}
	public double getTotal_monthly_charge() {
		return total_monthly_charge;
	}
	public void setTotal_monthly_charge(double total_monthly_charge) {
		this.total_monthly_charge = total_monthly_charge;
	}
	public String getPermanent_or_previous_address() {
		return permanent_or_previous_address;
	}
	public void setPermanent_or_previous_address(String permanent_or_previous_address) {
		this.permanent_or_previous_address = permanent_or_previous_address;
	}
	public String getOccupation() {
		return occupation;
	}
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	public String getEmergency_contact_details() {
		return emergency_contact_details;
	}
	public void setEmergency_contact_details(String emergency_contact_details) {
		this.emergency_contact_details = emergency_contact_details;
	}
	@Override
	public String toString() {
		return "MembershipInfo [member_id=" + member_id + ", member_name=" + member_name + ", members_login_id="
				+ members_login_id + ", password=" + password + ", confirm_password=" + confirm_password
				+ ", membership_date=" + membership_date + ", birth_date=" + birth_date
				+ ", son_of_dauhther_of_husband=" + son_of_dauhther_of_husband + ", isBangladeshi=" + isBangladeshi
				+ ", isForeigner=" + isForeigner + ", isPhysically_chanllenged=" + isPhysically_chanllenged
				+ ", isFreedomFighter=" + isFreedomFighter + ", isEx_serviceman=" + isEx_serviceman
				+ ", isSocial_activities=" + isSocial_activities + ", register_phone_number=" + register_phone_number
				+ ", alternative_phone_number=" + alternative_phone_number + ", email=" + email + ", identity_proof="
				+ identity_proof + ", residential_Type=" + residential_Type + ", unit_Type=" + unit_Type
				+ ", flate_house_shop_number=" + flate_house_shop_number + ", monthly_maintenance_rate="
				+ monthly_maintenance_rate + ", total_area=" + total_area + ", total_monthly_charge="
				+ total_monthly_charge + ", permanent_or_previous_address=" + permanent_or_previous_address
				+ ", occupation=" + occupation + ", emergency_contact_details=" + emergency_contact_details + "]";
	}
	
	
	
	

}
