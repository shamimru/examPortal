package com.exam.Repository;

import org.springframework.data.repository.CrudRepository;

import com.exam.Entity.AccountMaster;
import com.exam.Entity.SocietyInformation;


@org.springframework.stereotype.Repository
public interface SocietyInfoRepo extends CrudRepository<SocietyInformation, Long>{

	
}


