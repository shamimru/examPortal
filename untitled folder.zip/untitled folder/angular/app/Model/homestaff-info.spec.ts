import { HomestaffInfo } from './homestaff-info';

describe('HomestaffInfo', () => {
  it('should create an instance', () => {
    expect(new HomestaffInfo()).toBeTruthy();
  });
});
