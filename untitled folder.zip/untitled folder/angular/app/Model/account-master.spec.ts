import { AccountMaster } from './account-master';

describe('AccountMaster', () => {
  it('should create an instance', () => {
    expect(new AccountMaster()).toBeTruthy();
  });
});
