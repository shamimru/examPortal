import { SocietyInformation } from './society-information';

describe('SocietyInformation', () => {
  it('should create an instance', () => {
    expect(new SocietyInformation()).toBeTruthy();
  });
});
