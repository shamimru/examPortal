import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-building-info',
  templateUrl: './show-building-info.component.html',
  styleUrls: ['./show-building-info.component.css']
})
export class ShowBuildingInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
