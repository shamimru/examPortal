import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-monthly-fee',
  templateUrl: './monthly-fee.component.html',
  styleUrls: ['./monthly-fee.component.css']
})
export class MonthlyFeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
