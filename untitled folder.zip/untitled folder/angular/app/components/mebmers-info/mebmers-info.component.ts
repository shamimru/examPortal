import { Component, OnInit } from '@angular/core';
import { MembershipInfo } from 'src/app/Model/membership-info';

@Component({
  selector: 'app-mebmers-info',
  templateUrl: './mebmers-info.component.html',
  styleUrls: ['./mebmers-info.component.css']
})
export class MebmersInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


  membership_object:any;
  membership_submit(){
    this.membership_object=new MembershipInfo("",this.member_name,this.members_login_id,this.password, this.confirm_password,this.membership_date,this.birth_date,this.son_of_dauhther_of_husband,this.isBangladeshi,this.isForeigner,this.isPhysically_chanllenged,this.isFreedomFighter,this.isEx_serviceman,this.isSocial_activities, this.register_phone_number, this.alternative_phone_number, this.email, this.identity_proof, this.residential_Type, this.unit_Type, this.flate_house_shop_number, this.monthly_maintenance_rate, this.total_area, this.total_monthly_charge, this.permanent_or_previous_address,this.occupation,this.emergency_contact_details);
  }


  member_name:any;
  members_login_id:any;
  password:any;
  confirm_password:any;
  membership_date:any;
  birth_date:any;
  son_of_dauhther_of_husband:any;
  isBangladeshi:any;
  isForeigner:any;
  isPhysically_chanllenged:any;
  isFreedomFighter:any;
  isEx_serviceman:any;
  isSocial_activities:any;
  register_phone_number:any;
  alternative_phone_number:any;
  email:any;
  identity_proof:any;
  residential_Type:any;
  unit_Type:any;
  flate_house_shop_number:any;
  monthly_maintenance_rate:any;
  total_area:any;
  total_monthly_charge:any;
  permanent_or_previous_address:any;
  occupation:any;
  emergency_contact_details:any;

 
  isBan(ban:any){
    alert("hello bang")
    alert(ban.value)
  }

  isForeign(){

  }

  isPhysic(){

  }
  isFreedom(){

  }
  isExser(){

  }
  isSocial(){

  }
}
