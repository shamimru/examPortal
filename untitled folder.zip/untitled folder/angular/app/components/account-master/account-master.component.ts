import { Component, OnInit } from '@angular/core';
import { AccountMaster } from 'src/app/Model/account-master';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-account-master',
  templateUrl: './account-master.component.html',
  styleUrls: ['./account-master.component.css']
})
export class AccountMasterComponent implements OnInit {

  constructor(

    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }

  acc_id: any;
  accountNumber: any;
  name: any;
  transferMoneyAccount: any;

  description: any;
  remark: any;


  accountMaster_object:any
  accountSave(){

    this.accountMaster_object=new AccountMaster("",this.accountNumber, this.name, this.transferMoneyAccount, this.description,this.remark)

    this.service.saveAccountMaster(this.accountMaster_object).subscribe((response)=>{

    })
  }
}
