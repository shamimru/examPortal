CREATE DATABASE  IF NOT EXISTS `residential_society_management` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `residential_society_management`;
-- MySQL dump 10.13  Distrib 8.0.36, for macos14 (arm64)
--
-- Host: localhost    Database: residential_society_management
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account_master`
--

DROP TABLE IF EXISTS `account_master`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_master` (
  `acc_id` int NOT NULL,
  `account_number` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `transfer_money_account` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`acc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_master`
--

LOCK TABLES `account_master` WRITE;
/*!40000 ALTER TABLE `account_master` DISABLE KEYS */;
INSERT INTO `account_master` VALUES (102,'fgsgg','efe3','fds','dfs','fg'),(103,'fgsgg','efe3','fds','dfs','fg');
/*!40000 ALTER TABLE `account_master` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_master_seq`
--

DROP TABLE IF EXISTS `account_master_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_master_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_master_seq`
--

LOCK TABLES `account_master_seq` WRITE;
/*!40000 ALTER TABLE `account_master_seq` DISABLE KEYS */;
INSERT INTO `account_master_seq` VALUES (201);
/*!40000 ALTER TABLE `account_master_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartment`
--

DROP TABLE IF EXISTS `apartment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apartment` (
  `rent_id` int NOT NULL,
  `release_date` date DEFAULT NULL,
  `rent_date` date DEFAULT NULL,
  `rent_per_month` double NOT NULL,
  `tenant_id` int NOT NULL,
  `apartment_table_id` int NOT NULL,
  `apartment_id` int NOT NULL,
  `building_id` int NOT NULL,
  `society_id` int NOT NULL,
  `is_rented` bit(1) NOT NULL,
  `owener_id` varchar(255) DEFAULT NULL,
  `total_room` int NOT NULL,
  PRIMARY KEY (`rent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartment`
--

LOCK TABLES `apartment` WRITE;
/*!40000 ALTER TABLE `apartment` DISABLE KEYS */;
/*!40000 ALTER TABLE `apartment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `apartment_seq`
--

DROP TABLE IF EXISTS `apartment_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apartment_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apartment_seq`
--

LOCK TABLES `apartment_seq` WRITE;
/*!40000 ALTER TABLE `apartment_seq` DISABLE KEYS */;
INSERT INTO `apartment_seq` VALUES (1);
/*!40000 ALTER TABLE `apartment_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_info`
--

DROP TABLE IF EXISTS `assets_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_info` (
  `assets_id` int NOT NULL,
  `acquisition_date` date DEFAULT NULL,
  `assets_name` varchar(255) DEFAULT NULL,
  `assets_commense_date` date DEFAULT NULL,
  `assets_description` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `location_of_use` varchar(255) DEFAULT NULL,
  `mobile_number` varchar(255) DEFAULT NULL,
  `quantity` int NOT NULL,
  `return_date` date DEFAULT NULL,
  `service_center_name` varchar(255) DEFAULT NULL,
  `total_price` double NOT NULL,
  `unit_price` double NOT NULL,
  `use_of_assets` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`assets_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_info`
--

LOCK TABLES `assets_info` WRITE;
/*!40000 ALTER TABLE `assets_info` DISABLE KEYS */;
INSERT INTO `assets_info` VALUES (2,'2024-05-06','fdsa','2024-05-25','dfe3g','fds','dfsga','fe3',44,'2024-05-28','sf',454,45,'fdsg3');
/*!40000 ALTER TABLE `assets_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_info_seq`
--

DROP TABLE IF EXISTS `assets_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_info_seq`
--

LOCK TABLES `assets_info_seq` WRITE;
/*!40000 ALTER TABLE `assets_info_seq` DISABLE KEYS */;
INSERT INTO `assets_info_seq` VALUES (101);
/*!40000 ALTER TABLE `assets_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building_info`
--

DROP TABLE IF EXISTS `building_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `building_info` (
  `building_id` int NOT NULL,
  `apartment_number` int NOT NULL,
  `building_name` varchar(255) DEFAULT NULL,
  `building_owner` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `floor` int NOT NULL,
  `land_size` double NOT NULL,
  `owener_number` varchar(255) DEFAULT NULL,
  `rent` double NOT NULL,
  `room_number` int NOT NULL,
  `society_id` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`building_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building_info`
--

LOCK TABLES `building_info` WRITE;
/*!40000 ALTER TABLE `building_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `building_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building_info_seq`
--

DROP TABLE IF EXISTS `building_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `building_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building_info_seq`
--

LOCK TABLES `building_info_seq` WRITE;
/*!40000 ALTER TABLE `building_info_seq` DISABLE KEYS */;
INSERT INTO `building_info_seq` VALUES (1);
/*!40000 ALTER TABLE `building_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complains_log`
--

DROP TABLE IF EXISTS `complains_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complains_log` (
  `ticket_no` int NOT NULL,
  `brifly_describe` varchar(255) DEFAULT NULL,
  `complain_date` date DEFAULT NULL,
  `complains_type` varchar(255) DEFAULT NULL,
  `elaborate_problem` varchar(255) DEFAULT NULL,
  `member_code` varchar(255) DEFAULT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ticket_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complains_log`
--

LOCK TABLES `complains_log` WRITE;
/*!40000 ALTER TABLE `complains_log` DISABLE KEYS */;
INSERT INTO `complains_log` VALUES (1,'fdsa','2024-05-22','fsa','fsa',NULL,'dsf'),(2,'dfsa','2024-05-29','dfsa','staff',NULL,'fdsa'),(3,'h&j','2024-05-02','jghf','jhgf',NULL,'gh'),(4,'dfsa','2024-05-15','Asda','fdsa','isa','fdsa'),(5,'dsf','2024-05-21','dsf','dsf','isa','fsa');
/*!40000 ALTER TABLE `complains_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complains_log_seq`
--

DROP TABLE IF EXISTS `complains_log_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complains_log_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complains_log_seq`
--

LOCK TABLES `complains_log_seq` WRITE;
/*!40000 ALTER TABLE `complains_log_seq` DISABLE KEYS */;
INSERT INTO `complains_log_seq` VALUES (101);
/*!40000 ALTER TABLE `complains_log_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cost_center_info`
--

DROP TABLE IF EXISTS `cost_center_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cost_center_info` (
  `cost_id` int NOT NULL,
  `cost_code` varchar(255) DEFAULT NULL,
  `descriptin` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cost_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cost_center_info`
--

LOCK TABLES `cost_center_info` WRITE;
/*!40000 ALTER TABLE `cost_center_info` DISABLE KEYS */;
INSERT INTO `cost_center_info` VALUES (1,NULL,NULL,NULL,NULL),(2,'fdsaf','daf','fdsaf','sad');
/*!40000 ALTER TABLE `cost_center_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cost_center_info_seq`
--

DROP TABLE IF EXISTS `cost_center_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cost_center_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cost_center_info_seq`
--

LOCK TABLES `cost_center_info_seq` WRITE;
/*!40000 ALTER TABLE `cost_center_info_seq` DISABLE KEYS */;
INSERT INTO `cost_center_info_seq` VALUES (101);
/*!40000 ALTER TABLE `cost_center_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `electricity_bill`
--

DROP TABLE IF EXISTS `electricity_bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `electricity_bill` (
  `bill_number` int NOT NULL,
  `current_bill_date` date DEFAULT NULL,
  `due` double NOT NULL,
  `issue_date` date DEFAULT NULL,
  `net_bill` double NOT NULL,
  `owner_id` int NOT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `total_bill` double NOT NULL,
  PRIMARY KEY (`bill_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `electricity_bill`
--

LOCK TABLES `electricity_bill` WRITE;
/*!40000 ALTER TABLE `electricity_bill` DISABLE KEYS */;
/*!40000 ALTER TABLE `electricity_bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `electricity_bill_seq`
--

DROP TABLE IF EXISTS `electricity_bill_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `electricity_bill_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `electricity_bill_seq`
--

LOCK TABLES `electricity_bill_seq` WRITE;
/*!40000 ALTER TABLE `electricity_bill_seq` DISABLE KEYS */;
INSERT INTO `electricity_bill_seq` VALUES (1);
/*!40000 ALTER TABLE `electricity_bill_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_info`
--

DROP TABLE IF EXISTS `employee_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_info` (
  `emp_code` int NOT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emp_name` varchar(255) DEFAULT NULL,
  `gardian` varchar(255) DEFAULT NULL,
  `job_type` varchar(255) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `reference_name` varchar(255) DEFAULT NULL,
  `reference_number` varchar(255) DEFAULT NULL,
  `spuse` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`emp_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_info`
--

LOCK TABLES `employee_info` WRITE;
/*!40000 ALTER TABLE `employee_info` DISABLE KEYS */;
INSERT INTO `employee_info` VALUES (1,'dffd','2024-05-16','df','fde','gdsf','dsaf','pdf','fge',NULL,'df','fsf','age');
/*!40000 ALTER TABLE `employee_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee_info_seq`
--

DROP TABLE IF EXISTS `employee_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee_info_seq`
--

LOCK TABLES `employee_info_seq` WRITE;
/*!40000 ALTER TABLE `employee_info_seq` DISABLE KEYS */;
INSERT INTO `employee_info_seq` VALUES (51);
/*!40000 ALTER TABLE `employee_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_staff_info`
--

DROP TABLE IF EXISTS `home_staff_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_staff_info` (
  `membership_code` int NOT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `date_of_joining` date DEFAULT NULL,
  `driving_licence` varchar(255) DEFAULT NULL,
  `employee_code` varchar(255) DEFAULT NULL,
  `employee_code_of_name` varchar(255) DEFAULT NULL,
  `employee_name` varchar(255) DEFAULT NULL,
  `employee_old_address` varchar(255) DEFAULT NULL,
  `employee_pressent_address` varchar(255) DEFAULT NULL,
  `employee_type` varchar(255) DEFAULT NULL,
  `father_husband_name` varchar(255) DEFAULT NULL,
  `flat_of_house_name` varchar(255) DEFAULT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `password_number` varchar(255) DEFAULT NULL,
  `police_varification_code` varchar(255) DEFAULT NULL,
  `reference_address` varchar(255) DEFAULT NULL,
  `reference_name` varchar(255) DEFAULT NULL,
  `reference_phone` varchar(255) DEFAULT NULL,
  `spouse_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`membership_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_staff_info`
--

LOCK TABLES `home_staff_info` WRITE;
/*!40000 ALTER TABLE `home_staff_info` DISABLE KEYS */;
INSERT INTO `home_staff_info` VALUES (52,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `home_staff_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `home_staff_info_seq`
--

DROP TABLE IF EXISTS `home_staff_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `home_staff_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `home_staff_info_seq`
--

LOCK TABLES `home_staff_info_seq` WRITE;
/*!40000 ALTER TABLE `home_staff_info_seq` DISABLE KEYS */;
INSERT INTO `home_staff_info_seq` VALUES (151);
/*!40000 ALTER TABLE `home_staff_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_info`
--

DROP TABLE IF EXISTS `membership_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_info` (
  `member_id` int NOT NULL,
  `alternative_phone_number` varchar(255) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `confirm_password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `emergency_contact_details` varchar(255) DEFAULT NULL,
  `flate_house_shop_number` varchar(255) DEFAULT NULL,
  `identity_proof` varchar(255) DEFAULT NULL,
  `is_bangladeshi` bit(1) NOT NULL,
  `is_ex_serviceman` bit(1) NOT NULL,
  `is_foreigner` bit(1) NOT NULL,
  `is_freedom_fighter` bit(1) NOT NULL,
  `is_physically_chanllenged` bit(1) NOT NULL,
  `is_social_activities` bit(1) NOT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `members_login_id` varchar(255) DEFAULT NULL,
  `membership_date` date DEFAULT NULL,
  `monthly_maintenance_rate` double NOT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `permanent_or_previous_address` varchar(255) DEFAULT NULL,
  `register_phone_number` varchar(255) DEFAULT NULL,
  `residential_type` varchar(255) DEFAULT NULL,
  `son_of_dauhther_of_husband` varchar(255) DEFAULT NULL,
  `total_area` double NOT NULL,
  `total_monthly_charge` double NOT NULL,
  `unit_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_info`
--

LOCK TABLES `membership_info` WRITE;
/*!40000 ALTER TABLE `membership_info` DISABLE KEYS */;
/*!40000 ALTER TABLE `membership_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `membership_info_seq`
--

DROP TABLE IF EXISTS `membership_info_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `membership_info_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `membership_info_seq`
--

LOCK TABLES `membership_info_seq` WRITE;
/*!40000 ALTER TABLE `membership_info_seq` DISABLE KEYS */;
INSERT INTO `membership_info_seq` VALUES (1);
/*!40000 ALTER TABLE `membership_info_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parking_allotment`
--

DROP TABLE IF EXISTS `parking_allotment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parking_allotment` (
  `allotment_no` int NOT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `member_code` varchar(255) DEFAULT NULL,
  `parking_area` varchar(255) DEFAULT NULL,
  `vehicle_registration_no` varchar(255) DEFAULT NULL,
  `vehicle_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`allotment_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parking_allotment`
--

LOCK TABLES `parking_allotment` WRITE;
/*!40000 ALTER TABLE `parking_allotment` DISABLE KEYS */;
INSERT INTO `parking_allotment` VALUES (1,NULL,NULL,NULL,NULL,NULL),(2,'fdsa','dfsf','sofa','fed','fdsa');
/*!40000 ALTER TABLE `parking_allotment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `parking_allotment_seq`
--

DROP TABLE IF EXISTS `parking_allotment_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `parking_allotment_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parking_allotment_seq`
--

LOCK TABLES `parking_allotment_seq` WRITE;
/*!40000 ALTER TABLE `parking_allotment_seq` DISABLE KEYS */;
INSERT INTO `parking_allotment_seq` VALUES (101);
/*!40000 ALTER TABLE `parking_allotment_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rent_table`
--

DROP TABLE IF EXISTS `rent_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rent_table` (
  `rent_id` int NOT NULL,
  `advance_rent` double NOT NULL,
  `release_date` date DEFAULT NULL,
  `rent_date` date DEFAULT NULL,
  `rent_per_month` double NOT NULL,
  `tenant_id` int NOT NULL,
  PRIMARY KEY (`rent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rent_table`
--

LOCK TABLES `rent_table` WRITE;
/*!40000 ALTER TABLE `rent_table` DISABLE KEYS */;
/*!40000 ALTER TABLE `rent_table` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rent_table_seq`
--

DROP TABLE IF EXISTS `rent_table_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rent_table_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rent_table_seq`
--

LOCK TABLES `rent_table_seq` WRITE;
/*!40000 ALTER TABLE `rent_table_seq` DISABLE KEYS */;
INSERT INTO `rent_table_seq` VALUES (1);
/*!40000 ALTER TABLE `rent_table_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `society_information`
--

DROP TABLE IF EXISTS `society_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `society_information` (
  `society_id` bigint NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `long_name` varchar(255) DEFAULT NULL,
  `zip_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`society_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `society_information`
--

LOCK TABLES `society_information` WRITE;
/*!40000 ALTER TABLE `society_information` DISABLE KEYS */;
INSERT INTO `society_information` VALUES (1,NULL,'fed',NULL,'fas',NULL,'dasf'),(2,'ui','dkfk','jfdk','fdkjsf','nondlsa','343'),(3,'trger','dasf','fefe','saf','dsafe','fdsae');
/*!40000 ALTER TABLE `society_information` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `society_information_seq`
--

DROP TABLE IF EXISTS `society_information_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `society_information_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `society_information_seq`
--

LOCK TABLES `society_information_seq` WRITE;
/*!40000 ALTER TABLE `society_information_seq` DISABLE KEYS */;
INSERT INTO `society_information_seq` VALUES (101);
/*!40000 ALTER TABLE `society_information_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `tenant_id` int NOT NULL,
  `nid` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `job` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `parmanent_address` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `total_member` int NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_seq`
--

DROP TABLE IF EXISTS `tenant_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_seq`
--

LOCK TABLES `tenant_seq` WRITE;
/*!40000 ALTER TABLE `tenant_seq` DISABLE KEYS */;
INSERT INTO `tenant_seq` VALUES (1);
/*!40000 ALTER TABLE `tenant_seq` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor`
--

DROP TABLE IF EXISTS `visitor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor` (
  `visitor_id` int NOT NULL,
  `entry_date` date DEFAULT NULL,
  `out_date` date DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `tenant_id` int NOT NULL,
  `tenant_name` varchar(255) DEFAULT NULL,
  `tenant_phone` varchar(255) DEFAULT NULL,
  `total_day_stay` int NOT NULL,
  `visitor_name` varchar(255) DEFAULT NULL,
  `visitor_phone` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`visitor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor`
--

LOCK TABLES `visitor` WRITE;
/*!40000 ALTER TABLE `visitor` DISABLE KEYS */;
/*!40000 ALTER TABLE `visitor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visitor_seq`
--

DROP TABLE IF EXISTS `visitor_seq`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visitor_seq` (
  `next_val` bigint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visitor_seq`
--

LOCK TABLES `visitor_seq` WRITE;
/*!40000 ALTER TABLE `visitor_seq` DISABLE KEYS */;
INSERT INTO `visitor_seq` VALUES (1);
/*!40000 ALTER TABLE `visitor_seq` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-01  7:23:53
