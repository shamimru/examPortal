package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.exam.models.Question;
import com.exam.models.Quizz;

public class DAO {

	Connection con;
	PreparedStatement stm;

	public void saveRegistration(RegistrationModel r) {

		try {

//			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("insert into registration values(?,?,?,?,?,?,?)");

			stm.setInt(1, r.getRegistration_id());
			stm.setString(2, r.getUsername());
			stm.setString(3, r.getPassword());
			stm.setString(4, r.getFirstname());
			stm.setString(5, r.getLastname());
			stm.setString(6, r.getEmail());
			stm.setString(7, r.getPhone());

			stm.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public RegistrationModel login(int id, String password) {
		RegistrationModel r = null;
		try {
//			System.out.println(con);
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("select * from registration where registration_id=? and password=?");

			stm.setInt(1, id);
			stm.setString(2, password);

			ResultSet re = stm.executeQuery();
			while (re.next()) {
				r = new RegistrationModel(re.getInt(1), re.getString(2), re.getString(3), re.getString(4),
						re.getString(5), re.getString(6), re.getString(7));
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return r;
	}

	public void saveDescription(Description d) {

		try {
			System.out.println(d);
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("insert into categories values (?,?,?)");

			stm.setInt(1, d.category_id);

			stm.setString(2, d.getTitle());
			stm.setString(3, d.getDescription());

			stm.executeUpdate();
			stm.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public List<Description> showAllCategory() {
		List<Description> s_list = new ArrayList<>();

		try {
//				System.out.println();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("select * from categories");

			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				s_list.add(new Description(rs.getInt(1), rs.getString(2), rs.getString(3)));
			}
			stm.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		return s_list;
	}
	
	
//	getting quiz by id
	


//	public Patient searchById(int id) {
//		Patient data = null;
//		try {
//			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/hospital", "root", "root");
//			PreparedStatement st=con.prepareStatement("select * from appointment where a_id=?");
//			st.setInt(1,id);
//			
//
//			ResultSet rs=st.executeQuery();
//			System.out.println("Hello");
//			while(rs.next()) {
//				data = new Patient(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
//			}
//		}catch(Exception e) {
//		
//		}
//		return data;
//	}

	public Patient searchById(int id) {
		Patient data = null;
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/registration", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("select * from appointment where a_id=?");
			st.setInt(1, id);

			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				data = new Patient(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
			}
		} catch (Exception e) {

		}
		return data;
	}

	public List<RegistrationModel> showallData() {

		List<RegistrationModel> reModel = new ArrayList<>();

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			Statement st = con.createStatement();

			ResultSet rs = st.executeQuery("select * from registration");

			while (rs.next()) {
				reModel.add(new RegistrationModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7)));

			}

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return reModel;

	}

	public RegistrationModel getDataById(int id) {
		RegistrationModel data = null;
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("select * from registration where registration_id=?");
			st.setInt(1, id);

			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				data = new RegistrationModel(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7));
			}

			con.close();
		} catch (Exception e) {

		}
		return data;

	}

//	Add quiz

	public void addQuizz(Quizz q) {
		System.out.println("saving quizz");

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("insert into quiz values(?,?,?,?,?,?,?)");
			st.setInt(1, q.getQuiz_id());
			st.setString(2, q.getTitle());
			st.setString(3, q.getDescription());
			st.setInt(4, q.getMax_marks());
			st.setInt(5, q.getNo_of_question());
			st.setBoolean(6, q.isPublish());
			st.setInt(7, q.getCategory_id_fk());

			st.executeUpdate();

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}

//	delete by id
	public int deleteById(int id) {
		int execute = 0;
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("delete from registration where registration_id=?");
			st.setInt(1, id);

			execute = st.executeUpdate();

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return execute;

	}

//	updating registration 
	public void updateRegistration(RegistrationModel r) {
		String msg="";
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st=con.prepareStatement("update registration set username=?,  password=? , firstname=?, lastname=?, email=? ,phone=? where registration_id=?");
			
			st.setString(1, r.getUsername());
			st.setString(2, r.getPassword());
			st.setString(3, r.getFirstname());
			st.setString(4, r.getLastname());
			st.setString(5, r.getEmail());
			st.setString(6, r.getPhone());
			st.setInt(7,r.getRegistration_id());
			
			
			 st.executeUpdate();

			con.close();
		
		
			msg="Successfully updated";
		}catch(Exception e) {
			System.out.println(e);
			msg=e.toString();
		}
		
		
	}
	
	
	
//	getting all quizzes
	
	public List<Quizz> getAllquizz(){
		List<Quizz> slist=new ArrayList<>();
		try {
//			System.out.println();
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
		stm = con.prepareStatement("select * from quiz");

	
		ResultSet rs = stm.executeQuery();
		while (rs.next()) {
			slist.add(new Quizz(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getInt(4),rs.getInt(5),rs.getBoolean(6),rs.getInt(7)));
		}
		stm.close();

	} catch (Exception e) {
		System.out.println(e);
	}
	return slist;
		
		
	}
	
	
	
//	getting quizz by id
	
	public Quizz getQuizById(int quizz_id) {
		
		Quizz r = null;
		try {
//			System.out.println(con);
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("select * from quiz where quiz_id=?");

			stm.setInt(1, quizz_id);

			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
		
				r = new Quizz(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getBoolean(6), rs.getInt(7) );
			}

			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

	
		return r;
	}
	
//	get quizz by id
	
	public Quizz getQuizz_by_id(int quizz_id) {
		Quizz data = null;
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("select * from quiz where quiz_id=?");
			st.setInt(1, quizz_id);

			
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				data = new Quizz(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4), rs.getInt(5) , rs.getBoolean(6) , rs.getInt(7));
			}

			con.close();
		} catch (Exception e) {

		}
		return data;
	}
	
	
	
	
//	updatting quizz
	public int updateQuizz(Quizz q) {
		int msg=0;
		try {
//			System.out.println();
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
		stm = con.prepareStatement("update  quiz  set title=?, description=?, max_marks=?,  no_of_question=?, is_publish=?, category_id_fk=?  where quiz_id=?");
		stm.setString(1, q.getTitle());
		stm.setString(2, q.getDescription());
		stm.setInt(3, q.getMax_marks());
		stm.setInt(4, q.getNo_of_question());
		stm.setBoolean(5, q.isPublish());
		stm.setInt(6, q.getCategory_id_fk());
		stm.setInt(7, q.getQuiz_id());

		
		int executeUpdate = stm.executeUpdate();
		msg=executeUpdate;
		
		stm.close();

	} catch (Exception e) {
		System.out.println(e);
	}
		return msg;
		
	}
	
	
//	delete quizz by id
	
	public String deleteQuizzBy_id(int quizz_id) {
		String msg = "";
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("delete from quiz where quiz_id=?");
			st.setInt(1, quizz_id);

			int execute = st.executeUpdate();
			if(execute>0) {
				msg="Delete successful";
			}

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

		return msg;
		
	}
	
	
	
//	getting question 
	
	public List<Question> getAllQuestions(int quiz_id){
		List<Question> qlist=new ArrayList<>();
		try {
//			System.out.println();
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
		stm = con.prepareStatement("select * from question where quiz_id=?");
		stm.setInt(1, quiz_id);

	
		ResultSet rs = stm.executeQuery();
		

		
		while (rs.next()) {
			qlist.add(new Question(rs.getLong(1),rs.getInt(2),  rs.getString(3), rs.getString(4), rs.getString(5) , rs.getString(6) , rs.getString(7) ,rs.getString(8) , rs.getString(9) ));
			
			
		}
		stm.close();

	} catch (Exception e) {
		System.out.println(e);
	}
	return qlist;
		
		
	}	
	
	
//	saving question
	
	public void savingQuestion(Question q) {
		System.out.println("saving Question");

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("insert into question values(?,?,?,?,?,?,?,?,?)");
			
			
			
			st.setLong(1, q.getQuestionId());
			st.setInt(2, q.getQuiz_id());
			st.setString(3, q.getContent());
			st.setString(4, q.getImage());
			st.setString(5, q.getOption_1());
			st.setString(6, q.getOption_2());
			st.setString(7, q.getOption_3());
			st.setString(8, q.getOption_3());
			st.setString(9, q.getAnswer());
			
			st.executeUpdate();
			System.out.println("saving question");

			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	} 
	
	
	public void saveQuestion(Question q) {
		

		try {

			Class.forName("com.mysql.jdbc.Driver");

			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("insert into question values(?,?,?,?,?,?,?,?,?)");

			stm.setLong(1,q.getQuestionId());
			stm.setInt(2, q.getQuiz_id());
			stm.setString(3, q.getContent());
			stm.setString(4, q.getImage());
			stm.setString(5, q.getOption_1());
			stm.setString(6, q.getOption_2());
			stm.setString(7, q.getOption_3());
			stm.setString(8, q.getOption_4());
			stm.setString(9, q.getAnswer());

			

			int totalUpdate = stm.executeUpdate();
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
//	Deleting Question by id
	public void deleteQuestionById(int questionId){
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("delete from question where questionId=?");
			st.setInt(1, questionId);

			int execute = st.executeUpdate();
			
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	
//	getting Question by id 
	public List<Question> getQuestionBy_id(int question_id) {
	  List<Question> questionById= new ArrayList<>();
		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st = con.prepareStatement("select *  from question where questionId=?");
			st.setInt(1, question_id);

			 ResultSet rs = st.executeQuery();
			 			
			 while(rs.next()) {
				 questionById.add(new Question(rs.getLong(1), rs.getInt(2) , rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9)));
			 }
			
			con.close();

		} catch (Exception e) {
			System.out.println(e);
		}
		
		return questionById;
	}
	
//	updatting question by id

	public void updateQuestionById(Question q) {
		try {
//			System.out.println();
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
						
			stm = con.prepareStatement(
					"update  question  set content=?, option_1=?, option_2=?,  option_3=?, option_4=?, answer=?  where questionId=?");
			stm.setString(1, q.getContent());
			stm.setString(2, q.getOption_1());
			stm.setString(3, q.getOption_2());
			stm.setString(4, q.getOption_3());
			stm.setString(5, q.getOption_4());
			stm.setString(6, q.getAnswer());
			stm.setLong(7, q.getQuestionId());
            System.out.println(q);
			System.out.println("updating question");
			stm.executeUpdate();

			stm.close();

		} catch (Exception e) {
			System.out.println(e);
		}

	}
	
	
	
//	getting the quizz of category
	
	public List<Quizz> getQuizzOfCategory(int quizzId) {
		List<Quizz> quizzOfList =new ArrayList<>();
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("select * from quiz where category_id_fk=?");
			stm.setInt(1, quizzId);
			ResultSet rs = stm.executeQuery();
		
			while(rs.next()) {
				quizzOfList.add(new Quizz(rs.getInt(1), rs.getString(2) , rs.getString(3) , rs.getInt(4) , rs.getInt(5), rs.getBoolean(6), rs.getInt(7)));
			}
			
		}catch(Exception e) {
			System.out.println(e);
			
		}
		return quizzOfList;
	}
	
	
//	get Active Quiz by id
	public List<Quizz> getActiveQuizzBy_id(boolean activeQuiz) {
		List<Quizz> quizzOfList =new ArrayList<>();
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm = con.prepareStatement("select * from quiz where is_publish=?");
			stm.setBoolean(1, activeQuiz);
			ResultSet rs = stm.executeQuery();
		
			while(rs.next()) {
				quizzOfList.add(new Quizz(rs.getInt(1), rs.getString(2) , rs.getString(3) , rs.getInt(4) , rs.getInt(5), rs.getBoolean(6), rs.getInt(7)));
			}
			
		}catch(Exception e) {
			System.out.println(e);
			
		}
		return quizzOfList;
	}
	
	
//	end of class
}
	


