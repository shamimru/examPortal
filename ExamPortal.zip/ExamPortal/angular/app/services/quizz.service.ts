import { Injectable } from '@angular/core';
import { Quizz } from '../Models/quizz';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import baseUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class QuizzService {

  constructor(
    private _http:HttpClient,
    private _quizzservice:QuizzService

  ) { }

  url:any;
  


  // showallRegistrationdata():Observable<Registration>{
  //   this.url="http://localhost:8080/getalldata";
  //   return this.http.get<Registration>(this.url)
  // }
  // url:any;
  // register(r:Registration):Observable<Registration>{
  //   this.url="http://localhost:8080/save"
  //   return this.http.post<Registration>(this.url,r);
  // }

}
