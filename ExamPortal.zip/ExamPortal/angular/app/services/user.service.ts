import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';
import { Registration } from '../Models/registration';
import { Observable } from 'rxjs';
import { Patient } from '../Models/patient';
import { Quizz } from '../Models/quizz';
import { Questions } from '../Models/questions';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  // add user

  public addUser(user:any){
    return this.http.post(`${baseUrl}/user/`,user);
  }

  url:any;
  register(r:Registration):Observable<Registration>{
    this.url="http://localhost:8080/save"
    return this.http.post<Registration>(this.url,r);
  }

  logIn(id:any,password:any):Observable<Registration>{
    this.url="http://localhost:8080/login/";
    return this.http.get<Registration>(this.url+id+"/"+password);
  }

  searchDataById(id:any):Observable<Patient>{
    this.url="http://localhost:8080/getdatabyid/";
    return this.http.get<Patient>(this.url+id);
  }

  showallRegistrationdata():Observable<Registration>{
    this.url="http://localhost:8080/getalldata";
    return this.http.get<Registration>(this.url)
  }

  delete_by_id(id:any):Observable<Registration>{
    this.url="http://localhost:8080/admin/deleteById/";
    return this.http.delete<Registration>(this.url+id);
  }

  // getAllCategory():Observable<AddCategory>{
  //   this.url="http://localhost:8080/getallcategory";
  //   return this._http.get<AddCategory>(this.url);
  // }


  alldata:any
  getRegistrationDataById(registration_id:any):Observable<Registration>{
    this.url="http://localhost:8080/getdatabyid/";
    // alert("service registraron by id")
    this.alldata=this.http.get<Registration>(this.url+registration_id)
    return this.alldata
  }



  // updatting registraron
  msg:any;
  updateRegistration(r:Registration):Observable<Registration>{
    this.url="http://localhost:8080/admin/updateregistration";
    return  this.http.put<Registration>(this.url,r);
  }


  // saving quizz

  saveQuizz(quiz:Quizz):Observable<Quizz>{
    this.url="http://localhost:8080/admin/saveQuizz";
    return this.http.post<Quizz>(this.url,quiz)

  }

  // getting all quizzes

  
  getAllQuizzes():Observable<Quizz>{
    this.url="http://localhost:8080/admin/getAllQuizz";
    return this.http.get<Quizz>(this.url);

  }


  getQuizzBy_id(quizz_id:any):Observable<Quizz>{
    this.url="http://localhost:8080/admin/getQuizById/";
    return this.http.get<Quizz>(this.url+quizz_id);
  }

  // updatting quizz by id

  updateQuiz_by_id(q:Quizz):Observable<Quizz>{
    this.url="http://localhost:8080/admin/updateQuizz";
    return this.http.put<Quizz>(this.url,q);

  }

  // deleting quizz by id

  deleteQuizz_by_id(quizz_id:any):Observable<any>{
    this.url="http://localhost:8080/admin/deleteQuizById/";
    return this.http.delete<any>(this.url+quizz_id);
    }


    // getting all question 
    getQuestionOfQuizz(quiz_id:any):Observable<Questions>{
      this.url="http://localhost:8080/admin/getAllQuestions/";
      return this.http.get<Questions>(this.url+quiz_id);
    }

    // adding question 
    saveQuestions(q:Questions):Observable<Questions>{
      this.url="http://localhost:8080/admin/savingQuestion";

      return this.http.post<Questions>(this.url,q);
    }


    // deleting question by id 
    deleteQuestionById(questionId:any):Observable<Questions>{
      this.url="http://localhost:8080/admin/deleteQuestionById/";
      return this.http.delete<Questions>(this.url+questionId);
    }


    // getting question by id 
    getQuestionBy_id(questionId:any):Observable<Questions>{
      this.url="http://localhost:8080/admin/getQuestionBy_id/";
      return this.http.get<Questions>(this.url+questionId);
    }

    // update question by quistion id 
    updateQuestion_by_id(q:Questions):Observable<Questions>{
      this.url="http://localhost:8080/admin/updateQuestionById";
      alert("service update question")
      return this.http.put<Questions>(this.url,q);

    }

    // getting quiz of category 
    getQuizzOfCategoryId(categoryId:any):Observable<Quizz>{
      this.url="http://localhost:8080/user/getQuizzOfCategoryId/";
      return this.http.get<Quizz>(this.url+categoryId);
    }

    // getting active quizz 
    getActiveQuizzBy_id(activeQuizz:any):Observable<Quizz>{
      this.url="http://localhost:8080/user/getActiveQuizzBy_id/";
      return this.http.get<Quizz>(this.url+activeQuizz)

    }
  // end of class
}
