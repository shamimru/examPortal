import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.css']
})
export class InstructionsComponent implements OnInit {

  constructor(
    private _route:ActivatedRoute,
    private _userService:UserService,
    private _snak:MatSnackBar,
    private _router:Router
  ) { }

  quiz_id:any;
  quizzesBy_Id:any
  ngOnInit(): void {


    this.quiz_id=this._route.snapshot.params["QuizId"]
    this._userService.getQuizzBy_id(this.quiz_id).subscribe(
      (data:any)=>{
        this._snak.open('Message archived', 'Undo', {
          duration: 3000
        });
        this.quizzesBy_Id=data;
        console.log(this.quizzesBy_Id)

      },
      (error)=>{
        this._snak.open("Fail in Loading Data", "Undo",{
          duration:1500,

        })
      }
    )
  }


  startQuiz(){
    Swal.fire({
      title:"Do you want to save the changes",
      // showDenyButton:true,
      showCancelButton:true,
      confirmButtonText:"Start",
      denyButtonText:"Don't save",
      icon:"info"
    }).then(
      (result)=>{
        if(result.isConfirmed){

          this._router.navigate(["/quiz_start/"+this.quiz_id])
        }else{
          Swal.fire("Changes are not saved","","info")
        }
      }
    )
  }
  }


