import { LocationStrategy } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-quiz-start',
  templateUrl: './quiz-start.component.html',
  styleUrls: ['./quiz-start.component.css']
})
export class QuizStartComponent implements OnInit {

  constructor(
    private route:ActivatedRoute,
    private _userService:UserService,
    private location:LocationStrategy
  ) { }

  marksGot=0;
  correctAnswer=0;
  wrongAnswer:any=0;
  attempted=0;
  
  quiz_id:any
  questions_of_id:any
  quizz_by_id:any;

  allQuizz:any


  isSubmit=false;
  allGivenAnswer={

  }

  ngOnInit(): void {

    // getting all quizz 
    this._userService.getAllQuizzes().subscribe(
      (data)=>{
        
        this.allQuizz=data;
        
      }
    )

    this.preventBackButton();

    this.quiz_id=this.route.snapshot.params["QuizId"]
    console.log(this.quiz_id)
    this._userService.getQuestionOfQuizz(this.quiz_id).subscribe(
      (data:any)=>{
        this.questions_of_id=data

        this.questions_of_id.forEach((q:any) => {
          q['givenAnswer']='';
          
        });
      },
      (error)=>{
        alert("error")
      }
    )


    // get quiz by id 
    this._userService.getQuizzBy_id(this.quiz_id).subscribe(
      (quizz_by_id:any)=>{
        this.quizz_by_id=quizz_by_id;
      }
    )
  }

  

  preventBackButton(){
    history.pushState(null,"",location.href);
    this.location.onPopState(
      ()=>{
        history.pushState(null,"",location.href)
      }
    )
  
  }

  

  radioChange(event:any){
    this.questions_of_id.givenAnswer=event.target.value;
  }


  submit_quiz(){

    this.questions_of_id.forEach((q:any)=>{
      if(q.givenAnswer == q.answer){
        this.correctAnswer++
        // let marksSignle = this.questions_of_id[0].quiz.max_marks / this.questions_of_id.lenth;

        // this.marksGot+=marksSignle;


      }else{
        this.wrongAnswer++;
      }

      if(q.givenAnswer.trim() != ''){
        this.attempted++;
      }
      this.isSubmit=true;
    })
  }

}


