import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { max } from 'rxjs';
import { Quizz } from 'src/app/Models/quizz';
import { CategorySeviceService } from 'src/app/services/category-sevice.service';
import { QuizzService } from 'src/app/services/quizz.service';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-update-quizz',
  templateUrl: './update-quizz.component.html',
  styleUrls: ['./update-quizz.component.css']
})
export class UpdateQuizzComponent implements OnInit {

  constructor(
    private _route: ActivatedRoute,
    private _category: CategorySeviceService,
    private _userService: UserService,
    private router:Router

  ) { }

  allCategoryData: any

  allQuizz_of_id: any
  ngOnInit(): void {

    // Getting category
    this._category.getAllCategory().subscribe((data) => {
      this.allCategoryData = data;
    })

    // getting all quizz by id
    this.quizz_id = this._route.snapshot.params["quiz_id"];

    this._userService.getQuizzBy_id(this.quizz_id).subscribe((data_By_quizz_id_from_DB) => {
      this.allQuizz_of_id = data_By_quizz_id_from_DB;
    })
  }

  quizz_id: any;

  title: any;
  description: any
  max_marks: any
  no_of_question: any
  published: any
  category: any


  updateQuizz_data: any
  updateQuizz() {
    this.updateQuizz_data = new Quizz(this.quizz_id, this.allQuizz_of_id.title, this.allQuizz_of_id.description, this.allQuizz_of_id.max_marks, this.allQuizz_of_id.no_of_question, this.allQuizz_of_id.published, this.category);

    this._userService.updateQuiz_by_id(this.updateQuizz_data).subscribe((x: any) => {

      Swal.fire("Success !!", 'Quiz Updated', "success").then((e)=>{
        this.router.navigate(['/admin/quizzes'])
      });
    },
      (error) => {
        Swal.fire("Error !!", "error in Updating Quizz", 'error')
      }
    )
  }



}
