import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Questions } from 'src/app/Models/questions';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-edit-question',
  templateUrl: './edit-question.component.html',
  styleUrls: ['./edit-question.component.css']
})
export class EditQuestionComponent implements OnInit {

  public Editor = ClassicEditor;
  constructor(
    private route:ActivatedRoute,
    private _userService:UserService
  ) { }


  question_id:any
  quiz_title:any

  question_by_id:any
  ngOnInit(): void {

    this.question_id =this.route.snapshot.params["question_id"]
    this.quiz_title =this.route.snapshot.params["quiz_title"]

    this._userService.getQuestionBy_id(this.question_id).subscribe((questionById:any)=>{
      this.question_by_id=questionById;
    })
  }

  questionId: any
  quiz_id: any
  content: any
  image: any
  option_1: any
  option_2: any
  option_3: any
  option_4: any

  answer: any


  question:any={
    content:"",
    option_1:"",
    option_2:"",
    option_3:"",
    option_4:"",
    answer:""
  }
  question_object:any
  formSubmit(){
    this.question_object=new Questions(this.question_by_id.questionId,"", this.question_by_id.content, "",this.question_by_id.option_1, this.question_by_id.option_2, this.question_by_id.option_3, this.question_by_id.option_4, this.question_by_id.answer);
       
    this._userService.updateQuestion_by_id(this.question_object).subscribe((x)=>{
      alert("updated")
    })


  }

}
