import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { QuizzService } from 'src/app/services/quizz.service';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-quizzes',
  templateUrl: './view-quizzes.component.html',
  styleUrls: ['./view-quizzes.component.css']
})
export class ViewQuizzesComponent implements OnInit {

  constructor(
    private _userService: UserService,
    private _route: ActivatedRoute,
    private _router: Router

  ) { }

  ngOnInit(): void {

    this._userService.getAllQuizzes().subscribe((quizzes: any) => {

      this.allQuizzes_from_database = quizzes
    })
  }

  allQuizzes_from_database: any

  //  getallQuizzes(){
  //   this._userService.getAllQuizzes().subscribe((quizz:any)=>{
  //     this.allQuizzes_from_database=quizz;

  //     if(quizz !=null){
  //       alert("success")
  //     }else{
  //       alert("fail")
  //     }
  //   })
  //  }


  QuizzById: any
  update() {

    alert(this.allQuizzes_from_database.quiz_id)
    this._userService.getQuizzBy_id(this.allQuizzes_from_database.quiz_id).subscribe((quizById) => {
      if (quizById != null) {
        this.QuizzById = quizById;
      }
    })


    // refreshing

    this._userService.getAllQuizzes().subscribe((quizzes: any) => {
      this.allQuizzes_from_database = quizzes;

    })
    // this._router.navigateByUrl("updateQuizz", { state: { response: this.loginData } })
  }


  deleteFeedBackMsg: any
  // delete quizz by id 
  deleteQuizBy_id(quizz_id: any) {


    Swal.fire({
      title: "Are you Want to Delete Quiz",
      text: "your will not be able to recover Quiz",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes Delete the Quiz",
      cancelButtonText: "No Keep it"
    }).then((result) => {
      if (result.value) {
        this._userService.deleteQuizz_by_id(quizz_id).subscribe((deleteQuizById: any) => {
          this.deleteFeedBackMsg = deleteQuizById;
        })

        Swal.fire("Deleted", "Your Quiz has been deleted", "success");


        // re-freshing all quiz 
        this._userService.getAllQuizzes().subscribe((quizzes: any) => {
          this.allQuizzes_from_database = quizzes;
        })



      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your Quiz is Safe Now :) ", "error")
      }
    })



    // delete function end 
  }
}

// quizzes: any = [
//   {
//     qid: 1,
//     title: "java",
//     descrption: "Java is a high-level, general-purpose, object-oriented, and secure programming language",
//     maxMarks: "50",
//     numberOfQuestion: "20",
//     Action: "true",
//     category: {
//       title: "programming"
//     }
//   },

//   {
//     qid: 2,
//     title: "Python",
//     descrption: "basic quistion",
//     maxMarks: "50",
//     numberOfQuestion: "20",
//     Action: "true",
//     category: {
//       title: "programming"
//     }
//   },

//   {
//     qid: 3,
//     title: "javaScript",
//     descrption: "basic quistion",
//     maxMarks: "50",
//     numberOfQuestion: "20",
//     Action: "true",
//     category: {
//       title: "programming"
//     }
//   },

//   {
//     qid: 1,
//     title: "java",
//     descrption: "basic quistion",
//     maxMarks: "50",
//     numberOfQuestion: "20",
//     Action: "true",
//     category: {
//       title: "programming"
//     }
//   },

//   {
//     qid: 1,
//     title: "java",
//     descrption: "basic quistion",
//     maxMarks: "50",
//     numberOfQuestion: "20",
//     Action: "true",
//     category: {
//       title: "programming"
//     }
//   }
// ]

