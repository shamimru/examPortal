package com.exam.models;

public class Quizz {
	
	int quiz_id;
	String title;
	String description;
	int max_marks;
	int no_of_question;
	boolean publish;
	int category_id_fk;
	public Quizz() {
		super();
	}
	public Quizz(int quiz_id, String title, String description, int max_marks, int no_of_question, boolean publish,
			int category_id_fk) {
		super();
		this.quiz_id = quiz_id;
		this.title = title;
		this.description = description;
		this.max_marks = max_marks;
		this.no_of_question = no_of_question;
		this.publish = publish;
		this.category_id_fk = category_id_fk;
	}
	public int getQuiz_id() {
		return quiz_id;
	}
	public void setQuiz_id(int quiz_id) {
		this.quiz_id = quiz_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMax_marks() {
		return max_marks;
	}
	public void setMax_marks(int max_marks) {
		this.max_marks = max_marks;
	}
	public int getNo_of_question() {
		return no_of_question;
	}
	public void setNo_of_question(int no_of_question) {
		this.no_of_question = no_of_question;
	}
	public boolean isPublish() {
		return publish;
	}
	public void setPublish(boolean publish) {
		this.publish = publish;
	}
	public int getCategory_id_fk() {
		return category_id_fk;
	}
	public void setCategory_id_fk(int category_id_fk) {
		this.category_id_fk = category_id_fk;
	}
	@Override
	public String toString() {
		return "Quizz [quiz_id=" + quiz_id + ", title=" + title + ", description=" + description + ", max_marks="
				+ max_marks + ", no_of_question=" + no_of_question + ", publish=" + publish + ", category_id_fk="
				+ category_id_fk + "]";
	}
	
	
	
	
	
	
	

	
}
