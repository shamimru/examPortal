export class AddCategory {
    category_id:any
    title:any
    description:any;
    constructor(c_id:any,title:any,desc:any){
        this.category_id=c_id;
        this.title=title;
        this.description=desc;
    }
}
