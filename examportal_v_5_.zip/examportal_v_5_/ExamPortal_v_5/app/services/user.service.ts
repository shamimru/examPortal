import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';
import { Registration } from '../Models/registration';
import { Observable } from 'rxjs';
import { Patient } from '../Models/patient';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  // add user

  public addUser(user:any){
    return this.http.post(`${baseUrl}/user/`,user);
  }

  url:any;
  register(r:Registration):Observable<Registration>{
    this.url="http://localhost:8080/save"
    return this.http.post<Registration>(this.url,r);
  }

  logIn(id:any,password:any):Observable<Registration>{
    this.url="http://localhost:8080/login/";
    return this.http.get<Registration>(this.url+id+"/"+password);
  }

  searchDataById(id:any):Observable<Patient>{
    this.url="http://localhost:8080/search/";
    return this.http.get<Patient>(this.url+id);
  }

  showallRegistrationdata():Observable<Registration>{
    this.url="http://localhost:8080/getalldata";
    return this.http.get<Registration>(this.url)
  }

  // getAllCategory():Observable<AddCategory>{
  //   this.url="http://localhost:8080/getallcategory";
  //   return this._http.get<AddCategory>(this.url);
  // }


  alldata:any
  getRegistrationDataById(registration_id:any):Observable<Registration>{
    this.url="localhost:8080/getdatabyid/";
    // alert("service registraron by id")
    this.alldata=this.http.get<Registration>(this.url+registration_id)
    alert(this.alldata)
    console.log(this.alldata)
    return this.alldata
  }
}
