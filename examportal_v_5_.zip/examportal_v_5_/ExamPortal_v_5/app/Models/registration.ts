export class Registration {

    getRegistration_id:any;
    username:any;
    password:any;
    firstname:any;
    lastname:any;
    email:any;
    phone:any;

    constructor(getRegistration_id:any,u:any,pass:any,fname:any,lname:any,email:any,phone:any){
        this.getRegistration_id=getRegistration_id;
        this.username=u;
        this.password=pass;
        this.firstname=fname;
        this.lastname=lname;
        this.email=email;
        this.phone=phone;
    }
}
