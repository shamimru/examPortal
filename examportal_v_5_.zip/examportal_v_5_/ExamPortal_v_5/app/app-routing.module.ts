import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';

import { ViewCategoriesComponent } from './components/Admin/view-categories/view-categories.component';

import { ProfileComponent } from './components/Admin/profile/profile.component';
import { ShowdatabyidComponent } from './components/Admin/showdatabyid/showdatabyid.component';
import { AddCategoryComponent } from './components/Admin/add-category/add-category.component';
import { HomeComponent } from './components/pages/home/home.component';
import { SignupComponent } from './components/pages/signup/signup.component';
import { SigninComponent } from './components/pages/signin/signin.component';
import { SuccessComponent } from './components/pages/success/success.component';
import { WelcomeComponent } from './components/pages/welcome/welcome.component';
import { ViewQuizzesComponent } from './components/Admin/view-quizzes/view-quizzes.component';
import { AddQuizComponent } from './components/Admin/add-quiz/add-quiz.component';
import { ShowAllDataComponent } from './components/Admin/show-all-data/show-all-data.component';
import { EditRegisterDataComponent } from './components/Admin/edit-register-data/edit-register-data.component';


const routes: Routes = [
  {path:"", component:HomeComponent,pathMatch:"full"},
  {path:"signup", component:SignupComponent,pathMatch:"full"},
  {path:"login", component:SigninComponent,pathMatch:"full"},
  {path:"admin", component:DashboardComponent,pathMatch:"full"},
  // {path:"success", component:SuccessComponent,pathMatch:"full"},
  {
     path:"admin",
     component:DashboardComponent,
     children:[
      {
        path:"",
        component:WelcomeComponent
      },
      {path:'profile',
      component:ProfileComponent
      },
      {
        path:'showDataById',
        component:ShowdatabyidComponent
      },
      {
        path:"categories",
        component:ViewCategoriesComponent
      },

      {
        path:"add-category",
        component:AddCategoryComponent
      },
      {
        path:"quizzes",
        component:ViewQuizzesComponent
      },

      {
        path:"addquiz",
        component:AddQuizComponent
      },
      {
        path:"showAllData",
        component:ShowAllDataComponent
      },
      {
        path:"editRegistryData/:registration_id",
         component:EditRegisterDataComponent
        },

      

      

      // {
      //   path:'dashboard',component:DashboardComponent
      // }

      
     
     ]
    
    
    },
    



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
