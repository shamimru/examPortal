import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-edit-register-data',
  templateUrl: './edit-register-data.component.html',
  styleUrls: ['./edit-register-data.component.css']
})
export class EditRegisterDataComponent implements OnInit {

  constructor(private _myservice:UserService,
    private route:ActivatedRoute

  ) { 
 
    // _myservice.showalldata().subscribe((data)=>{
    //   this.old_register_data=data;
      // this.registration_id=data.registration_id.
    // })

  }

  registration_id: any;
  username: any;
  password: any
  firstname: any
  lastname: any
  email: any
  phone: any

 

  regis_id:any;



  ngOnInit(): void {
    this.regis_id=this.route.snapshot.paramMap.get('registration_id');
    alert(this.regis_id);
    this._myservice.getRegistrationDataById(this.regis_id).subscribe((res)=>{

      alert(res)
    },
  (error)=>{
    alert("error")
  }
  
  )

  }


  }


