import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-show-all-data',
  templateUrl: './show-all-data.component.html',
  styleUrls: ['./show-all-data.component.css']
})
export class ShowAllDataComponent implements OnInit {

  constructor(private _myservice: UserService,
    private router:Router,
    private _snack:MatSnackBar
  ) { }

  showAllData: any = []


 
  ngOnInit(): void {

    this._myservice.showallRegistrationdata().subscribe((data) => {

      // alert("hello")
      if(data != null){
        // Swal.fire("Success", "Success in Loading Data", "success");
        this._snack.open("Successfully Added all Data", '',
        {
          duration: 3000,
          verticalPosition: 'top',
          horizontalPosition: 'center'
        })
      }

      setTimeout(() => {
        if (data != null) {
          this.showAllData = data;
        }
      }, 3000);
    },
      (error) => {
        Swal.fire("Error !!", "Error in Loadig data", "error");
      }
    )
  }




}









