import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-quiz',
  templateUrl: './add-quiz.component.html',
  styleUrls: ['./add-quiz.component.css']
})
export class AddQuizComponent implements OnInit {
color: any;
checked: any;
disabled: any;

  constructor() { }

  ngOnInit(): void {
  }


  category:any=[
  {
    cid:1,
    title:"programming"
  },
  {
    cid:2,
    title:"gamming"
  },
  {
    cid:3,
    title:"drama"
  },
  {
    cid:4,
    title:"magazin"
  },
  {
    cid:5,
    title:"programming"
  }
]
}
