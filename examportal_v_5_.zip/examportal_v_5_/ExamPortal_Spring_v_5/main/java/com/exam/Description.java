package com.exam;

public class Description {

	int description_id;
	String title;
	String description;
	public Description() {
		super();
	}
	public Description(int description_id, String title, String description) {
		super();
		this.description_id = description_id;
		this.title = title;
		this.description = description;
	}
	public int getDescription_id() {
		return description_id;
	}
	public void setDescription_id(int description_id) {
		this.description_id = description_id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	@Override
	public String toString() {
		return "Description [description_id=" + description_id + ", title=" + title + ", description=" + description
				+ "]";
	}
	
	
}
