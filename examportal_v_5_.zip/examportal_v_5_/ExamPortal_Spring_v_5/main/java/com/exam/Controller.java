package com.exam;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class Controller {
	
	
	@PostMapping("/save")
	public void saveRegistration(@RequestBody RegistrationModel r) {
		
		DAO dao=new DAO();
		dao.saveRegistration(r);
		
	}
	
	@GetMapping("/login/{id}/{password}")
	public RegistrationModel login(@PathVariable int id,@PathVariable String password) {
		
		DAO dao= new DAO();
		RegistrationModel data = dao.login(id, password);
		
		return data;
	}
	
	@GetMapping("/search/{id}")
	public Patient search(@PathVariable int id) {
		
		DAO dao= new DAO();
		Patient data = dao.searchById(id);
		
		return data;
	}
	
	
	
	
	@PostMapping("/savecategory")
	public void saveCategory(@RequestBody Description d) {
		
		DAO dao=new DAO();
		dao.saveDescription(d);
		
	}
	
	
	List<Description> allDescription=new ArrayList<>();
	@GetMapping("/getallcategory")
	public List<Description> getAllCategory() {
		
		DAO dao= new DAO();
		allDescription = dao.showAllCategory();
		
		return allDescription;
	}
	
//	
//	@GetMapping("/addcategory/{id}/{title}/{description}")
//	public Description saveCategory(@PathVariable int id,@PathVariable String title,@PathVariable String description) {
//		
//		DAO dao= new DAO();
//		Description data = dao.saveDescription(id,title,description);
//		
//		return data;
//	}
	
	@GetMapping("/getalldata")
	public List<RegistrationModel> getAllData(){
		DAO dao=new DAO();
		List<RegistrationModel> data = dao.showallData();
		
		return data;
		
	}
	
	@GetMapping("/getdatabyid/{id}")
	public RegistrationModel getDataById(@PathVariable int id){
		DAO dao=new DAO();
		RegistrationModel data = dao.getDataById(id);
		
		return data;
		
	}

}
