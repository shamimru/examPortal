package com.exam.models;

public class Quizz {
	
	int q_id;
	String active;
	String description;
	String maxMarks;
	String number_of_questions;
	String title;
	public Quizz() {
		super();
	}
	public Quizz(int q_id, String active, String description, String maxMarks, String number_of_questions,
			String title) {
		super();
		this.q_id = q_id;
		this.active = active;
		this.description = description;
		this.maxMarks = maxMarks;
		this.number_of_questions = number_of_questions;
		this.title = title;
	}
	public int getQ_id() {
		return q_id;
	}
	public void setQ_id(int q_id) {
		this.q_id = q_id;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getMaxMarks() {
		return maxMarks;
	}
	public void setMaxMarks(String maxMarks) {
		this.maxMarks = maxMarks;
	}
	public String getNumber_of_questions() {
		return number_of_questions;
	}
	public void setNumber_of_questions(String number_of_questions) {
		this.number_of_questions = number_of_questions;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	@Override
	public String toString() {
		return "Quizz [q_id=" + q_id + ", active=" + active + ", description=" + description + ", maxMarks=" + maxMarks
				+ ", number_of_questions=" + number_of_questions + ", title=" + title + "]";
	}
	
	
	

	
}
