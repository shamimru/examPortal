package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;



public class DAO {
	
	Connection con;
	PreparedStatement stm;
	
	
	public  void saveRegistration(RegistrationModel r) {
		
		try {
			
//			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
			stm=con.prepareStatement("insert into registration values(?,?,?,?,?,?,?)");
			
			stm.setInt(1, r.getRegistration_id());
			stm.setString(2, r.getUsername());
			stm.setString(3, r.getPassword());
			stm.setString(4, r.getFirstname());
			stm.setString(5, r.getLastname());
			stm.setString(6, r.getEmail());
			stm.setString(7, r.getPhone());
			
			int totalUpdate = stm.executeUpdate();
			con.close();
			System.out.println(totalUpdate);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public RegistrationModel login(int id,String password) {
		RegistrationModel r=null;
		try {
//			System.out.println(con);
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
            stm=con.prepareStatement("select * from registration where registration_id=? and password=?");
            
			
			stm.setInt(1,id);
			stm.setString(2, password);
			
			ResultSet re=stm.executeQuery();
			while (re.next()) {
				r=new RegistrationModel(re.getInt(1),re.getString(2),re.getString(3),re.getString(4),re.getString(5),re.getString(6),re.getString(7));
			}

			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
		
		return r;
	}
	
	
	public void saveDescription(Description d) {
		
		try {
			System.out.println(d);
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
            stm=con.prepareStatement("insert into categories values (?,?,?)");
            
			
			stm.setInt(1,d.getDescription_id());

			stm.setString(2,d.getTitle());
			stm.setString(3, d.getDescription());
			
			int executeUpdate = stm.executeUpdate();
			System.out.println(executeUpdate);
			stm.close();

		}catch(Exception e) {
			System.out.println(e);
		}
		
		
	}
	
	
	
	public List<Description> showAllCategory() {
		List<Description>  s_list = new ArrayList<>();

			try {
//				System.out.println();
				con=DriverManager.getConnection("jdbc:mysql://localhost:3306/examportal", "root", "01799832253aa");
	            stm=con.prepareStatement("select * from categories");
	            
				ResultSet rs = stm.executeQuery();
				while(rs.next()) {
					s_list.add(new Description(rs.getInt(1),rs.getString(2),rs.getString(3)));
				}
				System.out.println(s_list);
				stm.close();

			}catch(Exception e) {
				System.out.println(e);
			}
		return s_list;
	}
	
	
	
//	public Patient searchById(int id) {
//		Patient data = null;
//		try {
//			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/hospital", "root", "root");
//			PreparedStatement st=con.prepareStatement("select * from appointment where a_id=?");
//			st.setInt(1,id);
//			
//
//			ResultSet rs=st.executeQuery();
//			System.out.println("Hello");
//			while(rs.next()) {
//				data = new Patient(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
//			}
//		}catch(Exception e) {
//		
//		}
//		return data;
//	}
	
	
	public Patient searchById(int id) {
		Patient data = null;
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/registration", "root", "01799832253aa");
			PreparedStatement st=con.prepareStatement("select * from appointment where a_id=?");
			st.setInt(1,id);
			

			ResultSet rs=st.executeQuery();
			while(rs.next()) {
				data = new Patient(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			}
		}catch(Exception e) {
		
		}
		return data;
	}
	
	
	public List<RegistrationModel>showallData(){
		
		List<RegistrationModel> reModel=new ArrayList<>();
		
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			Statement st=con.createStatement();
			
			 ResultSet rs = st.executeQuery("select * from registration");
			 
			while(rs.next()) {
				reModel.add(new RegistrationModel(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)));
				
			}
			
			con.close();
			
		
			
		}catch(Exception e) {
			System.out.println(e);
		}
		
		return reModel;
		
	}
	
	
	public RegistrationModel getDataById(int id) {
		RegistrationModel data = null;
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost/examportal", "root", "01799832253aa");
			PreparedStatement st=con.prepareStatement("select * from registration where registration_id=?");
			st.setInt(1,id);
			

			ResultSet rs=st.executeQuery();
			while(rs.next()) {
				data = new RegistrationModel(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7));
			}
		}catch(Exception e) {
		
		}
		return data;
		
	}
	
	

}
