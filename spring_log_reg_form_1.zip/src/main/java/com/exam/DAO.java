package com.exam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
	
	Connection con;
	PreparedStatement stm;
	
	
	public  void saveRegistration(RegistrationModel r) {
		
		try {
			
//			Class.forName("com.mysql.jdbc.Driver");
			
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/user", "root", "01799832253aa");
			stm=con.prepareStatement("insert into userregistration values(?,?,?,?,?,?,?)");
			
			stm.setInt(1, r.getId());
			stm.setString(2, r.getUsername());
			stm.setString(3, r.getPassword());
			stm.setString(4, r.getFirstname());
			stm.setString(5, r.getLastname());
			stm.setString(6, r.getEmail());
			stm.setString(7, r.getPhone());
			
			int totalUpdate = stm.executeUpdate();
			con.close();
			System.out.println(totalUpdate);
		}catch(Exception e) {
			System.out.println(e);
		}
	}
	
	public RegistrationModel login(int id,String password) {
		RegistrationModel r=null;
		try {
			System.out.println(con);
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/exam", "root", "01799832253aa");
            stm=con.prepareStatement("insert into registration values(?,?)");
            
			
			stm.setInt(1, r.getId());
			stm.setString(2, r.getPassword());
			
			ResultSet re=stm.executeQuery();
			while (re.next()) {
				r=new RegistrationModel(re.getInt(1),re.getString(2),re.getString(3),re.getString(4),re.getString(5),re.getString(6),re.getString(7));
			}

		}catch(Exception e) {
			System.out.println(e);
		}
		
		return r;
	}

}
