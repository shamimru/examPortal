package com.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamPortalCopyApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamPortalCopyApplication.class, args);
	}

}
