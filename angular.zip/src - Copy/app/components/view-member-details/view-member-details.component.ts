import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-view-member-details',
  templateUrl: './view-member-details.component.html',
  styleUrls: ['./view-member-details.component.css']
})
export class ViewMemberDetailsComponent implements OnInit {

  showAllDetailsOfMember:any
  constructor(
    private service:ServiceService
  ) { 
    
  }

  ngOnInit(): void {
  }

}
