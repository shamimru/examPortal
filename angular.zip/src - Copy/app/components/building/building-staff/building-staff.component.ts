import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-staff',
  templateUrl: './building-staff.component.html',
  styleUrls: ['./building-staff.component.css']
})
export class BuildingStaffComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
