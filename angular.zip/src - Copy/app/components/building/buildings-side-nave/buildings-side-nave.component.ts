import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buildings-side-nave',
  templateUrl: './buildings-side-nave.component.html',
  styleUrls: ['./buildings-side-nave.component.css']
})
export class BuildingsSideNaveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
