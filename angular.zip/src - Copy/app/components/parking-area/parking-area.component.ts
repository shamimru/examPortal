import { Component, OnInit } from '@angular/core';
import { ParkingAlloment } from 'src/app/Model/parking-alloment';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-parking-area',
  templateUrl: './parking-area.component.html',
  styleUrls: ['./parking-area.component.css']
})
export class ParkingAreaComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }

  
  parkingAllotment_object:any;

  parkingSubmit(){

  
  }

}
