import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpoyeeMaseterComponent } from './empoyee-maseter.component';

describe('EmpoyeeMaseterComponent', () => {
  let component: EmpoyeeMaseterComponent;
  let fixture: ComponentFixture<EmpoyeeMaseterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpoyeeMaseterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpoyeeMaseterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
