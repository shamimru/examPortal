import { Component, OnInit } from '@angular/core';
import { MembershipInfo } from 'src/app/Model/membership-info';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-mebmers-info',
  templateUrl: './mebmers-info.component.html',
  styleUrls: ['./mebmers-info.component.css']
})
export class MebmersInfoComponent implements OnInit {

  constructor(
    private service :ServiceService
  ) { }

  ngOnInit(): void {
  }


  membership_object:any;
  membership_submit(){
    this.service.saveMember(this.member_info).subscribe((response)=>{
      
    })
    // this.membership_object=new MembershipInfo("",this.member_name,this.members_login_id,this.password, this.confirm_password,this.membership_date,this.birth_date,this.son_of_dauhther_of_husband,this.isBangladeshi,this.isForeigner,this.isPhysically_chanllenged,this.isFreedomFighter,this.isEx_serviceman,this.isSocial_activities, this.register_phone_number, this.alternative_phone_number, this.email, this.identity_proof, this.residential_Type, this.unit_Type, this.flate_house_shop_number, this.monthly_maintenance_rate, this.total_area, this.total_monthly_charge, this.permanent_or_previous_address,this.occupation,this.emergency_contact_details);
  }


 member_info:any={
   "member_id":"",
	 "member_name":"",
	
	 "residential_type":"",
	
	 "password":"",
	
	 "membership_date":"",
	
	 "birth_date":"",
	
	 "son_of_dauhther_of_husband":"",

	 "register_phone_number":"",
	 "alternative_phone_number":"",
	 "email":"",
	

	 "unit_Type":"",
	 "flate_house_shop_number":"",
	
	 "total_area":"",
	 "total_monthly_charge":"",
	 "permanent_or_previous_address":"",
	 "occupation":"",
	 "emergency_contact_details":"",
	 "image":""
 }

 

}
