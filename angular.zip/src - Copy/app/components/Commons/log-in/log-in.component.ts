import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  constructor(
    private service:ServiceService,
    private router:Router
  ) { }

  ngOnInit(): void {
  }

  signIn:any={
    "user_name":"",
    "password":"",
    "role":"",

  }
  signInData:any;
  signIn_to_database(){
    if(this.signIn.user_name=="" || this.signIn.user_name == null && this.signIn.password == "" || this.signIn.password == null){
      return
    }

    this.service.signIn(this.signIn.user_name,this.signIn.password,this.signIn.role).subscribe((response)=>{
      if(response != null){
        this.signInData=response;
        if(this.signInData.password == "admin"){
          alert(this.signInData.password)
          this.router.navigateByUrl("/admin");
          
        }else{
          this.router.navigateByUrl("normal");
          alert(this.signInData.password)
        }
        
      }
    });
    

  }
}
