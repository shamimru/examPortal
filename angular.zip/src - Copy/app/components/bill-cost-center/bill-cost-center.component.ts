import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-cost-center',
  templateUrl: './bill-cost-center.component.html',
  styleUrls: ['./bill-cost-center.component.css']
})
export class BillCostCenterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
