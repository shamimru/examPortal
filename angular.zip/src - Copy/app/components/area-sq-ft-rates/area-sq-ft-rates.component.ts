import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-area-sq-ft-rates',
  templateUrl: './area-sq-ft-rates.component.html',
  styleUrls: ['./area-sq-ft-rates.component.css']
})
export class AreaSqFtRatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
