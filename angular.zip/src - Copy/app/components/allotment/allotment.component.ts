import { Component, OnInit } from '@angular/core';
import { ParkingAlloment } from 'src/app/Model/parking-alloment';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-allotment',
  templateUrl: './allotment.component.html',
  styleUrls: ['./allotment.component.css']
})
export class AllotmentComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }


  allotmentNo: any;
  vehicle_registration_no: any;
  member_code: any;
  memberName: any;
  parking_area: any;
  vehicle_type: any;

  parkingAllotment_object:any;
  allotmentSubmit(){

    this.parkingAllotment_object=new ParkingAlloment("",this.vehicle_registration_no,this.member_code,this.memberName,this.parking_area,this.vehicle_type)
    this.service.saveParingAllotment(this.parkingAllotment_object).subscribe((response)=>{
  
    })
  }

 

}
