import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HomeComponent } from './components/home/home.component';
import { SocietyInformationComponent } from './components/society-information/society-information.component';
import { AccountMasterComponent } from './components/account-master/account-master.component';
import { CostCenterComponent } from './components/cost-center/cost-center.component';
import { AssetsMasterComponent } from './components/assets-master/assets-master.component';
import { AreaSqFtRatesComponent } from './components/area-sq-ft-rates/area-sq-ft-rates.component';
import { DepartmentComponent } from './components/department/department.component';
import { EmpoyeeMaseterComponent } from './components/empoyee-maseter/empoyee-maseter.component';
import { MebmersInfoComponent } from './components/mebmers-info/mebmers-info.component';
import { HomeStaffComponent } from './components/MemberOfStaffInfo/home-staff/home-staff.component';
import { MemberListComponent } from './components/member-list/member-list.component';
import { NoticeBoardComponent } from './components/notice-board/notice-board.component';
import { AllotmentComponent } from './components/allotment/allotment.component';
import { VehicleDetailsComponent } from './components/vehicle-details/vehicle-details.component';
import { PersonalComponent } from './components/gallery/personal/personal.component';
import { MonthlyFeeComponent } from './components/monthly-fee/monthly-fee.component';
import { AccountVoucherComponent } from './components/account-voucher/account-voucher.component';
import { PendingFeeComponent } from './components/pending-fee/pending-fee.component';
import { BillCostCenterComponent } from './components/bill-cost-center/bill-cost-center.component';
import { BillAccountLedgerComponent } from './components/bill-account-ledger/bill-account-ledger.component';
import { ServiceComplainsComponent } from './components/service-complains/service-complains.component';
import { SendInvitationComponent } from './components/send-invitation/send-invitation.component';
import { AnnouncementComponent } from './components/announcement/announcement.component';
import { ShowAllSocietyComponent } from './components/show-all-society/show-all-society.component';
import { BuildingComponent } from './components/building/building.component';
import { ShowBuildingInfoComponent } from './components/building/show-building-info/show-building-info.component';
import { BuildingDetailsComponent } from './components/building/building-details/building-details.component';
import { ShowMemberDetailsComponent } from './components/show-member-details/show-member-details.component';
import { BuildingStaffComponent } from './components/building/building-staff/building-staff.component';
import { AddMemberComponent } from './components/building/add-member/add-member.component';
import { ViewMemberDetailsComponent } from './components/view-member-details/view-member-details.component';
import { StaffInfoComponent } from './components/MemberOfStaffInfo/staff-info/staff-info.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { LogInComponent } from './components/Commons/log-in/log-in.component';
import { SignUpComponent } from './components/Commons/sign-up/sign-up.component';
import { HomepageComponent } from './components/Commons/homepage/homepage.component';

const routes: Routes = [
  {
    path: "", component: HomepageComponent, pathMatch: "full"
  },
  {
    path: "signin", component: LogInComponent
  },
  {
    path: "signUp", component: SignUpComponent
  },
  {path: "admin", component: DashboardComponent,
    children: [
      {
        path: "", component: HomeComponent
      },
      {
        path: "societyInfo", component: SocietyInformationComponent
      },
      {
        path: "accMaster", component: AccountMasterComponent
      },
      {
        path: "costCenter", component: CostCenterComponent
      },
      {
        path: "assetsMaster", component: AssetsMasterComponent
      },
      {
        path: "area", component: AreaSqFtRatesComponent
      },
      {
        path: "department", component: DepartmentComponent
      },
      {
        path: "employee", component: EmpoyeeMaseterComponent
      },
      {
        path: "membersInfo", component: MebmersInfoComponent
      },
      {
        path: "homeStaff", component: HomeStaffComponent
      },
      {
        path: "memberList", component: MemberListComponent
      },
      {
        path: "noticeBoard", component: NoticeBoardComponent
      },
      {
        path: "allotment", component: AllotmentComponent
      },
      {
        path: "vehicle", component: VehicleDetailsComponent
      },
      {
        path: "personal", component: PersonalComponent
      },
      {
        path: "monthlyFee", component: MonthlyFeeComponent
      },
      {
        path: "accVoucher", component: AccountVoucherComponent
      },
      {
        path: "pendingList", component: PendingFeeComponent
      },
      {
        path: "constCenterLedger", component: BillCostCenterComponent
      },
      {
        path: "accountLedger", component: BillAccountLedgerComponent
      },
      {
        path: "complains", component: ComplaintsComponent
      },
      {
        path: "sendInvitation", component: SendInvitationComponent
      },
      {
        path: "announcement", component: AnnouncementComponent
      },
      {
        path: "showAllSociety", component: ShowAllSocietyComponent
      },
      {
        path: "buildingInfo", component: BuildingComponent
      },
      {
        path: "showBuildingInfo", component: ShowBuildingInfoComponent
      },
      {
        path: "showMemberInfo", component: ShowMemberDetailsComponent
      },
      {
        path: "ViewMemberDetails/:member_id", component: ViewMemberDetailsComponent
      },
      {
        path: "StaffInfo", component: StaffInfoComponent
      },


    ]
  },

  {
    path: "buildingDetails/:building_id", component: BuildingDetailsComponent,
    children: [

      {
        path: "memberDetails", component: ShowMemberDetailsComponent
      },
      {
        path: "buildingStaff", component: BuildingStaffComponent
      },
      {
        path: "addMember", component: AddMemberComponent,

      },


    ]
  },




];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
