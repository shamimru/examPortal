export class HomestaffInfo {

     membershipCode:any;
	 memberName:any;
	 flat_of_house_name:any;
	 employee_code_of_name:any;
	 employee_code:any;
	 police_varification_code:any;
	 employee_name:any;
	 father_husband_name:any;
	 spouse_name:any;
	 date_of_joining:any;
	 date_of_birth:any;
	 employee_type:any;
	 contact_number:any;
	 driving_Licence:any;
	 password_number:any;
	 reference_name:any;
	 reference_phone:any;
	 reference_address:any;
	
	 employee_pressent_address:any;
	 employee_old_address:any;

    image:any

     constructor(membershipCode:any, memberName:any, flat_of_house_name:any,employee_code_of_name:any, employee_code:any,police_varification_code:any, employee_name:any,father_husband_name:any,spouse_name:any, date_of_joining:any, date_of_birth:any, employee_type:any, contact_number:any, driving_Licence:any, password_number:any, reference_name:any, reference_phone:any, reference_address:any,employee_pressent_address:any, employee_old_address:any , image:any){
        this.membershipCode=membershipCode;
        this.memberName=memberName;
        this.flat_of_house_name=flat_of_house_name;
        this.employee_code_of_name=employee_code_of_name;
        this.employee_code=employee_code;
        this.police_varification_code=police_varification_code;
        this.employee_name=employee_name;
        this.father_husband_name=father_husband_name;
        this.spouse_name=spouse_name;
        this.date_of_joining=date_of_joining;
        this.date_of_birth=date_of_birth;
        this.employee_type=employee_type;
        this.contact_number=contact_number;
        this.driving_Licence=driving_Licence;
        this.password_number=password_number;
        this.reference_name=reference_name;
        this.reference_phone=reference_phone;
        this.reference_address=reference_address;
        this.employee_pressent_address=employee_pressent_address;
        this.employee_old_address=employee_old_address
        this.image=image
     }
}
