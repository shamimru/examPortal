import { Complains } from './complains';

describe('Complains', () => {
  it('should create an instance', () => {
    expect(new Complains()).toBeTruthy();
  });
});
