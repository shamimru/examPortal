export class CostCenterMaster {

     cost_id:any;
	 cost_code:any;
	 name:any;
	 descriptin:any;
	 remark:any;

     constructor(cost_id:any, cost_code:any, name:any, description:any, remark:any){

        this.cost_id=cost_id;
        this.cost_code=cost_code;
        this.name=name;
        this.descriptin=description;
        this.remark=remark;
     }
}
