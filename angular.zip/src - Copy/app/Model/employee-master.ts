export class EmployeeMaster {

    
	 emp_code:any;
	 emp_name:any;
	 gardian:any;
	 spuse:any;

	 joiningDate:any;

	 dateOfBirth:any;
	 jobType:any;
	 department:any;

	 designation:any;
	 contactNumber:any;
	 email:any;
	 referenceName:any;
	 referenceNumber:any;

     constructor( emp_code:any,emp_name:any, gardian:any,spuse:any, joiningDate:any,dateOfBirth:any, jobType:any, department:any,designation:any,contactNumber:any, email:any,referenceName:any,referenceNumber:any){

        this. emp_code= emp_code;
        this.emp_name=emp_name;
        this.gardian=gardian;
        this.spuse=spuse;
        this.joiningDate=joiningDate;
        this.dateOfBirth=dateOfBirth;
        this.jobType=jobType;
        this.department=department;
        this.designation=designation;
        this.contactNumber=contactNumber;
        this.email=email;
        this.referenceName=referenceName;
        this.referenceNumber=referenceNumber
     }
}
