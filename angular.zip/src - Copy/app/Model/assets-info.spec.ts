import { AssetsInfo } from './assets-info';

describe('AssetsInfo', () => {
  it('should create an instance', () => {
    expect(new AssetsInfo()).toBeTruthy();
  });
});
