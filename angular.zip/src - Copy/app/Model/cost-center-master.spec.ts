import { CostCenterMaster } from './cost-center-master';

describe('CostCenterMaster', () => {
  it('should create an instance', () => {
    expect(new CostCenterMaster()).toBeTruthy();
  });
});
