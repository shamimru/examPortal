import { EmployeeMaster } from './employee-master';

describe('EmployeeMaster', () => {
  it('should create an instance', () => {
    expect(new EmployeeMaster()).toBeTruthy();
  });
});
