import { MembershipInfo } from './membership-info';

describe('MembershipInfo', () => {
  it('should create an instance', () => {
    expect(new MembershipInfo()).toBeTruthy();
  });
});
