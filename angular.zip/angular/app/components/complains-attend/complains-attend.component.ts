import { Component, OnInit } from '@angular/core';
import { Complains } from 'src/app/Model/complains';

@Component({
  selector: 'app-complains-attend',
  templateUrl: './complains-attend.component.html',
  styleUrls: ['./complains-attend.component.css']
})
export class ComplainsAttendComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }




 
}
