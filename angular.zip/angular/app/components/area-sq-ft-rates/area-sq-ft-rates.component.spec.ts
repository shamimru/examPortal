import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AreaSqFtRatesComponent } from './area-sq-ft-rates.component';

describe('AreaSqFtRatesComponent', () => {
  let component: AreaSqFtRatesComponent;
  let fixture: ComponentFixture<AreaSqFtRatesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AreaSqFtRatesComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AreaSqFtRatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
