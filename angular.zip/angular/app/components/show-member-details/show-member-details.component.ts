import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-show-member-details',
  templateUrl: './show-member-details.component.html',
  styleUrls: ['./show-member-details.component.css']
})
export class ShowMemberDetailsComponent implements OnInit {

  allMemberInfo:any
  constructor(
    private service:ServiceService
  ) {
    this.service.getAllMemberIngo().subscribe((response)=>{
      this.allMemberInfo=response
    })
   }

  ngOnInit(): void {
  }

}
