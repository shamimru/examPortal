import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingsSideNaveComponent } from './buildings-side-nave.component';

describe('BuildingsSideNaveComponent', () => {
  let component: BuildingsSideNaveComponent;
  let fixture: ComponentFixture<BuildingsSideNaveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuildingsSideNaveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuildingsSideNaveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
