import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuildingWelcomeComponent } from './building-welcome.component';

describe('BuildingWelcomeComponent', () => {
  let component: BuildingWelcomeComponent;
  let fixture: ComponentFixture<BuildingWelcomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuildingWelcomeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuildingWelcomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
