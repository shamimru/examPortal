import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-building-welcome',
  templateUrl: './building-welcome.component.html',
  styleUrls: ['./building-welcome.component.css']
})
export class BuildingWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
