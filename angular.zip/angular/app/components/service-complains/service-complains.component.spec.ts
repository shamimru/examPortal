import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServiceComplainsComponent } from './service-complains.component';

describe('ServiceComplainsComponent', () => {
  let component: ServiceComplainsComponent;
  let fixture: ComponentFixture<ServiceComplainsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServiceComplainsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServiceComplainsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
