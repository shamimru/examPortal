import { Component, OnInit } from '@angular/core';
import { Complains } from 'src/app/Model/complains';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-service-complains',
  templateUrl: './service-complains.component.html',
  styleUrls: ['./service-complains.component.css']
})
export class ServiceComplainsComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }

  TicketNo:any;
	
  complain_date:any;
  member_code:any;
  member_name:any;
  complains_type:any;
  brifly_describe:any;
  elaborate_problem:any;

  complains_object:any;

  complains_submit(){
  
  }

}
