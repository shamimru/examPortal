import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatCardModule} from '@angular/material/card';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import {MatListModule} from '@angular/material/list';
import { HomeComponent } from './components/home/home.component';
import {MatButtonModule} from '@angular/material/button';
import { SocietyInformationComponent } from './components/society-information/society-information.component';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { AccountMasterComponent } from './components/account-master/account-master.component';
import { CostCenterComponent } from './components/cost-center/cost-center.component';
import { AssetsMasterComponent } from './components/assets-master/assets-master.component';
import { AreaSqFtRatesComponent } from './components/area-sq-ft-rates/area-sq-ft-rates.component';
import { DepartmentComponent } from './components/department/department.component';
import { EmpoyeeMaseterComponent } from './components/empoyee-maseter/empoyee-maseter.component';
import { HelplineComponent } from './components/helpline/helpline.component';
import { ParkingAreaComponent } from './components/parking-area/parking-area.component';
import { MebmersInfoComponent } from './components/mebmers-info/mebmers-info.component';
import { HomeStaffComponent } from './components/MemberOfStaffInfo/home-staff/home-staff.component';
import { MemberListComponent } from './components/member-list/member-list.component';
import { NoticeBoardComponent } from './components/notice-board/notice-board.component';
import { AllotmentComponent } from './components/allotment/allotment.component';
import { VehicleDetailsComponent } from './components/vehicle-details/vehicle-details.component';
import { PersonalComponent } from './components/gallery/personal/personal.component';
import { MonthlyFeeComponent } from './components/monthly-fee/monthly-fee.component';
import { AccountVoucherComponent } from './components/account-voucher/account-voucher.component';
import { PendingFeeComponent } from './components/pending-fee/pending-fee.component';
import { BillCostCenterComponent } from './components/bill-cost-center/bill-cost-center.component';
import { BillAccountLedgerComponent } from './components/bill-account-ledger/bill-account-ledger.component';
import { ServiceComplainsComponent } from './components/service-complains/service-complains.component';
import { ComplainsAttendComponent } from './components/complains-attend/complains-attend.component';
import { SendInvitationComponent } from './components/send-invitation/send-invitation.component';
import { AnnouncementComponent } from './components/announcement/announcement.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from  '@angular/common/http';
import { ServiceService } from './MyService/service.service';
import { BuildingComponent } from './components/building/building.component';
import { ShowAllSocietyComponent } from './components/show-all-society/show-all-society.component';
import { BuildingInfoComponent } from './components/building/building-info/building-info.component';
import { ShowBuildingInfoComponent } from './components/building/show-building-info/show-building-info.component';
import { BuildingDetailsComponent } from './components/building/building-details/building-details.component';
import { BuildingsSideNaveComponent } from './components/building/buildings-side-nave/buildings-side-nave.component';
import { ShowMemberDetailsComponent } from './components/show-member-details/show-member-details.component';
import { BuildingWelcomeComponent } from './components/building/building-welcome/building-welcome.component';
import { BuildingStaffComponent } from './components/building/building-staff/building-staff.component';
import { AddMemberComponent } from './components/building/add-member/add-member.component';
import { ViewMemberDetailsComponent } from './components/view-member-details/view-member-details.component';
import { StaffInfoComponent } from './components/MemberOfStaffInfo/staff-info/staff-info.component';
import { ComplaintsComponent } from './components/complaints/complaints.component';
import { SignUpComponent } from './components/Commons/sign-up/sign-up.component';
import { LogInComponent } from './components/Commons/log-in/log-in.component';
import { HomepageComponent } from './components/Commons/homepage/homepage.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    SidebarComponent,
    HomeComponent,
    SocietyInformationComponent,
    AccountMasterComponent,
    CostCenterComponent,
    AssetsMasterComponent,
    AreaSqFtRatesComponent,
    DepartmentComponent,
    EmpoyeeMaseterComponent,
    HelplineComponent,
    
    ParkingAreaComponent,
    MebmersInfoComponent,
    HomeStaffComponent,
    MemberListComponent,
    NoticeBoardComponent,
    AllotmentComponent,
    VehicleDetailsComponent,
    PersonalComponent,
    MonthlyFeeComponent,
    AccountVoucherComponent,
    PendingFeeComponent,
    BillCostCenterComponent,
    BillAccountLedgerComponent,
    ServiceComplainsComponent,
    ComplainsAttendComponent,
    SendInvitationComponent,
    AnnouncementComponent,
    BuildingComponent,
    ShowAllSocietyComponent,
    BuildingInfoComponent,
    ShowBuildingInfoComponent,
    BuildingDetailsComponent,
    BuildingsSideNaveComponent,
    ShowMemberDetailsComponent,
    BuildingWelcomeComponent,
    BuildingStaffComponent,
    AddMemberComponent,
    ViewMemberDetailsComponent,
    StaffInfoComponent,
    ComplaintsComponent,
    SignUpComponent,
  LogInComponent,
  HomepageComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    HttpClientModule
    

  ],
  providers: [ServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
