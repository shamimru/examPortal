export class AssetsInfo {
     assets_id:any;
	 code:any;
	 assets_Name:any;
	 mobile_Number:any;
	 assets_description:any;
	 use_Of_assets:any;
	 location_of_use:any;
	 unit_price:any;
	 quantity:any;
	 total_price:any;
	 serviceCenter_name:any;
	 acquisition_Date:any; 
    
     assets_commense_date:any;
    
     return_date:any;

     constructor(assets_id:any, code:any, assets_name:any, mobile_number:any, assets_description:any, use_of_assets:any, location:any, unit_price:any, quantity:any, totalPrice:any, servicecenter:any, acquisition_date:any, assetsCommenseDate:any, returnDate :any){

        this.assets_id=assets_id;
        this.code=code;
        this.assets_Name=assets_name;
        this.mobile_Number=mobile_number;
        this.assets_description=assets_description;
        this.use_Of_assets=use_of_assets;
        this.location_of_use=location;
        this.unit_price=unit_price;
        this.quantity=quantity;
        this.total_price=totalPrice;
        this.serviceCenter_name=servicecenter;
        this.acquisition_Date=acquisition_date;
        this.assets_commense_date=assetsCommenseDate;
        this.return_date=returnDate



     }
}
