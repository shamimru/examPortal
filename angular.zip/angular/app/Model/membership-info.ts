export class MembershipInfo {
     member_id:any;
	 member_name:any;
	 members_login_id:any;
	 password:any;
	 confirm_password:any;
	
	 membership_date:any;
	 birth_date:any;
	
	 son_of_dauhther_of_husband:any;
	
	 isBangladeshi:any;
	 isForeigner:any;
	 isPhysically_chanllenged:any;
	 isFreedomFighter:any;
	 isEx_serviceman:any;
	 isSocial_activities:any;
    //  constructor( member_id:any,member_name:any, members_login_id:any, password:any, confirm_password:any, membership_date:any, birth_date:any,son_of_dauhther_of_husband:any,isBangladeshi:any, isForeigner:any,isPhysically_chanllenged:any, isFreedomFighter:any, isEx_serviceman:any,isSocial_activities:any, register_phone_number:any, alternative_phone_number:any, email:any,identity_proof:any, residential_Type:any, unit_Type:any,flate_house_shop_number:any, monthly_maintenance_rate:any, total_area:any,total_monthly_charge:any, permanent_or_previous_address:any,occupation:any,emergency_contact_details:any)
	 register_phone_number:any;
	 alternative_phone_number:any;
	 email:any;
	 identity_proof:any;
	 residential_Type:any;
	 unit_Type:any;
	 flate_house_shop_number:any;
	 monthly_maintenance_rate:any;
	 total_area:any;
	 total_monthly_charge:any;
	 permanent_or_previous_address:any;
	 occupation:any;
	 emergency_contact_details:any;

     constructor( member_id:any,member_name:any, members_login_id:any, password:any, confirm_password:any, membership_date:any, birth_date:any,son_of_dauhther_of_husband:any,isBangladeshi:any, isForeigner:any,isPhysically_chanllenged:any, isFreedomFighter:any, isEx_serviceman:any,isSocial_activities:any, register_phone_number:any, alternative_phone_number:any, email:any,identity_proof:any, residential_Type:any, unit_Type:any,flate_house_shop_number:any, monthly_maintenance_rate:any, total_area:any,total_monthly_charge:any, permanent_or_previous_address:any,occupation:any,emergency_contact_details:any){
        this.member_id=member_id
        this.member_name=member_name;
        this.members_login_id=members_login_id;
        this.password=password;
        this.confirm_password=confirm_password;
        this.membership_date=membership_date;
        this.birth_date=birth_date;
        this.son_of_dauhther_of_husband=son_of_dauhther_of_husband;
        this.isBangladeshi=isBangladeshi;
        this.isForeigner=isForeigner;
        this.isPhysically_chanllenged=isPhysically_chanllenged;
        this.isFreedomFighter=isFreedomFighter;
        this.isEx_serviceman=isEx_serviceman;
        this.isSocial_activities=isSocial_activities;
        this.register_phone_number=register_phone_number;
        this.alternative_phone_number=alternative_phone_number;
        this.email=email;
        this.identity_proof=identity_proof;
        this.residential_Type=residential_Type;
        this.unit_Type=unit_Type;
        this.flate_house_shop_number=flate_house_shop_number;
        this.monthly_maintenance_rate=monthly_maintenance_rate;
        this.total_area=total_area;
        this.total_monthly_charge=total_monthly_charge;
        this.permanent_or_previous_address=permanent_or_previous_address;
        this.occupation=occupation;
        this.emergency_contact_details=emergency_contact_details;
     }
}
