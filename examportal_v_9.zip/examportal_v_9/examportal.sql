SELECT * FROM examportal.quiz;
desc quiz;
use examportal;
	
create table question(questionId int  auto_increment, quiz_id int, content varchar(40),
image varchar(100),option_1 varchar(40),option_2 varchar(40), option_3 varchar(40),
option_4 varchar(40), answer varchar(50), 
primary key (questionId)
);

drop table question;
select * from question;
select * from quiz;

desc quiz;

drop table quiz;
desc question;

create table quiz( quiz_id int  auto_increment, title varchar(30) not null,description varchar(100), 
max_marks int(40), no_of_question int(50), is_publish boolean, category_id_fk int, 
primary key (quiz_id)
);

alter table quiz add foreign key (category_id_fk) references categories(category_id);

select * from categories;
desc categories;
drop table categories;
select * from registration;

create table categories (category_id int primary key auto_increment, title varchar(50) unique not null,
description varchar(100) not null);

alter table categories rename column categority_id to category_id;
