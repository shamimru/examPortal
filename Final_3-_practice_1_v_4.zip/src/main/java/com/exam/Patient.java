package com.exam;

public class Patient {

	
	int id;
	String name;
	String gender;
	String problem;
	String phone;
	
	public Patient() {
		// TODO Auto-generated constructor stub
	}

	

	public Patient(int id, String name, String gender, String problem, String phone) {
		super();
		this.id = id;
		this.name = name;
		this.gender = gender;
		this.problem = problem;
		this.phone = phone;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getGender() {
		return gender;
	}



	public void setGender(String gender) {
		this.gender = gender;
	}



	public String getProblem() {
		return problem;
	}



	public void setProblem(String problem) {
		this.problem = problem;
	}



	public String getPhone() {
		return phone;
	}



	public void setPhone(String phone) {
		this.phone = phone;
	}

	
	
	
}
