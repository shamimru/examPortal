package com.exam;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;



@RestController
@CrossOrigin("*")
public class Controller {
	
	
	@PostMapping("/save")
	public void saveRegistration(@RequestBody RegistrationModel r) {
		
		DAO dao=new DAO();
		dao.saveRegistration(r);
		
	}
	
	@GetMapping("/login/{id}/{password}")
	public RegistrationModel login(@PathVariable int id,@PathVariable String password) {
		
		DAO dao= new DAO();
		RegistrationModel data = dao.login(id, password);
		
		return data;
	}
	
	@GetMapping("/search/{id}")
	public Patient search(@PathVariable int id) {
		
		DAO dao= new DAO();
		Patient data = dao.searchById(id);
		
		return data;
	}

}
