import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Registration } from 'src/app/Models/registration';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private userService:UserService, private snack:MatSnackBar) { }

  ngOnInit(): void {
  }

  // public User={
  //   username:'',
  //   password:'',
  //   firstname:'',
  //   lastname:'',
  //   email:'',
  //   phone:'',
  // }

  id:any;
  username:any;
  password:any;
  firstname:any;
  lastname:any;
  email:any;
  phone:any;


  registration:any;

  formSubmit(){

    this.registration=new Registration(this.id,this.username,this.password,this.firstname,this.lastname,this.email,this.phone);
    // alert("submit")
    if(this.registration.username =='' || this.registration.username ==null){
        this.username="UserName is Required ! "
        this.snack.open("User Name is Requred",'',{
          duration:3000,
          verticalPosition:'top',
          horizontalPosition:'center'
        })

        return;
    }

    //adduser: userServices
    this.userService.register(this.registration).subscribe((data)=>{
      //success
      this.snack.open("Success",'',
        {
          duration:3000,
          verticalPosition:'top',
          horizontalPosition:'center'
        }
      )
      alert("success")
    },
    (error)=>{
      // alert("error")
      this.snack.open("Something Went Wrong",'',
        {
          duration:3000,
          verticalPosition:'top',
          horizontalPosition:'center'
        }
      )
    }
  );
  }




}
