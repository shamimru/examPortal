import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignupComponent } from './pages/signup/signup.component';
import { HomeComponent } from './pages/home/home.component';
import { SigninComponent } from './pages/signin/signin.component';
import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { WelcomeComponent } from './pages/welcome/welcome.component';

const routes: Routes = [
  {path:"", component:HomeComponent,pathMatch:"full"},
  {path:"signup", component:SignupComponent,pathMatch:"full"},
  {path:"login", component:SigninComponent,pathMatch:"full"},
  {path:"admin", component:DashboardComponent,pathMatch:"full"},
  {
     path:"admin",
     component:DashboardComponent,
     children:[
      {path:'profile',
      component:ProfileComponent},
      {
        path:"",
        component:WelcomeComponent
      }
     ]
    
    
    },
    



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
