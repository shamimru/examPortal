import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baseUrl from './helper';
import { Registration } from '../Models/registration';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http:HttpClient) { }
  // add user

  public addUser(user:any){
    return this.http.post(`${baseUrl}/user/`,user);
  }

  url:any;
  register(r:Registration):Observable<Registration>{
    this.url="http://localhost:8080/save"
    return this.http.post<Registration>(this.url,r);
  }

  logIn(id:any , password:any):Observable<Registration>{
    this.url="http://localhost:8080/login/";
    return this.http.get<Registration>(this.url+id+"/"+password);
  }
}
