import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { DashboardComponent } from './components/Admin/dashboard/dashboard.component';

import { ViewCategoriesComponent } from './components/Admin/view-categories/view-categories.component';

import { ProfileComponent } from './components/Admin/profile/profile.component';
import { ShowdatabyidComponent } from './components/Admin/showdatabyid/showdatabyid.component';
import { AddCategoryComponent } from './components/Admin/add-category/add-category.component';
import { HomeComponent } from './components/pages/home/home.component';
import { SignupComponent } from './components/pages/signup/signup.component';
import { SigninComponent } from './components/pages/signin/signin.component';
import { SuccessComponent } from './components/pages/success/success.component';
import { WelcomeComponent } from './components/pages/welcome/welcome.component';
import { ViewQuizzesComponent } from './components/Admin/view-quizzes/view-quizzes.component';
import { AddQuizComponent } from './components/Admin/add-quiz/add-quiz.component';
import { ShowAllDataComponent } from './components/Admin/show-all-data/show-all-data.component';
import { EditRegisterDataComponent } from './components/Admin/edit-register-data/edit-register-data.component';
import { FailPageComponent } from './components/pages/fail-page/fail-page.component';
import { ViewQuizQuestionsComponent } from './components/Admin/view-quiz-questions/view-quiz-questions.component';
import { UpdateQuizzComponent } from './components/Admin/update-quizz/update-quizz.component';
import { AddQuestionComponent } from './components/Admin/add-question/add-question.component';
import { EditQuestionComponent } from './components/Admin/edit-question/edit-question.component';
import { UserDashboardComponent } from './components/user/user-dashboard/user-dashboard.component';
import { LoadQuizComponent } from './components/user/load-quiz/load-quiz.component';


const routes: Routes = [
  {path:"", component:UserDashboardComponent,pathMatch:"full"},
  {path:"signup", component:SignupComponent,pathMatch:"full"},
  {path:"login", component:SigninComponent,pathMatch:"full"},
  {path:"admin", component:DashboardComponent,pathMatch:"full"},
  
  {
     path:"admin",
     component:DashboardComponent,
     children:[
      {
        path:"",
        component:WelcomeComponent
      },
      {path:'profile',
      component:ProfileComponent
      },
      {
        path:'showDataById',
        component:ShowdatabyidComponent
      },
      {
        path:"categories",
        component:ViewCategoriesComponent
      },

      {
        path:"add-category",
        component:AddCategoryComponent
      },
      {
        path:"quizzes",
        component:ViewQuizzesComponent
      },

      {
        path:"addquiz",
        component:AddQuizComponent
      },
      {
        path:"showAllData",
        component:ShowAllDataComponent
      },
      {
        path:"editRegistryData",
         component:EditRegisterDataComponent
      },
      
      {
        path:"updateQuizz/:quiz_id",
         component:UpdateQuizzComponent
      },
      {
        path:"view_question/:quiz_id/:quiz_title",
         component:ViewQuizQuestionsComponent
      },
      {
        path:"add_question/:quiz_id/:quiz_title",
         component:AddQuestionComponent
      },
      {
        path:"edit_question/:question_id/:quiz_title",
         component:EditQuestionComponent
      },

      



      {
        path:"**",
        component:FailPageComponent
      },
      

      

      // {
      //   path:'dashboard',component:DashboardComponent
      // }

      // admin children end
     ]

    //  admin end
    },

    // user start 

    {
      path:"user-dashboard",
      component:UserDashboardComponent,
      children:[
        {
          path:":category_id",
          component:LoadQuizComponent
        }
      ]
    },
    // user end 

    {
      path:"**", component:FailPageComponent
    },
    



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
