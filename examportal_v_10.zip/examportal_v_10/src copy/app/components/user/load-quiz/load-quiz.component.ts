import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-load-quiz',
  templateUrl: './load-quiz.component.html',
  styleUrls: ['./load-quiz.component.css']
})
export class LoadQuizComponent implements OnInit {

  constructor(
    private _route: ActivatedRoute,
    private _userService: UserService

  ) { }

  category_id: any;
  allQuizzes: any

  ngOnInit(): void {

    this._route.params.subscribe((params)=>{
      this.category_id = params["category_id"];

      if (this.category_id == 0) {

        // getting all  quizzes 
        this._userService.getAllQuizzes().subscribe(
          (data: any) => {
            this.allQuizzes = data;
          },
          (error)=>{
            alert("erro all data")
          }
  
        )
      } else {
       this._userService.getActiveQuizzBy_id(this.category_id).subscribe(
        (data:any)=>{
          this.allQuizzes=data;
        },
        (error)=>{
          alert("error")
        }
       )
        this.allQuizzes=[]
      }
    })
   
  }
}

  


