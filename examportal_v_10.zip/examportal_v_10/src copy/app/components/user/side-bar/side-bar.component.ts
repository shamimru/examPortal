import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CategorySeviceService } from 'src/app/services/category-sevice.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'side-bar-user',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css']
})
export class SideBarComponent implements OnInit {

  constructor(
    private _categoryService:CategorySeviceService,
    private _route:ActivatedRoute

  ) { }

  category:any
  category_id:any
  
  ngOnInit(): void {

    


    this._categoryService.getAllCategory().subscribe(
      (data)=>{
        this.category=data
      },
      (error)=>{
        Swal.fire("error","no data found","error")
      }
    )


    if(this.category_id == 0){

      console.log(this.category_id);
      
    }else{
      console.log(this.category_id);
    }


    // end of init 
  }

 
}
