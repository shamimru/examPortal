import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { Questions } from 'src/app/Models/questions';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.css']
})
export class AddQuestionComponent implements OnInit {

  constructor(
    private _userService: UserService,
    private _route: ActivatedRoute
  ) { }

  public Editor = ClassicEditor;
  quiz_id: any
  quiz_title: any
  ngOnInit(): void {
    this.quiz_id = this._route.snapshot.params["quiz_id"];
    this.quiz_title = this._route.snapshot.params["quiz_title"];
  }

  qustion_content: any;
  option_1: any;
  option_2: any
  option_3: any
  option_4: any
  image: any;
  answer: any;


  question_object: any;

  formSubmit() {
    if (this.qustion_content.trim() == '' || this.qustion_content == null) {
      return
    }
    if (this.option_1.trim() == '' || this.option_1 == null) {
      return
    }
    if (this.option_2.trim() == '' || this.option_2 == null) {
      return
    }
    this.question_object = new Questions("", this.quiz_id, this.qustion_content, "", this.option_1, this.option_2, this.option_3, this.option_4, this.answer)

    this._userService.saveQuestions(this.question_object).subscribe((data) => {

      Swal.fire("Success !!", 'Quiz Updated', "success");
    },
      (error) => {
        Swal.fire("Error !!", "error in Updating Quizz", 'error')
      }
      // Swal.fire({
      //   position: "center",
      //   icon: "success",
      //   title: "Your work has been saved",
      //   showConfirmButton: false,
      //   timer: 1500
      // })

    )
  }
}


