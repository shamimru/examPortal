import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-quiz-questions',
  templateUrl: './view-quiz-questions.component.html',
  styleUrls: ['./view-quiz-questions.component.css']
})
export class ViewQuizQuestionsComponent implements OnInit {

  constructor(
    private route:ActivatedRoute,
    private _userService:UserService


  ) { }

  questions:any;

  quiz_id:any;
  quiz_title:any

  ngOnInit(): void {
    this.quiz_id =this.route.snapshot.params["quiz_id"]
    this.quiz_title = this.route.snapshot.params["quiz_title"]
    this._userService.getQuestionOfQuizz(this.quiz_id).subscribe((questionOfQuizId:any)=>{
      this.questions=questionOfQuizId;
    },
  (error)=>{
    alert("no data")
  }
  
  )
  }
  deleteQuestionById(questionId:any){

    Swal.fire({
      title: "Are you Want to Delete Question",
      text: "your will not be able to recover Question",
      icon: "warning",
      showCancelButton: true,
      confirmButtonText: "Yes Delete the Question",
      cancelButtonText: "No Keep it"
    }).then((result) => {
      if (result.value) {
        this._userService.deleteQuestionById(questionId).subscribe((deleteQuizById: any) => {
        })

        Swal.fire("Deleted", "Your Question has been deleted", "success");


        // re-freshing all quiz 
        this._userService.getQuestionOfQuizz(this.quiz_id).subscribe((questionOfQuizId:any)=>{
          this.questions=questionOfQuizId;
        },
      (error)=>{
        alert("no data")
      } )

      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire("Cancelled", "Your Question is Safe Now :) ", "error")
      }
    })



    // delete function end 
  }
   

  // update question by id 
  updateQuestionById(updatequestionById:any){

  }
   // end of class 
  }


 

