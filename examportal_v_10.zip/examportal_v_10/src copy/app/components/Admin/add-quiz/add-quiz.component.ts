import { Component, OnInit, Query } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { Quizz } from 'src/app/Models/quizz';
import { CategorySeviceService } from 'src/app/services/category-sevice.service';
import { QuizzService } from 'src/app/services/quizz.service';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-quiz',
  templateUrl: './add-quiz.component.html',
  styleUrls: ['./add-quiz.component.css']
})
export class AddQuizComponent implements OnInit {
color: any;
checked: any;
disabled: any;

  constructor(
    private _category:CategorySeviceService,
    private _snack:MatSnackBar,
    private _router:Router,
    private _userService:UserService

  ) { }

  allQuizData:any;

  ngOnInit(): void {
    this._category.getAllCategory().subscribe((data)=>{
      if(data !=null){
        this.allQuizData=data;
        // Swal.fire("Success","Successfully Loaded Data");
        // this._snack.open("Success", '', {
        //   duration: 3000
        // });
      }
    }
    // },
    //   (erro)=>{
    //     Swal.fire("Error !","Error in Loading data from server")
    //   }
  
  )

  }

  quiz_id:any
  title:any
  description:any
  max_marks:any;
  no_of_question:any;
  published:any;
  category:any;

  saveQuizz_Object:any
 
  addQuizz(){
    alert("add quiz")
    this.saveQuizz_Object=new Quizz(this.quiz_id,this.title,this.description,this.max_marks,this.no_of_question,this.published,this.category);
    return this._userService.saveQuizz(this.saveQuizz_Object).subscribe(()=>{

    })
   
  }


      
    
  }
  // Quizz:any={
  //    quiz_id:"",
  //    title:"",
  //    description:"",
  //    max_marks:"",
  //    no_of_question:"",
  //    publish:true,
  //   "category":""
  // }

