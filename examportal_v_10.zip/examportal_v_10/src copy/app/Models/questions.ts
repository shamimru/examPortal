export class Questions {

  questionId: any
  quiz_id: any
  content: any
  image: any
  option_1: any
  option_2: any
  option_3: any
  option_4: any

  answer: any
  constructor(qId: any, quiz_id: any, content: any, image: any, opt_1: any, opt_2: any, opt_3: any, opt_4: any, answer: any) {
    this.questionId = qId;
    this.quiz_id = quiz_id;
    this.content = content;
    this.image = image;
    this.option_1 = opt_1;
    this.option_2 = opt_2;
    this.option_3 = opt_3;
    this.option_4 = opt_4;

    this.answer = answer;

  }

}
