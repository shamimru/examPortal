package com.exam.models;

public class Category {

}
