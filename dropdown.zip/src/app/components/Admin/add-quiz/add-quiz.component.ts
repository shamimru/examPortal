import { Component, OnInit } from '@angular/core';
import { Quizz } from 'src/app/Models/quizz';
import { QuizzServiceService } from 'src/app/services/quizz-service.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-quiz',
  templateUrl: './add-quiz.component.html',
  styleUrls: ['./add-quiz.component.css']
})
export class AddQuizComponent implements OnInit {
color: any;
checked: any;
disabled: any;

  constructor(private _quizzService:QuizzServiceService) { }

  ngOnInit(): void {
  }

  quiz_id:any
  title:any
  description:any
  max_marks:any;
  no_of_question:any;
  published:any;
  category:any;

  quizz_object:any;
  selecetdId:any;

  addQuizz(){
    this.quizz_object=new Quizz(this.quiz_id,this.title,this.description,this.max_marks,this.no_of_question,this.published,this.category)
    this._quizzService.saveQuizz(this.quizz_object).subscribe(()=>{
      Swal.fire({
        position: "center",
        icon: "success",
        title: "Your work has been saved",
        showConfirmButton: false,
        timer: 1500
      });
    })
  
  }
  categories:any=[
  {
    cid:1,
    title:"programming"
  },
  {
    cid:2,
    title:"gamming"
  },
  {
    cid:3,
    title:"drama"
  },
  {
    cid:4,
    title:"magazin"
  },
  {
    cid:5,
    title:"programming"
  }
]
}
