import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Registration } from 'src/app/Models/registration';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-edit-register-data',
  templateUrl: './edit-register-data.component.html',
  styleUrls: ['./edit-register-data.component.css']
})
export class EditRegisterDataComponent implements OnInit {

  all_data_of_specific_id:any
  
  constructor(private _myservice:UserService,
    private route:ActivatedRoute,
    private router:Router,
  ) { 
 
    // _myservice.showalldata().subscribe((data)=>{
    //   this.old_register_data=data;
      // this.registration_id=data.registration_id.
    // })

    this.all_data_of_specific_id=this.router.getCurrentNavigation()?.extras.state?.["response"];
    // alert(this.all_data_of_specific_id)

  }

  registration_id: any;
  username: any;
  password: any
  firstname: any
  lastname: any
  email: any
  phone: any
  regis_id:any;
  ngOnInit(): void {
    this.regis_id=this.route.snapshot.paramMap.get('registration_id');
//     alert(this.regis_id);
//     this._myservice.getRegistrationDataById(this.regis_id).subscribe((res)=>{

//       alert(res)
//     },
//   (error)=>{
//     alert("error")
//   })
 }

 registrationModel:any;

 msg:any
  updateRegistration(){

    alert("update method")
    this.registrationModel=new Registration(
      this.all_data_of_specific_id.registration_id,
      this.all_data_of_specific_id.username,
      this.all_data_of_specific_id.password,
      this.all_data_of_specific_id.firstname,
      this.all_data_of_specific_id.lastname,
      this.all_data_of_specific_id.email,
      this.all_data_of_specific_id.phone);

    alert(this.registrationModel)

    this._myservice.updateRegistration(this.registrationModel).subscribe(()=>{
      
      
    })
  }



//  end of class
  }


