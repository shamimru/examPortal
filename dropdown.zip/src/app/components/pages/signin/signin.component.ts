import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  constructor(private userService: UserService, private snack: MatSnackBar, private router: Router) { }

  ngOnInit(): void {
  }
  id: any
  password: any;

  loginData: any;

  submitLogin() {
    //adduser: userServices
    this.userService.logIn(this.id, this.password).subscribe((data) => {
      this.loginData = data;
      if (this.loginData != null) {

        // sweetalert
        // Swal.fire("Error !!","Error in Loadig data","error");

        Swal.fire({
          position: "center",
          icon: "success",
          title: "Your work has been saved",
          showConfirmButton: false,
          timer: 1500
        });


        //success
        // this.snack.open("Success", '',
        //   {
        //     duration: 3000,
        //     verticalPosition: 'top',
        //     horizontalPosition: 'center'
        //   }
        // )

        //  snak bar end 
        // alert("logindata")
        this.router.navigateByUrl("success", { state: { response: this.loginData } })

      }


      this.id = "";
      this.password = ""
    },
      (error) => {
        alert("error")
        this.snack.open("Something Went Wrong", '',
          {
            duration: 3000,
            verticalPosition: 'top',
            horizontalPosition: 'center'
          })
        this.router.navigateByUrl("fail")
      })
  }
}





