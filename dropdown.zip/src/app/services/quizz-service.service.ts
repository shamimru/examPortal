import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Quizz } from '../Models/quizz';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuizzServiceService {

  constructor(private _http:HttpClient) { }


  url:any;
  saveQuizz(q:Quizz):Observable<Quizz>{
    this.url="http://localhost:8080/admin/addQuiz"
    return this._http.post<Quizz>(this.url,q);
  }


}
