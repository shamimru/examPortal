export class AddCategory {
    description_id:any
    title:any
    description:any;
    constructor(des:any,title:any,desc:any){
        this.description_id=des;
        this.title=title;
        this.description=desc;
    }
}
