import { ParkingAlloment } from './parking-alloment';

describe('ParkingAlloment', () => {
  it('should create an instance', () => {
    expect(new ParkingAlloment()).toBeTruthy();
  });
});
