export class ParkingAlloment {


   // int allotmentNo;

   // String vehicle_registration_no;
   // String member_code;
   // String memberName;
   // String parking_area;
   // String vehicle_type;


   allotmentNo: any;
   vehicle_registration_no: any;
   member_code: any;
   memberName: any;
   parking_area: any;
   vehicle_type: any;

   constructor(allotmentNo: any, vehicle_registration_noallotmentNo: any, member_code: any, memberName: any, parking_area: any, vehicle_type: any) {
      this.allotmentNo = allotmentNo;
      this.vehicle_registration_no = vehicle_registration_noallotmentNo;
      this.member_code = member_code;
      this.memberName = memberName;
      this.parking_area = parking_area;
      this.vehicle_type = vehicle_type;

   }
}
