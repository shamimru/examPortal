import { Injectable } from '@angular/core';
import { SocietyInformation } from '../Model/society-information';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { AccountMaster } from '../Model/account-master';
import { CostCenterMaster } from '../Model/cost-center-master';
import { AssetsInfo } from '../Model/assets-info';
import { EmployeeMaster } from '../Model/employee-master';
import { MebmersInfoComponent } from '../components/mebmers-info/mebmers-info.component';
import { HomestaffInfo } from '../Model/homestaff-info';
import { Complains } from '../Model/complains';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(
    private http:HttpClient
  ) { }
  url:any;
  // saveCategory(r:AddCategory):Observable<AddCategory>{
  //   this.url="http://localhost:8080/savecategory"
  //   return this._http.post<AddCategory>(this.url,r);
  // }

    soc_info(soc:SocietyInformation):Observable<SocietyInformation>{
      this.url="http://localhost:8080/admin/society_info";
      // alert(this.url)
      return this.http.post<SocietyInformation>(this.url,soc);
  }

  // getAllSocities 

  getAllSocietyData():Observable<SocietyInformation>{
    this.url="http://localhost:8080/admin/getAllSociety";
    // alert(this.url)
    return this.http.get<SocietyInformation>(this.url);
}

  sayHello():Observable<any>{
    this.url="http://localhost:8080/";
    return this.http.get<any>(this.url);
  }

  saveAccountMaster(acc:AccountMaster):Observable<AccountMaster>{
    this.url="http://localhost:8080/admin/saveAccountMaster";
    return this.http.post<AccountMaster>(this.url,acc);
  }

  saveCostAccountMaster(cost:CostCenterMaster):Observable<CostCenterMaster>{
    alert("service")
    this.url="http://localhost:8080/admin/saveCostAccountMaster";
    return this.http.post<CostCenterMaster>(this.url,cost);
  }

  saveAssetsInfo(assets:AssetsInfo):Observable<AssetsInfo>{
    this.url="http://localhost:8080/admin/saveAssetsMaster";
    return this.http.post<AssetsInfo>(this.url,assets);

  }

  saveEmployeeMaster(empoyee:EmployeeMaster):Observable<EmployeeMaster>{
    this.url="http://localhost:8080/admin/saveEmployeeMaster";
    return this.http.post<EmployeeMaster>(this.url,empoyee);

  }
  saveMembership(membership:MebmersInfoComponent):Observable<MebmersInfoComponent>{
    this.url="http://localhost:8080/admin/saveMembership";
    return this.http.post<MebmersInfoComponent>(this.url,membership);
  }
  saveHomeStaff(homestaff:HomestaffInfo):Observable<HomestaffInfo>{
    this.url="http://localhost:8080/admin/saveHomeStaff";
    return this.http.post<HomestaffInfo>(this.url,homestaff);
  }

  saveParingAllotment(homestaff:HomestaffInfo):Observable<HomestaffInfo>{
    this.url="http://localhost:8080/admin/saveParingAllotment";
    return this.http.post<HomestaffInfo>(this.url,homestaff);
  }

  saveComplains(complains:Complains):Observable<Complains>{
    this.url="http://localhost:8080/admin/saveComplains";
    return this.http.post<Complains>(this.url,complains);
  }

  

  // saving building information 
  saveBuildingInformation(building:Object):Observable<Object>{
    this.url="http://localhost:8080/admin/saveBuildingInformation";
    return this.http.post<Object>(this.url,building);
  }

  // getAll Building data 
  showAllBuildingInfo():Observable<Object>{
    this.url="http://localhost:8080/admin/showAllBuildingInfo";
    return this.http.get<Object>(this.url);
  }
  

  

  
  
}
