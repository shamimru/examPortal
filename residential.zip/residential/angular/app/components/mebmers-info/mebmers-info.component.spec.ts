import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MebmersInfoComponent } from './mebmers-info.component';

describe('MebmersInfoComponent', () => {
  let component: MebmersInfoComponent;
  let fixture: ComponentFixture<MebmersInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MebmersInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MebmersInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
