import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowBuildingInfoComponent } from './show-building-info.component';

describe('ShowBuildingInfoComponent', () => {
  let component: ShowBuildingInfoComponent;
  let fixture: ComponentFixture<ShowBuildingInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowBuildingInfoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShowBuildingInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
