import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-building',
  templateUrl: './building.component.html',
  styleUrls: ['./building.component.css']
})
export class BuildingComponent implements OnInit {

  constructor(
    private service:ServiceService
  ) { }

  ngOnInit(): void {
  }
  // int building_id;
	// String building_name;
	// int floor;
	// int apartment_number;
	// int room_number;
	// double rent;
	// String society_id;
	// String building_owner;
	// String owener_number;
	// String email;
	// double landSize;
	
	// String image; 
  building:any={
    "building_id":"",
    "building_name":"",
    "floor":"",
    "apartment_number":"",
    "room_number":"",
    "rent":"",
    "society_id":"",
    "building_owner":"",
    "owener_number":"",
    "email":"",
    "landSize":"",
    "image":""
  }


  buildingSubmit(){

    this.service.saveBuildingInformation(this.building).subscribe((response)=>{
      
    })
  }

}
