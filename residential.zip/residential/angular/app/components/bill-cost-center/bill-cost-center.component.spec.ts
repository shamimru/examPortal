import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillCostCenterComponent } from './bill-cost-center.component';

describe('BillCostCenterComponent', () => {
  let component: BillCostCenterComponent;
  let fixture: ComponentFixture<BillCostCenterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillCostCenterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillCostCenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
