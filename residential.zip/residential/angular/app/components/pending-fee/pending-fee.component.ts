import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pending-fee',
  templateUrl: './pending-fee.component.html',
  styleUrls: ['./pending-fee.component.css']
})
export class PendingFeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
