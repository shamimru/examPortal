import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillAccountLedgerComponent } from './bill-account-ledger.component';

describe('BillAccountLedgerComponent', () => {
  let component: BillAccountLedgerComponent;
  let fixture: ComponentFixture<BillAccountLedgerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillAccountLedgerComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillAccountLedgerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
