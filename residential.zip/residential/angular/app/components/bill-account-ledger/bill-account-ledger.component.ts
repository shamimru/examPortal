import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bill-account-ledger',
  templateUrl: './bill-account-ledger.component.html',
  styleUrls: ['./bill-account-ledger.component.css']
})
export class BillAccountLedgerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
