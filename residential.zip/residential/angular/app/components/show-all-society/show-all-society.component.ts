import { Component, OnInit } from '@angular/core';
import { ServiceService } from 'src/app/MyService/service.service';

@Component({
  selector: 'app-show-all-society',
  templateUrl: './show-all-society.component.html',
  styleUrls: ['./show-all-society.component.css']
})
export class ShowAllSocietyComponent implements OnInit {

  allSocietyData:any
  constructor(
    private service:ServiceService
  ) {
    this.service.getAllSocietyData().subscribe((response)=>{
      this.allSocietyData=response;

    })
   }

  ngOnInit(): void {
  }

}
