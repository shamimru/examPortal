import { Component, OnInit } from '@angular/core';
import { Complains } from 'src/app/Model/complains';

@Component({
  selector: 'app-complaints-type',
  templateUrl: './complaints-type.component.html',
  styleUrls: ['./complaints-type.component.css']
})
export class ComplaintsTypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }


}
