import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-voucher',
  templateUrl: './account-voucher.component.html',
  styleUrls: ['./account-voucher.component.css']
})
export class AccountVoucherComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
