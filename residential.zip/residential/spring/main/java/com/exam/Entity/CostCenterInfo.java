package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class CostCenterInfo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int cost_id;
	String cost_code;
	String name;
	String descriptin;
	String remark;
	
	public CostCenterInfo() {
		super();
	}
	public CostCenterInfo(int cost_id, String cost_code, String name, String descriptin, String remark) {
		super();
		this.cost_id = cost_id;
		this.cost_code = cost_code;
		this.name = name;
		this.descriptin = descriptin;
		this.remark = remark;
	}
	public int getCost_id() {
		return cost_id;
	}
	public void setCost_id(int cost_id) {
		this.cost_id = cost_id;
	}
	public String getCost_code() {
		return cost_code;
	}
	public void setCost_code(String cost_code) {
		this.cost_code = cost_code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescriptin() {
		return descriptin;
	}
	public void setDescriptin(String descriptin) {
		this.descriptin = descriptin;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "CostCenterInfo [cost_id=" + cost_id + ", cost_code=" + cost_code + ", name=" + name + ", descriptin="
				+ descriptin + ", remark=" + remark + "]";
	}
	
	

}
