package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity

public class SocietyInformation {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long society_id;
	String full_name;
	String long_Name;
	String email;
	String address;
	String city;
	String zip_code;
	
	public SocietyInformation() {
		super();
	}

	public SocietyInformation(long society_id, String full_name, String long_Name, String email, String address,
			String city, String zip_code) {
		super();
		this.society_id = society_id;
		this.full_name = full_name;
		this.long_Name = long_Name;
		this.email = email;
		this.address = address;
		this.city = city;
		this.zip_code = zip_code;
	}

	public long getSociety_id() {
		return society_id;
	}

	public void setSociety_id(long society_id) {
		this.society_id = society_id;
	}

	public String getFull_name() {
		return full_name;
	}

	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getLong_Name() {
		return long_Name;
	}

	public void setLong_Name(String long_Name) {
		this.long_Name = long_Name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	@Override
	public String toString() {
		return "SocietyInformation [society_id=" + society_id + ", full_name=" + full_name + ", long_Name=" + long_Name
				+ ", email=" + email + ", address=" + address + ", city=" + city + ", zip_code=" + zip_code + "]";
	}
	
	
	
	

}
