package com.exam.Entity;

import java.util.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@Entity
public class ComplainsLog {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int TicketNo;
	
	@Temporal(TemporalType.DATE)
	Date complain_date;
	String member_code;
	String member_name;
	String complains_type;
	String brifly_describe;
	String elaborate_problem;
	public ComplainsLog() {
		super();
	}
	public ComplainsLog(int ticketNo, Date complain_date, String member_code, String member_name, String complains_type,
			String brifly_describe, String elaborate_problem) {
		super();
		TicketNo = ticketNo;
		this.complain_date = complain_date;
		this.member_code = member_code;
		this.member_name = member_name;
		this.complains_type = complains_type;
		this.brifly_describe = brifly_describe;
		this.elaborate_problem = elaborate_problem;
	}
	public int getTicketNo() {
		return TicketNo;
	}
	public void setTicketNo(int ticketNo) {
		TicketNo = ticketNo;
	}
	public Date getComplain_date() {
		return complain_date;
	}
	public void setComplain_date(Date complain_date) {
		this.complain_date = complain_date;
	}
	public String getMember_code() {
		return member_code;
	}
	public void setMember_code(String member_code) {
		this.member_code = member_code;
	}
	public String getMember_name() {
		return member_name;
	}
	public void setMember_name(String member_name) {
		this.member_name = member_name;
	}
	public String getComplains_type() {
		return complains_type;
	}
	public void setComplains_type(String complains_type) {
		this.complains_type = complains_type;
	}
	public String getBrifly_describe() {
		return brifly_describe;
	}
	public void setBrifly_describe(String brifly_describe) {
		this.brifly_describe = brifly_describe;
	}
	public String getElaborate_problem() {
		return elaborate_problem;
	}
	public void setElaborate_problem(String elaborate_problem) {
		this.elaborate_problem = elaborate_problem;
	}
	@Override
	public String toString() {
		return "ComplainsLog [TicketNo=" + TicketNo + ", complain_date=" + complain_date + ", member_code="
				+ member_code + ", member_name=" + member_name + ", complains_type=" + complains_type
				+ ", brifly_describe=" + brifly_describe + ", elaborate_problem=" + elaborate_problem + "]";
	}
	
	
	

}
