package com.exam.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


@Entity
public class AccountMaster {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	int acc_id;
	
	String  accountNumber;
	String name;
	String transferMoneyAccount;
	
	String description;
	String remark;
	public AccountMaster() {
		super();
	}
	public AccountMaster(int acc_id, String accountNumber, String name, String transferMoneyAccount, String description,
			String remark) {
		super();
		this.acc_id = acc_id;
		this.accountNumber = accountNumber;
		this.name = name;
		this.transferMoneyAccount = transferMoneyAccount;
		this.description = description;
		this.remark = remark;
	}
	public int getAcc_id() {
		return acc_id;
	}
	public void setAcc_id(int acc_id) {
		this.acc_id = acc_id;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTransferMoneyAccount() {
		return transferMoneyAccount;
	}
	public void setTransferMoneyAccount(String transferMoneyAccount) {
		this.transferMoneyAccount = transferMoneyAccount;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	@Override
	public String toString() {
		return "AccountMaster [acc_id=" + acc_id + ", accountNumber=" + accountNumber + ", name=" + name
				+ ", transferMoneyAccount=" + transferMoneyAccount + ", description=" + description + ", remark="
				+ remark + "]";
	}
	

}
